/*--------------------------------------------------------------------------

eDevice.h

This file is part of e.Lib

Interface
Application interface to the eDevice-Board

$Date: 2016-11-12 17:02:47 +0100 (Sa, 12 Nov 2016) $
$Revision: 1170 $

Copyright (c) 2006,2007,2008,2010 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#ifndef E_DEVICE_CONTROLLER_H
#define E_DEVICE_CONTROLLER_H

#include "eCore.h"
#include "eDeviceSerialStream.h"



/** eDevice bietet Methoden zum Zugriff auf den Microcontroller
*/




class eDevice
	{
	public:
		/** Konstruktor.
		*/
		eDevice();
		
	
		
		/** Initialisiert den Controller.
		*/
		static void	reset(void);

		/** Enable the watchdog timer.
		*/
		//static void	enableWatchdog(void);

		/** Disable the watchdog timer.
		*/
		//static void	disableWatchdog(void);

		/** Resets the watchdog timer.
		*/
		//static void	serviceWatchdog(void);

		/** Setzt den Controller in den Uploadmodus.
		Nach Aufruf dieser Methode kann das Board mit der eIDE programmiert werden.
		*/
		//static void	update(void);

		/** Gibt die Zeit in Millisekunden seit der letzten Initialisierung an.
		Initialisiert wird das Board entweder durch Anlegen einer Spannung (USB oder
		�ber Erweiterungsport) oder durch Aufruf der Methode \ref reset().
		\sa reset(), eDevice()
		*/
		static time_t	ticks(void);

		/** Wartet blockierend t Millisekunden.
		*/
		static void		wait(time_t t);

		/** Wartet blockierend t Millisekunden.
		*/
		//static void		wait(time_t t, time_t intervall, timerWaitCallbackHandler handler);

		/** \addtogroup FRAM
		*/
		/*@{*/
		/** Liest aus dem FRAM
			\param adr Offset im FRAM
			\param p Zeiger auf Empfangsdatenpuffer
			\param n Anzahl zu lesender Bytes
			\return Anzahl gelesener Byte
		*/
		static int16	framRead(uint16 adr, void* p, int16 n);
		/** Schreibt ins FRAM
			\param adr Offset im FRAM
			\param p Zeiger auf die zu �bertragenden Daten
			\param n Anzahl zu sendender Bytes
			\return Anzahl geschriebener Byte
		*/
		static int16	framWrite(uint16 adr, const void* p, int16 n);
		/*@}*/

		static bool	getPin(controllerPort port, controllerPortPin pin);

		static void	switchPin(controllerPort port, controllerPortPin pin, bool on);

		static void	setPin(controllerPort port, controllerPortPin pin);

		static void	clearPin(controllerPort port, controllerPortPin pin);
		
		static void	togglePin(controllerPort port, controllerPortPin pin);

		static bool	getBit(controllerPort port, controllerPortBit bit);

		static void	switchBit(controllerPort port, controllerPortBit bit, bool on);

		static void	setBit(controllerPort port, controllerPortBit bit);

		static void	clearBit(controllerPort port, controllerPortBit bit);
		
		static void	toggleBit(controllerPort port, controllerPortBit bit);
		/** \addtogroup RS232
		*/
		/*@{*/
		/** Serielle Schnittstelle #1: SERCOM4.
		*/
		#ifndef BOOTABLE
			static	 serialStream		asc0;
		#endif
		
		
	
		//static usbStream	asc2;
		/** Serielle Schnittstelle #2: SERCOM2, Bluetooth Dongle RX/TX/CTS/RTS.
		*/
		//static serialStream	asc1;
		/** Serielle Schnittstelle #3: SERCOM3, virtual COM port via EDBG.
		*/
		//static serialStream	asc2;

		//static eDevicePWM	pwm;
		/*@}*/
	
	//private:
		/** Initialize controller subsystem.
		*/
		void	initialize(void);
		
		private:
		static bool		eDeviceIsInitialized;
		
	};

time_t ticks(void);

inline void	eDevice::reset(void)
	{
	coreControllerReset();
	}
/*
inline void	eDevice::enableWatchdog(void)
	{
	coreControllerEnableWatchdog();
	}

inline void	eDevice::disableWatchdog(void)
	{
	coreControllerDisableWatchdog();
	}

inline void	eDevice::serviceWatchdog(void)
	{
	coreControllerServiceWatchdog();
	}

inline void	eDevice::update(void)
	{
	coreControllerEnterBootloader();
	}
 */
inline time_t ticks(void)
	{
	return coreSystemTimerTicks();
	}

inline time_t eDevice::ticks(void)
	{
	return coreSystemTimerTicks();
	}

inline void eDevice::wait(time_t t)
	{
	coreSystemTimerWait(t);
	}
/*
inline void eDevice::wait(time_t t, time_t intervall, timerWaitCallbackHandler handler)
	{
	coreSystemTimerWaitWithCallback(t, intervall, handler);
	}
*/
inline bool eDevice::getPin(controllerPort port, controllerPortPin pin)
	{
	return corePortsGetPortPin(port, pin);
	}

inline void eDevice::switchPin(controllerPort port, controllerPortPin pin, bool on)
 	{
 	if (on)
		corePortsSetPortPin(port, pin);
	else
		corePortsClearPortPin(port, pin);
	}

inline void eDevice::setPin(controllerPort port, controllerPortPin pin)
 	{
	corePortsSetPortPin(port, pin);
	}

inline void eDevice::clearPin(controllerPort port, controllerPortPin pin)
	{
	corePortsClearPortPin(port, pin);
	}
		
inline void eDevice::togglePin(controllerPort port, controllerPortPin pin)
	{
	corePortsTogglePortPin(port, pin);
	}

inline bool eDevice::getBit(controllerPort port, controllerPortBit bit)
	{
	return corePortsGetPortBit(port, bit);
	}

inline void eDevice::switchBit(controllerPort port, controllerPortBit bit, bool on)
 	{
 	if (on)
		corePortsSetPortBit(port, bit);
	else
		corePortsClearPortBit(port, bit);
	}

inline void eDevice::setBit(controllerPort port, controllerPortBit bit)
 	{
	corePortsSetPortBit(port, bit);
	}

inline void eDevice::clearBit(controllerPort port, controllerPortBit bit)
	{
	corePortsClearPortBit(port, bit);
	}
		
inline void eDevice::toggleBit(controllerPort port, controllerPortBit bit)
	{
	corePortsTogglePortBit(port, bit);
	}

extern eDevice	controller;


#endif

