/*--------------------------------------------------------------------------

eCore.c

This file is part of e.Lib

Implementation
Library initialization code

$Author: steffen $
$Date: 2016-09-28 14:13:45 +0200 (Mi, 28 Sep 2016) $
$Revision: 967 $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/Libraries/Cortex/e.Lib/eLib.cc $

Copyright (c) 2010 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#include <stdlib.h>
#include <unistd.h>

#include "eLib.h"

//............................................................................
extern "C" void *malloc(size_t)
	{
    return (void *)0;
	}
//............................................................................
extern "C" void free(void *)
	{
	}

extern "C" void *_sbrk (ptrdiff_t)
	{
    return (void *)0;
	}

extern "C"
	{
	void __cxa_pure_virtual(void)
		{
		}
	}

void* operator new(unsigned int size)
	{
	return malloc(size);
	}

void operator delete(void* p)
	{
	free(p);
	}

extern "C" void eLibInitialize(void)
	{
	}

