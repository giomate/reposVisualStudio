/*--------------------------------------------------------------------------

eLib.h

This file is part of e.Development

Interface
Common includes for the eLib C++ library

$Date: 2016-09-28 14:13:45 +0200 (Mi, 28 Sep 2016) $
$Revision: 967 $

Copyright (c) 2006,2007, 2009, 2010 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#ifndef E_LIB_H
#define E_LIB_H

#include "coreTypes.h"

#endif

