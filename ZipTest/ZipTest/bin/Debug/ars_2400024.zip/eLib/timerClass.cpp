/*
 * timerClass.cpp
 *
 * Created: 10/27/2019 5:27:16 PM
 *  Author: giova
 */ 

#include "buttonTimer.h"

#include "eCore.h"
//#include "eCore.h"

static Tc* TCx[] =
{
TC3, TC4, TC5, TC6, TC7,
} ;

timerClass::timerClass(int8 value){
	timerNumber=value;
	timerRegister=TCx[timerNumber-2];

	setUpTimer();
	
}

timerClass::~timerClass(void){
	stopTimer();
}

void timerClass::setUpTimer(void){
	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID(GCLK_CLKCTRL_ID_TC6_TC7_Val) | GCLK_CLKCTRL_GEN(GENERIC_CLOCK_GENERATOR_OSC8M) | GCLK_CLKCTRL_CLKEN;							// select TC3 peripheral channel
	PM->APBCSEL.reg = PM_APBCSEL_APBCDIV_DIV1;
	if(timerRegister== TC7){
		PM->APBCMASK.reg |= PM_APBCMASK_TC7;													// enable TC3 interface
	}else if( timerRegister== TC6){
		PM->APBCMASK.reg |= PM_APBCMASK_TC6;												// Configure synchronous bus clock
	}
}

void timerClass::startTimer(time_t timeoutsec){
	cpu_irq_disable();
	uint32_t	timesec=timeoutsec*20;
		// Configure Count Mode (32-bit)
	timerRegister->COUNT32.CTRLA.reg =TC_CTRLA_MODE_COUNT32|TC_CTRLA_WAVEGEN_MFRQ|TC_CTRLA_PRESCALER_DIV1024;
		
	// Initialize compare value for 100mS @ 500kHz
	timerRegister->COUNT32.CC[0].reg = timesec;
	while(timerRegister->COUNT32.STATUS.bit.SYNCBUSY == 1);
	// Enable TC3 compare mode interrupt generation
	timerRegister->COUNT32.INTENSET.reg = TC_INTENSET_MC0;										// Enable match interrupts on compare channel 0
	
	// Enable TC3
	timerRegister->COUNT32.CTRLA.reg |= TC_CTRLA_ENABLE;
	
	// Wait until TC3 is enabled
	while(timerRegister->COUNT32.STATUS.bit.SYNCBUSY == 1);
	
	NVIC_EnableIRQ((timerRegister==TC6)?TC6_IRQn:TC7_IRQn);						// Enable the interrupt
	
	/* Enable all IRQs */
	cpu_irq_enable();
	
	
}

void timerClass::stopTimer( void){
	cpu_irq_disable();
	NVIC_DisableIRQ((timerRegister==TC6)?TC6_IRQn:TC7_IRQn);		// Disable the interrupt
		
	// Disable TC3
	timerRegister->COUNT32.CTRLA.bit.SWRST = 1 ;
	timerRegister->COUNT32.CTRLA.reg = TC_CTRLA_RESETVALUE;
	cpu_irq_enable();
	
	
}

bool timerClass::timerTimeout(void){
	bool overflow_tcx=(timerRegister->COUNT32.INTFLAG.bit.OVF);
	return overflow_tcx;
}

#ifdef BOOTABLE
timerClass BootTimer;

bool samba_timeout(void){
	
	return BootTimer.timerTimeout()==0;
}
void samba_timerInit(void){
	
	timerClass BootTimer(7);
	
	BootTimer.startTimer((time_t)SAMBA_TIMEOUT);
}

#endif