/*
 * buttonTimer.h
 *
 * Created: 10/27/2019 5:17:11 PM
 *  Author: giova
 */ 


#ifndef BUTTONTIMER_H_
#define BUTTONTIMER_H_


//#include "coreSystemTimer.h"
#include "coreTypes.h"
#include "sam.h"
//#include "sam_ba_monitor.h"




class timerClass
{
public:
	timerClass(){};
	timerClass(int8 value);
	~timerClass();
	void  startTimer(time_t timeoutsec);
	void stopTimer(void);
	bool timerTimeout(void);
	#ifdef BOOTABLE
		friend bool samba_timeout(void);
		friend void samba_timerInit(void);
	#endif
	
protected:
	void setUpTimer(void);
	
private:
	int8	timerNumber;
	Tc	* timerRegister;

};

#ifdef BOOTABLE
	#define SAMBA_TIMEOUT						90
	extern timerClass BootTimer;


extern bool samba_timeout(void);
extern void samba_timerInit(void);
#endif


#endif /* BUTTONTIMER_H_ */