/*--------------------------------------------------------------------------

serialStream.cc

This file is part of e.Development

Implementation
Serial IO using low level routines provided in asyncSerial

$Date: 2016-09-28 14:13:45 +0200 (Mi, 28 Sep 2016) $
$Revision: 967 $
$Author: steffen $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/Libraries/Cortex/e.Lib/eDeviceSerialStream.cc $

Copyright (c) 2006,2007 Steffen Simon.
All rights reserved.
--------------------------------------------------------------------------*/

#include <eDeviceSerialStream.h>

serialStream::serialStream(uint8 uart)
	:selfUART(uart)
	{
	}

bool serialStream::open(void)
	{
#ifdef ICB_Revision
	return coreAsyncSerialOpen(selfUART, kBaud230400, 8, 1, false) == 0;
#else
	coreAsyncSerialConfigure(selfUART, 115200, 8, 1, 0);
	return coreAsyncSerialOpen(selfUART) == 0;
	//return coreAsyncSerialOpen(selfUART, kBaud57600, 8, 1, false) == 0;
#endif
	}

bool serialStream::open(int32 baud, uint8 bits, uint8 stop, bool parity)
	{
	coreAsyncSerialConfigure(selfUART, baud, bits, stop, parity);
	return coreAsyncSerialOpen(selfUART) == 0;
	}

bool serialStream::close(void)
	{
	return coreAsyncSerialClose(selfUART) == 0;
	}

bool serialStream::dataAvailable(void)
	{
	return coreAsyncSerialDataAvailable(selfUART) > 0;
	}

int16 serialStream::readData(void* p, int16 n, time_t timeout)
	{
	int16	nRead(coreAsyncSerialRead(selfUART, (byte*)p, n, timeout));
	return nRead;
	}

int16 serialStream::writeData(const void* p, int16 n)
	{
	int16	nWritten(coreAsyncSerialWrite(selfUART, (byte*)p, n));
	return nWritten;
	}

