/*
 * thermometerClass.h
 *
 * Created: 10/27/2019 2:45:09 PM
 *  Author: giova
 */ 


#ifndef THERMOMETERCLASS_H_
#define THERMOMETERCLASS_H_
#include "coreTypes.h"
#include "coreADConverter.h"



class thermoClass
{
public:
	friend class applicationClass;
	friend void coreADCPortConfigure( uint8,  uint8);
	friend void coreADConverterSelectChannel(uint8 );
	
	thermoClass(uint8);
	
	void	initThermo(void);
	
	int16	getTemperatureRaw(void);
	float	getTemperature(void);
	
	
protected:
	
private:
	uint16	lastResult,actualResult;
	
	uint8 temperature;
	uint8	AIchannel;
	
};






#endif /* THERMOMETERCLASS_H_ */