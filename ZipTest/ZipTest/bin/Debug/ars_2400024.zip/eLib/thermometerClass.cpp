/*
 * thermometerClass.cpp
 *
 * Created: 10/27/2019 2:57:29 PM
 *  Author: giova
 */ 

#include "thermometerClass.h"
#include "coreADConverter.h"
#include "eDevice.h"


//serialStream	thermoClass::uart2(kUART2);

thermoClass::thermoClass(uint8 channel){
	AIchannel=channel;
	
	temperature= 20.0;
	
}

void thermoClass::initThermo(void){
	
	coreADCPortConfigure(0,AIchannel);
	
	//coreADConverterSelectChannel(AIchannel);
}



int16 thermoClass::getTemperatureRaw(void){
	int16	temperatureRaw;

	coreADConverterSelectChannel(AIchannel);
	temperatureRaw= coreADConverterReadSingle();

	#if __DEBUG__  > 3
	controller.asc0 << coreSystemTimerTicks() << ": getTemperatureRaw: raw == " << temperatureRaw << newline;
	#endif
	
	return temperatureRaw;
}

float thermoClass::getTemperature(void){
	
	temperature = 0.1659 * (float)(getTemperatureRaw()) - 436.35;
	#if __DEBUG__  > 3
	controller.asc0 << coreSystemTimerTicks() << ": getTemperature: temperature == " << temperature << newline;
	#endif
	
	return temperature;
}



