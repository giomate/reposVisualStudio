/*--------------------------------------------------------------------------

eDevice.cc

This file is part of e.Development

Implementation
Application interface to the eDevice-Board

$Date: 2017-08-01 12:23:06 +0200 (Di, 01 Aug 2017) $
$Revision: 1516 $
$Author: steffen $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/Libraries/Cortex/e.Lib/eDevice.cc $

--------------------------------------------------------------------------*/

#include <stdlib.h>
#include "eDevice.h"
#include "eDeviceEvent.h"
#include "applicationClass.h"





eDevice controller;

eDevice::eDevice(){
	
	
	
		
}
#ifndef BOOTABLE
	serialStream	eDevice::asc0(kUART2);
#endif

void eDevice::initialize(void)
	{
	
	eCoreInitialize();	
	// Setup async serial communication
	#ifndef BOOTABLE
		asc0.open(115200, 8, 1, 0);
	#endif
	
	//asc1.open(115200, 8, 1, 0);
	//asc2.init(115200, 8, 1, 0);
	}

/** Liest aus dem FRAM
	\param adr Adresse des Ger�ts
	\param p Zeiger auf die zu �bertragenden Daten
	\return Anzahl gelesener Byte
*/
#ifdef NVM_SUPPORT
int16 eDevice::framRead(uint16 adr, void* p, int16 n)
	{
	return coreNVMRead(kNVM1, adr, p, n);
	}

/** Schreibt ins FRAM
	\param p Zeiger auf die zu �bertragenden Daten
	\param n Anzahl zu sendender Bytes
	\return Anzahl geschriebener Byte
*/
int16 eDevice::framWrite(uint16 adr, const void* p, int16 n)
	{
	return coreNVMWrite(kNVM1, adr, p, n);
	}
#endif

