/*--------------------------------------------------------------------------

serialStream.h

This file is part of e.Development

Interface
Serial IO using low level routines provided in asyncSerial

$Date: 2016-09-28 14:13:45 +0200 (Mi, 28 Sep 2016) $
$Revision: 967 $

Copyright (c) 2003,2004,2005 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/

#ifndef SERIAL_STREAM_H
#define SERIAL_STREAM_H

#include "coreAsyncSerial.h"
#include <eDeviceStream.h>

/** \addtogroup RS232
*/
/*@{*/
const int32	kBaud1200 = 1200;
const int32	kBaud2400 = 2400L;
const int32	kBaud9600 = 9600L;
const int32	kBaud19200 = 19200L;
const int32	kBaud38400  = 38400L;
const int32	kBaud57600  = 57600L;
const int32	kBaud115200  = 115200L;
const int32	kBaud230400  = 230400L;


/** serialStream erm�glicht die Ausgabe auf die seriellen Ports des @ref eDeviceController.
  */
class serialStream :public stream
	{
	public:
		serialStream(uint8 uart);
		//~serialStream();
		/** Konfiguriert den seriellen Port
		 */

		/** Setzt die Einstellungen des seriellen Ports auf die Standardwerte:
			57600 Baud,8 Datenbits, 1 Stopbit, keine Parit�t
		 */
		bool		open(void);
		bool		open(int32 baud, uint8 bits, uint8 stop, bool parity);
		bool		close(void);

		/** �berpr�ft, ob ein Zeichen verf�gbar ist.
		 */
		virtual bool dataAvailable(void);

		virtual int16	readData(void*, int16, time_t);
		virtual int16	writeData(const void*, int16);
		
	protected:
		uint8	selfUART;
	};
/*@}*/

#endif // SERIAL_STREAM_H
