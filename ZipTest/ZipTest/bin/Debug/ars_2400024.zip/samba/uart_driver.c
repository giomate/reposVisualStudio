/*******************************************************************************
Copyright (c) 2017 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/





#if BOOTABLE

#include "uart_driver.h"
#include "usart_sam_ba.h"
#include "coreController.h"

#include "eCore.h"
/**
 * \brief Open the given USART
 */
void usart_open()
{
	configure_sercom_port_pins();
	clock_configuration_for_boot_usart(); 

	uart_basic_init(BOOT_USART_MODULE, USART_BAUD_REG_VAL_FOR_SAMBA, BOOT_USART_MUX_SETTINGS);
	/*enable of interrups*/
	uart_inter_enable(BOOT_USART_MODULE);
}

void uart_basic_init(Sercom *sercom, uint16_t baud_val, uint32_t pad_conf)
{
	/* Wait for synchronization */
	wait_for_usart_enable_sync(sercom);
	/* Disable the SERCOM UART module */
	//sercom->USART.CTRLA.bit.ENABLE = 0;
	/* Wait for synchronization */
	wait_for_usart_swrst_sync(sercom);
	/* Perform a software reset */
	sercom->USART.CTRLA.bit.SWRST = 1;
	/* Wait for synchronization */
	wait_for_usart_swrst_sync(sercom);
	/* Wait for synchronization */
	wait_for_usart_swrst_enable_sync(sercom);
	/* Update the UART pad settings, mode and data order settings */
	sercom->USART.CTRLA.reg = pad_conf | SERCOM_USART_CTRLA_MODE(1) | 
											SERCOM_USART_CTRLA_DORD |
											SERCOM_USART_CTRLA_SAMPR(0x0)| 											SERCOM_USART_CTRLA_RUNSTDBY;
	/* Wait for synchronization */
	wait_for_usart_ctrlb_sync(sercom);
	/* Enable transmit and receive and set data size to 8 bits */
	sercom->USART.CTRLB.reg = SERCOM_USART_CTRLB_RXEN | SERCOM_USART_CTRLB_TXEN | SERCOM_USART_CTRLB_CHSIZE(0);
	/* Load the baud value */
	sercom->USART.BAUD.reg = baud_val;
	/* Wait for synchronization */
	wait_for_usart_enable_sync(sercom);
	/* Enable SERCOM UART */
	sercom->USART.CTRLA.bit.ENABLE = 1;
}
void uart_inter_enable(Sercom *sercom){
	cpu_irq_disable();
	wait_for_usart_ctrlb_sync(sercom);
	
	/* enable interrup event */
	//sercom->USART.INTENSET.reg = SERCOM_USART_INTENSET_RXS;
	sercom->USART.INTENSET.reg = SERCOM_USART_INTENSET_RXC;

	// Enable interrupts
	NVIC_EnableIRQ(SERCOM5_IRQn);
	
	cpu_irq_enable();
	
}

void uart_inter_disable(Sercom *sercom){
	cpu_irq_disable();
	NVIC_DisableIRQ(SERCOM5_IRQn);
	wait_for_usart_ctrlb_sync(sercom);
	
	/* Disable interrup event */
	//sercom->USART.INTENCLR.reg =SERCOM_USART_INTENCLR_RXS;
	sercom->USART.INTENCLR.reg =SERCOM_USART_INTENCLR_RXC;

	// Enable interrupts
	
	cpu_irq_enable();
	
}

void uart_disable(Sercom *sercom)
{
	/* Wait for synchronization */
	wait_for_usart_enable_sync(sercom);
	/* Disable SERCOM UART */
	sercom->USART.CTRLA.bit.ENABLE = 0;
}

void uart_write_byte(Sercom *sercom, uint8_t data)
{
	wait_for_uart_syncbusy_clear(sercom);
	
	/* Write the data to DATA register */
	sercom->USART.DATA.reg = (uint16_t)data;

	while (!(sercom->USART.INTFLAG.reg & SERCOM_USART_INTFLAG_TXC));
}

uint8_t uart_read_byte(Sercom *sercom)
{
	wait_for_uart_syncbusy_clear(sercom);
	uart_read_clear_errors(sercom);
	
	/* Return the read data */
	return((uint8_t)sercom->USART.DATA.reg);
}

void uart_write_buffer_polled(Sercom *sercom, uint8_t *ptr, uint16_t length)
{
	/* Do the following for specified length */
	do {
		/* Wait for Data Register Empty flag */
		while(!sercom->USART.INTFLAG.bit.DRE);
		/* Send data from the buffer */
		sercom->USART.DATA.reg = (uint16_t)*ptr++;
	} while (length--);
}

void uart_read_buffer_polled(Sercom *sercom, uint8_t *ptr, uint16_t length)
{
	/* Do the following for specified length */
	do {
		/* Wait for Receive Complete flag */
		while(!sercom->USART.INTFLAG.bit.RXC);
		uart_read_clear_errors(sercom);

		/* Store the read data to the buffer */
		*ptr++ = (uint8_t)sercom->USART.DATA.reg;
	} while (length--);
}

bool usart_is_rx_ready(void) {

	bool uart_ready=false;
	
	//uart_ready=(BOOT_USART_MODULE->USART.INTFLAG.bit.RXC)|(BOOT_USART_MODULE->USART.SYNCBUSY.bit.CTRLB);
	uart_ready=(BOOT_USART_MODULE->USART.INTFLAG.bit.RXC);

	return uart_ready;
	
}

void configure_port_pin(uint32_t gpio_pin, uint32_t pin_mux_position)
{
	Port *const ports[PORT_INST_NUM] = PORT_INSTS;
	PortGroup *port;
	uint32_t pin_mask, pin_cfg;

	port = &(ports[gpio_pin/128]->Group[gpio_pin/32]);
	pin_cfg = PORT_WRCONFIG_PMUXEN | (pin_mux_position << PORT_WRCONFIG_PMUX_Pos) | PORT_WRCONFIG_INEN;
	pin_mask = 1L << ((gpio_pin) % 32);
	
	port->WRCONFIG.reg = ((pin_mask & 0xFFFF) << PORT_WRCONFIG_PINMASK_Pos) |
	pin_cfg | PORT_WRCONFIG_WRPMUX | PORT_WRCONFIG_WRPINCFG;
	port->WRCONFIG.reg = ((pin_mask >> 16) << PORT_WRCONFIG_PINMASK_Pos) |
	pin_cfg | PORT_WRCONFIG_WRPMUX | PORT_WRCONFIG_WRPINCFG | PORT_WRCONFIG_HWSEL;
}

void configure_sercom_port_pins(void)
{
	uint32_t gpio_pin, pin_mux_position;
	
	if(BOOT_USART_PAD0 != PINMUX_UNUSED){
		gpio_pin = BOOT_USART_PAD0 >> 16;
		pin_mux_position = BOOT_USART_PAD0 & 0xFFFF;
		configure_port_pin(gpio_pin, pin_mux_position);
	}

	if(BOOT_USART_PAD1 != PINMUX_UNUSED){
		gpio_pin = BOOT_USART_PAD1 >> 16;
		pin_mux_position = BOOT_USART_PAD1 & 0xFFFF;
		configure_port_pin(gpio_pin, pin_mux_position);
	}

	if(BOOT_USART_PAD2 != PINMUX_UNUSED){
		gpio_pin = BOOT_USART_PAD2 >> 16;
		pin_mux_position = BOOT_USART_PAD2 & 0xFFFF;
		configure_port_pin(gpio_pin, pin_mux_position);
	}

	if(BOOT_USART_PAD3 != PINMUX_UNUSED){
		gpio_pin = BOOT_USART_PAD3 >> 16;
		pin_mux_position = BOOT_USART_PAD3 & 0xFFFF;
		configure_port_pin(gpio_pin, pin_mux_position);
	}
}




void clock_configuration_for_boot_usart(void)
{
	uint8_t inst = 0;
	Sercom *sercom_instances[SERCOM_INST_NUM] = SERCOM_INSTS;

	for (uint32_t i = 0; i < SERCOM_INST_NUM; i++) {
		if (BOOT_USART_MODULE == sercom_instances[i]) {
			inst = i;
			break;
		}
	}

	enable_sercom_digital_interface_clock(inst);

	/* Set GCLK_GEN0 as source for GCLK_ID_SERCOMx_CORE */
	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID(inst+GCLK_CLKCTRL_ID_SERCOM0_CORE_Val) | (GCLK_CLKCTRL_GEN(GENERIC_CLOCK_GENERATOR_OSC8M)) | GCLK_CLKCTRL_CLKEN;
}
void enable_sercom_digital_interface_clock(uint8_t inst)
{
	PM->APBCMASK.reg |= (1u << (inst + PM_APBCMASK_SERCOM0_Pos));
}







#endif
