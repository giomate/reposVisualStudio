/*
 * StreamOperator.cpp
 *
 * Created: 10/1/2019 5:11:26 AM
 * Author : giova
 */ 




#include "main.h"


int main(void)
{
	controller.initialize();
	initializeEvents();
	#if __DEBUG__
	
	controller.asc0 << newline;
	controller.asc0 << "Application startup sequence finished" << newline;
	controller.asc0 << "    " << getVersionAsString() << newline;
	
	
	
		controller.asc0 << newline;
		controller.asc0 << "Application startup sequence finished" << newline;
		controller.asc0 << "    " << getVersionAsString() << newline;
		controller.asc0 << "    " << getRevisionAsString() << newline;
		controller.asc0 << "    " << getTargetAsString() << newline;
		controller.asc0 << "    " << getBuildDateAsString() << ", " << getBuildTimeAsString() << newline;
		controller.asc0 << "_______________________________________________________" << newline << newline << newline;
	
		uint8	resetCause;
		uint8	resetCauseIndex;
		uint8_t buffer[16];


		resetCause = (uint8)PM->RCAUSE.reg;
		
		for (resetCauseIndex=0; resetCauseIndex<8; resetCauseIndex++)
		{
			if (resetCause & (1 << resetCauseIndex))
			break;
		}
		
		controller.asc0 << newline;
		controller.asc0 << "_______________________________________________________" << newline;
		controller.asc0 << "Startup sequence finished" << newline;
		controller.asc0 << "reset cause: " << kModeHex << resetCause << " (" << resetCauseDescription[resetCauseIndex] << ")" << newline;
		controller.asc0 << getVersionAsString() << newline;
		controller.asc0 << getRevisionAsString() << newline;
		controller.asc0 << getTargetAsString() << newline;
		controller.asc0 << getBuildDateAsString() << ", " << getBuildTimeAsString() << newline << newline;
		controller.asc0 << "CPU serial: ";
		applicationToolsGetCPUSerialNumber(buffer);
		coreAsyncSerialWriteDataAsHexString(kUART2, buffer, sizeof(buffer), false);
		controller.asc0 << newline;
		controller.asc0 << "_______________________________________________________" << newline << newline << newline;
		
	#endif
	
	corePWMSetUnitFrequency(kPWMUnit0, 1000);
	Door.initDoor();
	Door.run();
	
	return(0);
}
