/*
 * main.h
 *
 * Created: 10/11/2019 9:34:16 AM
 *  Author: GMateusDP
 */ 


#ifndef MAIN_H_
#define MAIN_H_

#include "sam.h"
#include "eCore.h"
#include <string.h>
//#include "eDeviceEvent.h"
#include "version.h"
#include "eDevice.h"
#include "applicationClass.h"




uint8_t applicationToolsGetCPUSerialNumber(uint8_t* buffer)
{
	memcpy(buffer, (uint8_t*)0x0080A00C, 4);
	memcpy(buffer + 4, (uint8_t*)0x0080A040, 4);
	memcpy(buffer + 8, (uint8_t*)0x0080A044, 4);
	memcpy(buffer + 12, (uint8_t*)0x0080A048, 4);

	return 16;
}

static const char* resetCauseDescription[] =
{
	"POR",		//	0x01
	"BOD12",	//	0x02
	"BOD33",	//	0x04
	"unused",	//	0x08
	"EXT",		//	0x10
	"WDT",		//	0x20
	"SYST",		//	0x40
	"Reserved",
	"unknown",
};





#endif /* MAIN_H_ */