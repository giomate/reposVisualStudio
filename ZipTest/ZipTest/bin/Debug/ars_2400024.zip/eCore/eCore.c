/*--------------------------------------------------------------------------

eCore.c

This file is part of e.Development

Implementation
Library initialization code

$Author: steffen $
$Date: 2016-11-12 17:02:47 +0100 (Sa, 12 Nov 2016) $
$Revision: 1170 $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/Libraries/Cortex/e.Core/eCore.c $

Copyright (c) 2010 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#include "eCore.h"
#include "corePorts.h"
#include "sam.h"

#ifdef BOOTABLE
	#include "sam_ba_monitor.h"
#endif

void eCoreInitialize(void)
	{
	//coreInterruptsInitialize();
	corePortsInitialize();
	coreControllerInitialize();
	// Interrupts an
	//coreInterruptsEnableInterrupts();
	coreSystemTimerInitialize();
	coreSystemTimerOpen();
	//	coreFlashROMInitialize();
	//	coreControllerConfigureSDRAM();
	#ifdef BOOTABLE
		set_flash_wait_states();
		init_sam_ba_monitor_interface();
	#else
		coreAsyncSerialInitialize();
	#endif
   	
   //	coreI2CInitialize();
   	//coreUSBInitialize();
	corePWMInitialize();
   	coreADConverterInitialize();
	coreADConverterOpen();
	//coreEICInitialize();
   	//coreSPIInitialize();
/*
	coreRTCInitialize();
	coreNVMInitialize();
#if (PARTNUMBER != 1205)
#endif
#ifdef ICB_Revision
#endif
#ifdef NSD_SUPPORT
   	coreCANInitialize();
#endif
*/
	}

