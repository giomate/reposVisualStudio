/*--------------------------------------------------------------------------

coreSERCOM.h

This file is part of e.Core

Interface
low level interface to the Atmel SAM SERCOM units

$Date: 2016-09-28 14:13:45 +0200 (Mi, 28 Sep 2016) $
$Revision: 967 $

--------------------------------------------------------------------------*/
#ifndef CORE_kUARTH
#define CORE_kUARTH

#include "coreTypes.h"
#include "sam.h"

#ifndef CCPU
#define kUARTFREQ_REF 1000000
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
	*\defgroup SERCOM Atmel SAM serial communication
*/
/*@{*/

enum
	{
	kSERCOM0,
	kSERCOM1,
	kSERCOM2,
	kSERCOM3,
	kSERCOM4,
	kSERCOM5,
	kNumberOfSERCOMs,
	};

enum SercomOperationMode
	{
	kUARTExternalClock = 0,
	kUARTInternalClock = 1,
	kSPISlaveOperation = 2,
	kSPIMasterOperation = 3,
	kI2CSlaveOperation = 4,
	kI2CMasterOperation = 5,
	};

typedef enum SercomOperationMode	SercomOperationMode;

typedef enum
	{
	kUARTEVENParity = 0,
	kUARTODDParity,
	kUARTNOParity
	} SercomParityMode;

typedef enum
	{
	kUARTStopBits1 = 0,
	kUARTSTOPBits2
	} SercomNumberStopBit;

typedef enum
	{
	MSB_FIRST = 0,
	LSB_FIRST
	} SercomDataOrder;

typedef enum
	{
	kUARTCharSize8Bits = 0,
	kUARTCharSize9Bits,
	kUARTCharSize5Bits = 0x5u,
	kUARTCharSize6Bits,
	kUARTCharSize7Bits
	} SercomUartCharSize;

typedef enum
{
	kUARTRX_PAD_0 = 0,
	kUARTRX_PAD_1,
	kUARTRX_PAD_2,
	kUARTRX_PAD_3
} SercomRXPad;

typedef enum
{
	UART_TX_PAD_0 = 0x0ul,	// Only for UART
	UART_TX_PAD_2 = 0x1ul,  // Only for UART
	UART_TX_RTS_CTS_PAD_0_2_3 = 0x2ul,  // Only for UART with TX on PAD0, RTS on PAD2 and CTS on PAD3
} SercomUartTXPad;

typedef enum
{
	SAMPLE_RATE_x16 = 0x1,	//Fractional
	SAMPLE_RATE_x8 = 0x3,	//Fractional
} SercomUartSampleRate;

typedef enum
{
	kModeSPIClockMode0 = 0,	// CPOL : 0  | CPHA : 0
	kModeSPIClockMode1,		// CPOL : 0  | CPHA : 1
	kModeSPIClockMode2,		// CPOL : 1  | CPHA : 0
	kModeSPIClockMode3		// CPOL : 1  | CPHA : 1
} SercomSpiClockMode;

typedef enum
{
	SPI_PAD_0_SCK_1 = 0,
	SPI_PAD_2_SCK_3,
	SPI_PAD_3_SCK_1,
	SPI_PAD_0_SCK_3
} SercomSpiTXPad;

typedef enum
{
	SPI_CHAR_SIZE_8Bits = 0x0ul,
	SPI_CHAR_SIZE_9Bits
} SercomSpiCharSize;

typedef enum
{
	I2C_UNKNOWN_STATE = 0x0ul,
	I2C_IDLE_STATE,
	I2C_OWNER_STATE,
	I2C_BUSY_STATE
} SercomWireBusState;

typedef enum
{
	I2C_WRITE_FLAG = 0x0ul,
	I2C_READ_FLAG
} SercomWireReadWriteFlag;

typedef enum
{
	I2C_MASTER_ACT_NO_ACTION = 0,
	I2C_MASTER_ACT_REPEAT_START,
	I2C_MASTER_ACT_READ,
	I2C_MASTER_ACT_STOP
} SercomMasterCommandWire;

typedef enum
{
	I2C_MASTER_ACK_ACTION = 0,
	I2C_MASTER_NACK_ACTION
} SercomMasterAckActionWire;

// ========== UART ========== //
void coreSercomInitUART(uint8_t sercom, SercomOperationMode mode, SercomUartSampleRate sampleRate, uint32_t baudrate);
void coreSercomInitFrame(uint8_t sercom, SercomUartCharSize charSize, SercomDataOrder dataOrder, SercomParityMode parityMode, SercomNumberStopBit nbStopBits);
void coreSercomInitPads(uint8_t sercom, SercomUartTXPad txPad, SercomRXPad rxPad);

void coreSercomResetUART(uint8_t sercom);
void coreSercomEnableUART(uint8_t sercom);
void coreSercomFlushUART(uint8_t sercom);
void coreSercomClearStatusUART(uint8_t sercom);
bool coreSercomAvailableDataUART(uint8_t sercom);
bool coreSercomIsBufferOverflowErrorUART(uint8_t sercom);
bool coreSercomIsFrameErrorUART(uint8_t sercom);
bool coreSercomIsParityErrorUART(uint8_t sercom);
bool coreSercomIsDataRegisterEmptyUART(uint8_t sercom);
uint8_t coreSercomReadDataUART(uint8_t sercom);
int coreSercomWriteDataUART(uint8_t sercom, uint8_t data);
bool coreSercomIsUARTError(uint8_t sercom);
void coreSercomAcknowledgeUARTError(uint8_t sercom);

// ========== SPI ========== //
void coreSercomInitSPI(uint8_t sercom, SercomSpiTXPad mosi, SercomRXPad miso, SercomSpiCharSize charSize, SercomDataOrder dataOrder);
void coreSercomInitSPIClock(uint8_t sercom, SercomSpiClockMode clockMode, uint32_t baudrate);

void coreSercomResetSPI(uint8_t sercom);
void coreSercomEnableSPI(uint8_t sercom);
void coreSercomDisableSPI(uint8_t sercom);
void coreSercomSetDataOrderSPI(uint8_t sercom, SercomDataOrder dataOrder);
SercomDataOrder coreSercomGetDataOrderSPI(uint8_t sercom);
void coreSercomSetBaudrateSPI(uint8_t sercom, uint8_t divider);
void coreSercomSetClockModeSPI(uint8_t sercom, SercomSpiClockMode clockMode);
void coreSercomWriteDataSPI(uint8_t sercom, uint8_t data);
uint16_t coreSercomReadDataSPI(uint8_t sercom);
bool coreSercomIsBufferOverflowErrorSPI(uint8_t sercom);
bool coreSercomIsDataRegisterEmptySPI(uint8_t sercom);
bool coreSercomIsTransmitCompleteSPI(uint8_t sercom);
bool coreSercomIsReceiveCompleteSPI(uint8_t sercom);

// ========== I2C ========== //
void coreSercomInitSlaveI2C(uint8_t sercom, uint8_t address);
void coreSercomInitMasterI2C(uint8_t sercom, uint32_t baudrate);

void coreSercomResetI2C(uint8_t sercom);
void coreSercomEnableI2C(uint8_t sercom);
void coreSercomDisableI2C(uint8_t sercom);
void coreSercomPrepareNackBitI2C(uint8_t sercom);
void coreSercomPrepareAckBitI2C(uint8_t sercom);
void coreSercomPrepareCommandBitsI2C(uint8_t sercom, uint8_t cmd);
bool coreSercomStartTransmissionI2C(uint8_t sercom, uint8_t address, SercomWireReadWriteFlag flag);
bool coreSercomSendDataMasterI2C(uint8_t sercom, uint8_t data);
bool coreSercomSendDataSlaveI2C(uint8_t sercom, uint8_t data);
bool coreSercomIsMasterI2C(uint8_t sercom);
bool coreSercomIsSlaveI2C(uint8_t sercom);
bool coreSercomIsBusIdleI2C(uint8_t sercom);
bool coreSercomIsBusOwnerI2C(uint8_t sercom);
bool coreSercomIsDataReadyI2C(uint8_t sercom);
bool coreSercomIsStopDetectedI2C(uint8_t sercom);
bool coreSercomIsRestartDetectedI2C(uint8_t sercom);
bool coreSercomIsAddressMatchI2C(uint8_t sercom);
bool coreSercomIsMasterReadOperationI2C(uint8_t sercom);
bool coreSercomIsRXNackReceivedI2C(uint8_t sercom);
int coreSercomAvailableI2C(uint8_t sercom);
uint8_t coreSercomReadDataI2C(uint8_t sercom);
/*@}*/

#ifdef __cplusplus
	}
#endif

#endif
