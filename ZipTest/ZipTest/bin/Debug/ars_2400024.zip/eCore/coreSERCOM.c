/*
*/

#include "coreSERCOM.h"

//#include "variant.h"
#define GCM_SERCOMx_SLOW          (0x13U)
#define GCM_SERCOM0_CORE          (0x14U)
#define GCM_SERCOM1_CORE          (0x15U)
#define GCM_SERCOM2_CORE          (0x16U)
#define GCM_SERCOM3_CORE          (0x17U)
#define GCM_SERCOM4_CORE          (0x18U)
#define GCM_SERCOM5_CORE          (0x19U)

#define SERCOM_CLOCK		8000000UL
#ifndef SERCOM_CLOCK
#define SERCOM_CLOCK		F_CPU
#endif

#define SERCOM_CLOCK		8000000UL

Sercom*	sercoms[6] =
	{
	SERCOM0,
	SERCOM1,
	SERCOM2,
	SERCOM3,
	SERCOM4,
	SERCOM5,
	};

uint8_t coreSercomCalculateBaudrateSynchronous(uint32_t baudrate);
uint32_t coreSercomDivision(uint32_t dividend, uint32_t divisor);
void coreSercomInitClockNVIC(uint8_t sercom);
/* 	=========================
 *	===== Sercom UART
 *	=========================
*/
void coreSercomInitUART(uint8_t sercom, SercomOperationMode mode, SercomUartSampleRate sampleRate, uint32_t baudrate)
{
  coreSercomInitClockNVIC(sercom);
  coreSercomResetUART(sercom);

  //Setting the CTRLA register
  sercoms[sercom]->USART.CTRLA.reg = SERCOM_USART_CTRLA_MODE(mode) |
                SERCOM_USART_CTRLA_SAMPR(sampleRate);

  //Setting the Interrupt register
  sercoms[sercom]->USART.INTENSET.reg = SERCOM_USART_INTENSET_RXC |  //Received complete
                                SERCOM_USART_INTENSET_ERROR; //All others errors

  if ( mode == kUARTInternalClock )
  {
    uint16_t sampleRateValue;

    if (sampleRate == SAMPLE_RATE_x16) {
      sampleRateValue = 16;
    } else {
      sampleRateValue = 8;
    }

    // Asynchronous fractional mode (Table 24-2 in datasheet)
    //   BAUD = fref / (sampleRateValue * fbaud)
    // (multiply by 8, to calculate fractional piece)
    uint32_t baudTimes8 = (SystemCoreClock * 8) / (sampleRateValue * baudrate);

    sercoms[sercom]->USART.BAUD.FRAC.FP   = (baudTimes8 % 8);
    sercoms[sercom]->USART.BAUD.FRAC.BAUD = (baudTimes8 / 8);
  }
}
void coreSercomInitFrame(uint8_t sercom, SercomUartCharSize charSize, SercomDataOrder dataOrder, SercomParityMode parityMode, SercomNumberStopBit nbStopBits)
{
  //Setting the CTRLA register
  sercoms[sercom]->USART.CTRLA.reg |=	SERCOM_USART_CTRLA_FORM( (parityMode == kUARTNOParity ? 0 : 1) ) |
                dataOrder << SERCOM_USART_CTRLA_DORD_Pos;

  //Setting the CTRLB register
  sercoms[sercom]->USART.CTRLB.reg |=	SERCOM_USART_CTRLB_CHSIZE(charSize) |
                nbStopBits << SERCOM_USART_CTRLB_SBMODE_Pos |
                (parityMode == kUARTNOParity ? 0 : parityMode) << SERCOM_USART_CTRLB_PMODE_Pos; //If no parity use default value
}

void coreSercomInitPads(uint8_t sercom, SercomUartTXPad txPad, SercomRXPad rxPad)
{
  //Setting the CTRLA register
  sercoms[sercom]->USART.CTRLA.reg |=	SERCOM_USART_CTRLA_TXPO(txPad) |
                SERCOM_USART_CTRLA_RXPO(rxPad);

  // Enable Transceiver and Receiver
  sercoms[sercom]->USART.CTRLB.reg |= SERCOM_USART_CTRLB_TXEN | SERCOM_USART_CTRLB_RXEN ;
}

void coreSercomResetUART(uint8_t sercom)
{
  // Start the Software Reset
  sercoms[sercom]->USART.CTRLA.bit.SWRST = 1 ;

  while ( sercoms[sercom]->USART.CTRLA.bit.SWRST || sercoms[sercom]->USART.SYNCBUSY.bit.SWRST )
  {
    // Wait for both bits Software Reset from CTRLA and SYNCBUSY coming back to 0
  }
}

void coreSercomEnableUART(uint8_t sercom)
{
  //Setting  the coreSercomEnable bit to 1
  sercoms[sercom]->USART.CTRLA.bit.ENABLE = 0x1u;

  //Wait for then coreSercomEnable bit from SYNCBUSY is equal to 0;
  while(sercoms[sercom]->USART.SYNCBUSY.bit.ENABLE);
}

void coreSercomFlushUART(uint8_t sercom)
{
  // Wait for transmission to complete
  while(!sercoms[sercom]->USART.INTFLAG.bit.TXC);
}

void coreSercomClearStatusUART(uint8_t sercom)
{
  //Reset (with 0) the STATUS register
  sercoms[sercom]->USART.STATUS.reg = SERCOM_USART_STATUS_RESETVALUE;
}

bool coreSercomAvailableDataUART(uint8_t sercom)
{
  //RXC : Receive Complete
  return sercoms[sercom]->USART.INTFLAG.bit.RXC;
}

bool coreSercomIsUARTError(uint8_t sercom)
{
  return sercoms[sercom]->USART.INTFLAG.bit.ERROR;
}

void coreSercomAcknowledgeUARTError(uint8_t sercom)
{
  //sercoms[sercom]->USART.INTFLAG.bit.ERROR = 1;
}

bool coreSercomIsBufferOverflowErrorUART(uint8_t sercom)
{
  //BUFOVF : Buffer Overflow
  return sercoms[sercom]->USART.STATUS.bit.BUFOVF;
}

bool coreSercomIsFrameErrorUART(uint8_t sercom)
{
  //FERR : Frame Error
  return sercoms[sercom]->USART.STATUS.bit.FERR;
}

bool coreSercomIsParityErrorUART(uint8_t sercom)
{
  //PERR : Parity Error
  return sercoms[sercom]->USART.STATUS.bit.PERR;
}

bool coreSercomIsDataRegisterEmptyUART(uint8_t sercom)
{
  //DRE : Data Register Empty
  return sercoms[sercom]->USART.INTFLAG.bit.DRE;
}

uint8_t coreSercomReadDataUART(uint8_t sercom)
{
  return sercoms[sercom]->USART.DATA.bit.DATA;
}

int coreSercomWriteDataUART(uint8_t sercom, uint8_t data)
	{
	// Wait for data register to be empty
	while (!coreSercomIsDataRegisterEmptyUART(sercom))
		;

	//Put data into DATA register
	sercoms[sercom]->USART.DATA.reg = (uint16_t)data;
	return 1;
	}

/*	=========================
 *	===== Sercom SPI
 *	=========================
*/
void coreSercomInitSPI(uint8_t sercom, SercomSpiTXPad mosi, SercomRXPad miso, SercomSpiCharSize charSize, SercomDataOrder dataOrder)
{
  coreSercomResetSPI(sercom);
  coreSercomInitClockNVIC(sercom);

  //Setting the CTRLA register
  sercoms[sercom]->SPI.CTRLA.reg = SERCOM_SPI_CTRLA_MODE_SPI_MASTER |
                          SERCOM_SPI_CTRLA_DOPO(mosi) |
                          SERCOM_SPI_CTRLA_DIPO(miso) |
                          dataOrder << SERCOM_SPI_CTRLA_DORD_Pos;

  //Setting the CTRLB register
  sercoms[sercom]->SPI.CTRLB.reg = SERCOM_SPI_CTRLB_CHSIZE(charSize) |
                          SERCOM_SPI_CTRLB_RXEN;	//Active the SPI receiver.


}

void coreSercomInitSPIClock(uint8_t sercom, SercomSpiClockMode clockMode, uint32_t baudrate)
{
  //Extract data from clockMode
  int cpha, cpol;

  if((clockMode & (0x1ul)) == 0 )
    cpha = 0;
  else
    cpha = 1;

  if((clockMode & (0x2ul)) == 0)
    cpol = 0;
  else
    cpol = 1;

  //Setting the CTRLA register
  sercoms[sercom]->SPI.CTRLA.reg |=	( cpha << SERCOM_SPI_CTRLA_CPHA_Pos ) |
                            ( cpol << SERCOM_SPI_CTRLA_CPOL_Pos );

  //Synchronous arithmetic
  sercoms[sercom]->SPI.BAUD.reg = coreSercomCalculateBaudrateSynchronous(baudrate);
}

void coreSercomResetSPI(uint8_t sercom)
{
  //Setting the Software Reset bit to 1
  sercoms[sercom]->SPI.CTRLA.bit.SWRST = 1;

  //Wait both bits Software Reset from CTRLA and SYNCBUSY are equal to 0
  while(sercoms[sercom]->SPI.CTRLA.bit.SWRST || sercoms[sercom]->SPI.SYNCBUSY.bit.SWRST);
}

void coreSercomEnableSPI(uint8_t sercom)
{
  //Setting the coreSercomEnable bit to 1
  sercoms[sercom]->SPI.CTRLA.bit.ENABLE = 1;

  while(sercoms[sercom]->SPI.SYNCBUSY.bit.ENABLE)
  {
    //Waiting then coreSercomEnable bit from SYNCBUSY is equal to 0;
  }
}

void coreSercomDisableSPI(uint8_t sercom)
{
  //Setting the coreSercomEnable bit to 0
  sercoms[sercom]->SPI.CTRLA.bit.ENABLE = 0;

  while(sercoms[sercom]->SPI.SYNCBUSY.bit.ENABLE)
  {
    //Waiting then coreSercomEnable bit from SYNCBUSY is equal to 0;
  }
}

void coreSercomSetDataOrderSPI(uint8_t sercom, SercomDataOrder dataOrder)
{
  //Register coreSercomEnable-protected
  coreSercomDisableSPI(sercom);

  sercoms[sercom]->SPI.CTRLA.bit.DORD = dataOrder;

  coreSercomEnableSPI(sercom);
}

SercomDataOrder coreSercomGetDataOrderSPI(uint8_t sercom)
{
  return (sercoms[sercom]->SPI.CTRLA.bit.DORD ? LSB_FIRST : MSB_FIRST);
}

void coreSercomSetBaudrateSPI(uint8_t sercom, uint8_t divider)
{
  //Can't divide by 0
  if(divider == 0)
    return;

  //Register coreSercomEnable-protected
  coreSercomDisableSPI(sercom);

  sercoms[sercom]->SPI.BAUD.reg = coreSercomCalculateBaudrateSynchronous( SERCOM_CLOCK / divider );

  coreSercomEnableSPI(sercom);
}

void coreSercomSetClockModeSPI(uint8_t sercom, SercomSpiClockMode clockMode)
{
  int cpha, cpol;
  if((clockMode & (0x1ul)) == 0)
    cpha = 0;
  else
    cpha = 1;

  if((clockMode & (0x2ul)) == 0)
    cpol = 0;
  else
    cpol = 1;

  //Register coreSercomEnable-protected
  coreSercomDisableSPI(sercom);

  sercoms[sercom]->SPI.CTRLA.bit.CPOL = cpol;
  sercoms[sercom]->SPI.CTRLA.bit.CPHA = cpha;

  coreSercomEnableSPI(sercom);
}

void coreSercomWriteDataSPI(uint8_t sercom, uint8_t data)
{
  while( sercoms[sercom]->SPI.INTFLAG.bit.DRE == 0 )
  {
    // Waiting Data Registry Empty
  }

  sercoms[sercom]->SPI.DATA.bit.DATA = data; // Writing data into Data register

  while( sercoms[sercom]->SPI.INTFLAG.bit.TXC == 0 || sercoms[sercom]->SPI.INTFLAG.bit.DRE == 0 )
  {
    // Waiting Complete Transmission
  }
}

uint16_t coreSercomReadDataSPI(uint8_t sercom)
{
  while( sercoms[sercom]->SPI.INTFLAG.bit.DRE == 0 || sercoms[sercom]->SPI.INTFLAG.bit.RXC == 0 )
  {
    // Waiting Complete Reception
  }

  return sercoms[sercom]->SPI.DATA.bit.DATA;  // Reading data
}

bool coreSercomIsBufferOverflowErrorSPI(uint8_t sercom)
{
  return sercoms[sercom]->SPI.STATUS.bit.BUFOVF;
}

bool coreSercomIsDataRegisterEmptySPI(uint8_t sercom)
{
  //DRE : Data Register Empty
  return sercoms[sercom]->SPI.INTFLAG.bit.DRE;
}

//bool coreSercomIsTransmitCompleteSPI(uint8_t sercom)
//{
//	//TXC : Transmit complete
//	return sercoms[sercom]->SPI.INTFLAG.bit.TXC;
//}
//
//bool coreSercomIsReceiveCompleteSPI(uint8_t sercom)
//{
//	//RXC : Receive complete
//	return sercoms[sercom]->SPI.INTFLAG.bit.RXC;
//}

uint8_t coreSercomcoreSercomCalculateBaudrateSynchronous(uint8_t sercom, uint32_t baudrate)
{
  return SERCOM_CLOCK / (2 * baudrate) - 1;
}


/*	=========================
 *	===== Sercom I2C
 *	=========================
 */
void coreSercomResetI2C(uint8_t sercom)
	{
	//I2CM OR I2CS, no matter SWRST is the same bit.

	//Setting the Software bit to 1
	sercoms[sercom]->I2CM.CTRLA.bit.SWRST = 1;

	//Wait both bits Software Reset from CTRLA and SYNCBUSY are equal to 0
	while(sercoms[sercom]->I2CM.CTRLA.bit.SWRST || sercoms[sercom]->I2CM.SYNCBUSY.bit.SWRST)
  		;
	}

void coreSercomEnableI2C(uint8_t sercom)
	{
	// I2C Master and Slave modes share the ENABLE bit function.

	// Enable the I2C master mode
	sercoms[sercom]->I2CM.CTRLA.bit.ENABLE = 1 ;

	while ( sercoms[sercom]->I2CM.SYNCBUSY.bit.ENABLE != 0 )
		{
    // Waiting the coreSercomEnable bit from SYNCBUSY is equal to 0;
	}

  // Setting bus idle mode
  sercoms[sercom]->I2CM.STATUS.bit.BUSSTATE = 1 ;

  while ( sercoms[sercom]->I2CM.SYNCBUSY.bit.SYSOP != 0 )
  {
    // Wait the SYSOP bit from SYNCBUSY coming back to 0
  }
}

void coreSercomDisableI2C(uint8_t sercom)
{
  // I2C Master and Slave modes share the ENABLE bit function.

  // Enable the I�C master mode
  sercoms[sercom]->I2CM.CTRLA.bit.ENABLE = 0 ;

  while ( sercoms[sercom]->I2CM.SYNCBUSY.bit.ENABLE != 0 )
  {
    // Waiting the coreSercomEnable bit from SYNCBUSY is equal to 0;
  }
}

void coreSercomInitSlaveI2C(uint8_t sercom, uint8_t ucAddress)
	{
	// Initialize the peripheral clock and interruption
	coreSercomInitClockNVIC(sercom);
	coreSercomResetI2C(sercom);

	// Set slave mode
	sercoms[sercom]->I2CS.CTRLA.bit.MODE = kI2CSlaveOperation ;

	sercoms[sercom]->I2CS.ADDR.reg = SERCOM_I2CS_ADDR_ADDR( ucAddress & 0x7Ful ) | // 0x7F, select only 7 bits
                          SERCOM_I2CS_ADDR_ADDRMASK( 0x00ul ) ;         // 0x00, only match exact address

	// Set the interrupt register
	sercoms[sercom]->I2CS.INTENSET.reg = SERCOM_I2CS_INTENSET_PREC |   // Stop
                              SERCOM_I2CS_INTENSET_AMATCH | // Address Match
                              SERCOM_I2CS_INTENSET_DRDY ;   // Data Ready

	while ( sercoms[sercom]->I2CM.SYNCBUSY.bit.SYSOP != 0 )
  		{
    	// Wait the SYSOP bit from SYNCBUSY to come back to 0
  		}
	}

void coreSercomInitMasterI2C(uint8_t sercom, uint32_t baudrate )
	{
	// Initialize the peripheral clock and interruption
	//coreSercomInitClockNVIC(sercom);

	coreSercomResetI2C(sercom);

	// Set master mode and enable SCL Clock Stretch mode (stretch after ACK bit)
	sercoms[sercom]->I2CM.CTRLA.reg =  SERCOM_I2CM_CTRLA_MODE( kI2CMasterOperation )/* |
                            SERCOM_I2CM_CTRLA_SCLSM*/ ;

	// Enable Smart mode and Quick Command
	//sercoms[sercom]->I2CM.CTRLB.reg =  SERCOM_I2CM_CTRLB_SMEN /*| SERCOM_I2CM_CTRLB_QCEN*/ ;


	// Enable all interrupts
	//  sercoms[sercom]->I2CM.INTENSET.reg = SERCOM_I2CM_INTENSET_MB | SERCOM_I2CM_INTENSET_SB | SERCOM_I2CM_INTENSET_ERROR ;

	// Synchronous arithmetic baudrate
	sercoms[sercom]->I2CM.BAUD.bit.BAUD = SERCOM_CLOCK / ( 2 * baudrate) - 1 ;
	}

void coreSercomPrepareNackBitI2C(uint8_t sercom)
{
  if (coreSercomIsMasterI2C(sercom)) {
    // Send a NACK
    sercoms[sercom]->I2CM.CTRLB.bit.ACKACT = 1;
  } else {
    sercoms[sercom]->I2CS.CTRLB.bit.ACKACT = 1;
  }
}

void coreSercomPrepareAckBitI2C(uint8_t sercom)
{
  if (coreSercomIsMasterI2C(sercom)) {
    // Send an ACK
    sercoms[sercom]->I2CM.CTRLB.bit.ACKACT = 0;
  } else {
    sercoms[sercom]->I2CS.CTRLB.bit.ACKACT = 0;
  }
}

void coreSercomPrepareCommandBitsI2C(uint8_t sercom, uint8_t cmd)
{
  if (coreSercomIsMasterI2C(sercom)) {
    sercoms[sercom]->I2CM.CTRLB.bit.CMD = cmd;

    while(sercoms[sercom]->I2CM.SYNCBUSY.bit.SYSOP)
    {
      // Waiting for synchronization
    }
  } else {
    sercoms[sercom]->I2CS.CTRLB.bit.CMD = cmd;
  }
}

bool coreSercomStartTransmissionI2C(uint8_t sercom, uint8_t address, SercomWireReadWriteFlag flag)
{
  address |= flag;
  // 7-bits address + 1-bits R/W
 // address = (address << 0x1ul) | flag;

  // Wait idle or owner bus mode
  while (!coreSercomIsBusIdleI2C(sercom) && !coreSercomIsBusOwnerI2C(sercom))
  	;

  // Send start and address
  sercoms[sercom]->I2CM.ADDR.bit.ADDR = address;

  // Address Transmitted
  if ( flag == I2C_WRITE_FLAG ) // Write mode
  {
    //while( !sercoms[sercom]->I2CM.INTFLAG.bit.MB )
    if( !sercoms[sercom]->I2CM.INTFLAG.bit.MB )
    {
      return false;
    }
  }
  else  // Read mode
  {
    while( !sercoms[sercom]->I2CM.INTFLAG.bit.SB )
    {
        // If the slave NACKS the address, the MB bit will be set.
        // In that case, send a stop condition and return false.
        if (sercoms[sercom]->I2CM.INTFLAG.bit.MB) {
            sercoms[sercom]->I2CM.CTRLB.bit.CMD = 3; // Stop condition
            return false;
        }
      // Wait transmission complete
    }

    // Clean the 'Slave on Bus' flag, for further usage.
    //sercoms[sercom]->I2CM.INTFLAG.bit.SB = 0x1ul;
  }


  //ACK received (0: ACK, 1: NACK)
  if(sercoms[sercom]->I2CM.STATUS.bit.RXNACK)
  {
    return false;
  }
  else
  {
    return true;
  }
}

bool coreSercomSendDataMasterI2C(uint8_t sercom, uint8_t data)
{
  //Send data
  sercoms[sercom]->I2CM.DATA.bit.DATA = data;

  //Wait transmission successful
  while(!sercoms[sercom]->I2CM.INTFLAG.bit.MB) {

    // If a bus error occurs, the MB bit may never be set.
    // Check the bus error bit and bail if it's set.
    if (sercoms[sercom]->I2CM.STATUS.bit.BUSERR) {
      return false;
    }
  }

  //Problems on line? nack received?
  if(sercoms[sercom]->I2CM.STATUS.bit.RXNACK)
    return false;
  else
    return true;
}

bool coreSercomSendDataSlaveI2C(uint8_t sercom, uint8_t data)
	{
	//Send data
	sercoms[sercom]->I2CS.DATA.bit.DATA = data;

	//Wait data transmission successful
	while(!sercoms[sercom]->I2CS.INTFLAG.bit.DRDY)
		;

	//Problems on line? nack received?
	if (sercoms[sercom]->I2CS.STATUS.bit.RXNACK)
		return false;
	else
		return true;
	}

bool coreSercomIsMasterI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CS.CTRLA.bit.MODE == kI2CMasterOperation;
}

bool coreSercomIsSlaveI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CS.CTRLA.bit.MODE == kI2CSlaveOperation;
}

bool coreSercomIsBusIdleI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CM.STATUS.bit.BUSSTATE == I2C_IDLE_STATE;
}

bool coreSercomIsBusOwnerI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CM.STATUS.bit.BUSSTATE == I2C_OWNER_STATE;
}

bool coreSercomIsDataReadyI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CS.INTFLAG.bit.DRDY;
}

bool coreSercomIsStopDetectedI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CS.INTFLAG.bit.PREC;
}

bool coreSercomIsRestartDetectedI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CS.STATUS.bit.SR;
}

bool coreSercomIsAddressMatchI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CS.INTFLAG.bit.AMATCH;
}

bool coreSercomIsMasterReadOperationI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CS.STATUS.bit.DIR;
}

bool coreSercomIsRXNackReceivedI2C(uint8_t sercom)
{
  return sercoms[sercom]->I2CM.STATUS.bit.RXNACK;
}

int coreSercomAvailableI2C(uint8_t sercom)
{
  if (coreSercomIsMasterI2C(sercom))
    return sercoms[sercom]->I2CM.INTFLAG.bit.SB;
  else
    return sercoms[sercom]->I2CS.INTFLAG.bit.DRDY;
}

uint8_t coreSercomReadDataI2C(uint8_t sercom)
{
  if (coreSercomIsMasterI2C(sercom))
  {
    while( sercoms[sercom]->I2CM.INTFLAG.bit.SB == 0 )
    {
      // Waiting complete receive
    }

    return sercoms[sercom]->I2CM.DATA.bit.DATA ;
  }
  else
  {
    return sercoms[sercom]->I2CS.DATA.reg ;
  }
}


void coreSercomInitClockNVIC(uint8_t sercom)
	{
	uint8_t clockId = 0;
	IRQn_Type IdNvic=PendSV_IRQn ; // Dummy init to intercept potential error later

	switch (sercom)
		{
		case kSERCOM0:
		    clockId = GCM_SERCOM0_CORE;
			IdNvic = SERCOM0_IRQn;
			break;
			
		case kSERCOM1:
		    clockId = GCM_SERCOM1_CORE;
			IdNvic = SERCOM1_IRQn;
			break;
			
		case kSERCOM2:
		    clockId = GCM_SERCOM2_CORE;
			IdNvic = SERCOM2_IRQn;
			break;
			
		case kSERCOM3:
		    clockId = GCM_SERCOM3_CORE;
			IdNvic = SERCOM3_IRQn;
			break;
			
		case kSERCOM4:
		    clockId = GCM_SERCOM4_CORE;
			IdNvic = SERCOM4_IRQn;
			break;
			
		case kSERCOM5:
		    clockId = GCM_SERCOM5_CORE;
			IdNvic = SERCOM5_IRQn;
			break;
		
		default:
			break;
			
		}

	// Setting NVIC
	NVIC_EnableIRQ(IdNvic);
	NVIC_SetPriority (IdNvic, (1<<__NVIC_PRIO_BITS) - 1);  /* set Priority */

	//Setting clock
	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID( clockId ) | // Generic Clock 0 (SERCOMx)
                      GCLK_CLKCTRL_GEN_GCLK0 | // Generic Clock Generator 0 is source
                      GCLK_CLKCTRL_CLKEN ;

	while ( GCLK->STATUS.reg & GCLK_STATUS_SYNCBUSY )
		{
		//	Wait for synchronization
		}
	}
