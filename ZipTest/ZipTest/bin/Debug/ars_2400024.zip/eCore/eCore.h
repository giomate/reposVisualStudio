/*--------------------------------------------------------------------------

eCore.h

This file is part of e.Development

Interface
Common includes for the eCore C library

$Date: 2017-02-27 09:47:26 +0100 (Mo, 27 Feb 2017) $
$Revision: 1324 $

Copyright (c) 2006,2007, 2009, 2010 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#ifndef CORE_E_CORE_H
#define CORE_E_CORE_H


#ifdef __cplusplus
extern "C" {
#endif

//#include <stdint.h>
//#include <stdbool.h>
//#include <string.h>

//#include "coreTypes.h"
#include "coreADConverter.h"
#include "coreController.h"
#include "corePorts.h"
#include "coreAsyncSerial.h"
	
#ifdef USB_SUPPORT	
	#include "coreUSB.h"
#endif
//#include "coreSPI.h"
//#include "coreRTC.h"
#include "coreSystemTimer.h"
//#include "coreCAN.h"
#include "corePWM.h"

void eCoreInitialize(void);




#define cpu_irq_enable()				\
do {                                \
	__DMB();                        \
	__enable_irq();                 \
} while (0)

#define cpu_irq_disable()				\
do {                                \
	__disable_irq();                \
	__DMB();                        \
} while (0)


#define MIN(a,b)			(((a)<(b))?(a):(b))
#ifdef __cplusplus
}
#endif


#endif

