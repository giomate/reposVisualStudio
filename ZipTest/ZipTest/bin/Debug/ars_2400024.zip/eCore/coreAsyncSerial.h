/*--------------------------------------------------------------------------

coreAsyncSerial.h

This file is part of e.Core

Interface
low level interface to the ARM7 Asynchronous serial controller

$Date: 2017-06-07 11:15:35 +0200 (Mi, 07 Jun 2017) $
$Revision: 1481 $

--------------------------------------------------------------------------*/
#ifndef CORE_ASYNC_SERIAL_H
#define CORE_ASYNC_SERIAL_H

#ifdef __cplusplus
extern "C" {
#endif

#include "coreTypes.h"

/**
	Constants for on-chip UARTS
*/
enum
	{
	kUART0 = 0,	//!	UART0
	kUART1,
	kUART2,
	kUART3,
	kUART4,
	kUART5,
	kNumberOfUARTS
	};

/** Initialize async serial subsystem
*/
int8 coreAsyncSerialInitialize(void);

/** Configure uart
*/
int8_t coreAsyncSerialConfigure(uint8 uart, uint32_t baudrate, uint8 bits, uint8 stop, uint8 parity);
/** Open uart
*/
int8_t coreAsyncSerialOpen(uint8 uart);

/** Close uart
*/
int8 coreAsyncSerialClose(uint8 uart);

/**
	Check if there is any data available.
	\returns Number of bytes available
*/
uint16 coreAsyncSerialDataAvailable(uint8 uart);

/**
	Peek for the next byte in stream.
	This function doesn't change the read pointer, so you have to call
	\ref coreAsyncSerialRead anyway.
	\returns Next byte if  data available, 0 else.
*/
uint8 coreAsyncSerialPeek(uint8 uart);

/**
	Read <n> byte in stream.
	\returns Number of bytes read
*/
uint16 coreAsyncSerialRead(uint8 uart, void* p, uint16 n, time_t timeout);

/**
	Read one byte from stream.
*/
uint8 coreAsyncSerialReadByte(uint8 uart, time_t timeout);

/**
	Write one byte to stream.
*/
void coreAsyncSerialWriteByte(uint8 uart, uint8);

/**
	Writes <n> byte to stream.
	\returns Number of bytes written
*/
uint16 coreAsyncSerialWriteAsync(uint8 uart, const void* p, uint16 n);

/**
	Writes <n> byte to stream.
	\returns Number of bytes written
*/
uint16 coreAsyncSerialWrite(uint8 uart, const void* p, uint16 n);

/**
	Writes a C-string to stream.
	\returns Number of bytes written
*/
uint16 coreAsyncSerialWriteString(uint8 uart, const char* p);

void coreAsyncSerialWriteDataAsHexString(uint8_t usartID, const void* v, int n, bool writeSpace);

#ifdef __cplusplus
	}
#endif

#endif

