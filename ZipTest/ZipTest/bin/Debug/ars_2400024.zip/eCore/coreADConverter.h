/*--------------------------------------------------------------------------

coreADConverter.h

This file is part of e.Core

Interface
low level interface to the LPC2468 internal A/D converter

$Date: 2016-10-24 09:50:09 +0200 (Mo, 24 Okt 2016) $
$Revision: 984 $

Copyright (c) 2006,2007,2008,2009, 2012 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#ifndef CORE_AD_CONVERTER_H
#define CORE_AD_CONVERTER_H
#ifdef __cplusplus
extern "C" {
	#endif


#include "coreTypes.h"


/**
 * \defgroup AnalogIn Analoge Eing�nge
*/
/*@{*/
/**	Constants for auto trigger source
	\sa coreADConverterEnableAutoTrigger
*/
typedef enum
	{
	kNoAutoTrigger = 0,				//!<	Auto trigger off
	kFreeRunningMode,				//!<	Free Running mode
	kAnalogComparator,				//!<	Analog Comparator
	kExternalInterruptRequest0,		//!<	External Interrupt Request 0
	kTimerCounter0CompareMatch,		//!<	Timer/Counter0 Compare Match
	kTimerCounter0Overflow,			//!<	Timer/Counter0 Overflow
	kTimerCounter1CompareMatchB,	//!<	Timer/Counter1 Compare Match B
	kTimerCounter1Overflow,			//!<	Timer/Counter1 Overflow
	kTimerCounter1CaptureEvent		//!<	Timer/Counter1 Capture Event
	} analogAutoTriggerSource;

/**	Constants for oversampling of the analogue inputs
	\sa coreADConverterReadSingle, coreADConverterReadArray, coreADConverterEnableAutoTrigger
*/
typedef enum
	{
	kNoOversampling = 0,	//!< Single conversion, no oversampling
	kOversampling4 = 1,		//!< 4-times oversampling => 1 bit enhancement (4^1)
	kOversampling16 = 2,	//!< 16-times oversampling => 2 bit enhancement (4^2)
	kOversampling64 = 3,	//!< 64-times oversampling => 3 bit enhancement (4^3)
	kOversampling256 = 4	//!< 256-times oversampling => 4 bit enhancement (4^4)
	} analogOversampling;

/** Konstanten f�r die digitalen Ein-/Ausg�nge
	\sa analogIn()
*/
typedef enum
	{
	kAnalogPort0 = 0,	//!< Analogeingang 1
	kAnalogPort1 = 1,	//!< Analogeingang 2
	kAnalogPort2 = 2,	//!< Analogeingang 3
	kAnalogPort3 = 3,	//!< Analogeingang 4
	kAnalogPort4 = 4,	//!< Analogeingang 5
	kAnalogPort5 = 5,	//!< Analogeingang 6
	kAnalogPort6 = 6,	//!< Analogeingang 7
	kAnalogPort7 = 7,	//!< Analogeingang 8
#if ICB_Revision >= 0x0100
	kAnalogPort8 = 8,	//!< Analogeingang 1
	kAnalogPort9 = 9,	//!< Analogeingang 2
	kAnalogPort10 = 10,	//!< Analogeingang 3
	kAnalogPort11 = 11,	//!< Analogeingang 4
	kAnalogPort12 = 12,	//!< Analogeingang 5
	kAnalogPort13 = 13,	//!< Analogeingang 6
	kAnalogPort14 = 14,	//!< Analogeingang 7
#endif
	} analogPinValues;
/** Bit-Konstanten f�r die Analogeing�nge
	\sa analogIn()
*/
typedef enum
	{
	kBitAnalog0 = (1 << 0),	//!< Analogeingang 1
	kBitAnalog1 = (1 << 1),	//!< Analogeingang 2
	kBitAnalog2 = (1 << 2),	//!< Analogeingang 3
	kBitAnalog3 = (1 << 3),	//!< Analogeingang 4
	kBitAnalog4 = (1 << 4),	//!< Analogeingang 5
	kBitAnalog5 = (1 << 5),	//!< Analogeingang 6
	kBitAnalog6 = (1 << 6),	//!< Analogeingang 7
	kBitAnalog7 = (1 << 7),	//!< Analogeingang 8
#if ICB_Revision >= 0x0100
	kBitAnalog8 = (1 << 8),	//!< Analogeingang 8
	kBitAnalog9 = (1 << 9),	//!< Analogeingang 8
	kBitAnalog10 = (1 << 10),	//!< Analogeingang 8
	kBitAnalog11 = (1 << 11),	//!< Analogeingang 8
	kBitAnalog12 = (1 << 12),	//!< Analogeingang 8
	kBitAnalog13 = (1 << 13),	//!< Analogeingang 8
	kBitAnalog14 = (1 << 14),	//!< Analogeingang 8
	kBitAnalogAll = 0x7FFF		//!< Alle Analogeing�nge
#else
	kBitAnalogAll = 0xFF		//!< Alle Analogeing�nge
#endif
	} analogBitValues;
	

/*@}*/

/** \addtogroup AnalogIn
*/
/*@{*/
/** A/D converter interface initializer
*/
void coreADConverterInitialize(void);
void coreADConverterRelease(void);

void coreADConverterOpen(void);
void coreADConverterClose(void);

void coreADConverterSelectChannel(uint8 channel);
int16 coreADConverterReadSingle(void);

void coreADConverterSetOversampling(uint8 oversampling);


void coreADConverterReadArray(uint16 bits, int16 results[], uint8 oversampling);

uint8 coreADConverterGetResolution(void);

int16 coreADConverterGetMaximumValue(void);

void coreADCPortConfigure( uint8,  uint8);

/*@}*/

#ifdef __cplusplus
}
#endif

#endif

