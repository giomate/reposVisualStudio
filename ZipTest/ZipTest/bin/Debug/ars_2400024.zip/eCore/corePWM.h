/*--------------------------------------------------------------------------

corePWM.h

This file is part of e.Core

Interface
low level interface to PWM functionality

$Date: 2016-11-07 09:07:35 +0100 (Mo, 07 Nov 2016) $
$Revision: 1080 $

Copyright (c) 2006,2007,2010, 2014 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#ifndef CORE_PWM_H
#define CORE_PWM_H

#ifdef __cplusplus
extern "C" {
#endif

#include "coreTypes.h"
//#include "coreInterfaceDescription.h"

/**
 * \defgroup PWMOut PWM-Ausg�nge
*/
/*@{*/

/** Konstanten f�r die PWM-Ausg�nge
*/
typedef enum
	{
	kPWMUnit0 = 0,	//!< PWM unit 1
/*
	kPWMUnit1 = 1,	//!< PWM unit 2
	kPWMUnit2 = 2,	//!< PWM unit 3
	kPWMUnit3 = 3,	//!< PWM unit 4
	kPWMUnit4 = 4,	//!< PWM unit 5
	kPWMUnit5 = 5,	//!< PWM unit 6
	kPWMUnit6 = 6,	//!< PWM unit 7
	kPWMUnit7 = 7,	//!< PWM unit 8
*/
	kPWMUnitCount
	} pwmUnit;

typedef enum
	{
	kPWMChannel0 = 0,		//!< PWM channel 1
	kPWMChannel1 = 1,		//!< PWM channel 2
	kPWMChannel2 = 2,		//!< PWM channel 3
	kPWMChannel3 = 3,		//!< PWM channel 4
	kPWMChannel4 = 4,		//!< PWM channel 5
	kPWMChannel5 = 5,		//!< PWM channel 6
	kPWMChannel6 = 6,		//!< PWM channel 7
	kPWMChannel7 = 7,		//!< PWM channel 8
	kPWMChannelCount
	} pwmChannel;

typedef enum
	{
	kPWM0 = 0,		//!< PWM pin 1
/*
	kPWM1,			//!< PWM pin 2
	kPWM2,			//!< PWM pin 3
	kPWM3,			//!< PWM pin 4
	kPWM4,			//!< PWM pin 5
	kPWM5,			//!< PWM pin 6
	kPWM6,			//!< PWM pin 7
	kPWM7,			//!< PWM pin 8
	kPWM8,			//!< PWM pin 9
	kPWM9,			//!< PWM pin 10
*/
	kPWMPinCount
	} pwmPin;

typedef struct
	{
	pwmUnit		unit;
	pwmChannel	channel;
	} corePWMPinDescription;

typedef uint32	pwmFrequency;

extern const corePWMPinDescription corePWMPinList[];

void corePWMInitialize(void);

/** \addtogroup PWMOut
*/
/*@{*/
void corePWMSetUnitFrequency(pwmUnit unit, pwmFrequency frequency);

/*
bool corePWMOpen(pwmUnit uint, pwm channel);

bool corePWMClose(pwmPin pin);
*/
void corePWMSetDutyCycle(pwmPin pin, float dutyCycle);

float corePWMGetDutyCycle(pwmPin pin);

void corePWMSetStateOn(pwmPin pin);

void corePWMSetStateOff(pwmPin pin);

bool corePWMGetState(pwmPin pin);

/*@}*/

#ifdef __cplusplus
	}
#endif

#endif

