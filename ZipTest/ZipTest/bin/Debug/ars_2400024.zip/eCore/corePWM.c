/*--------------------------------------------------------------------------

corePWM.cc

This file is part of e.Development

Implementation
low level interface to the ATMega128 PWM controller

$Author: steffen $
$Date: 2016-11-07 09:07:35 +0100 (Mo, 07 Nov 2016) $
$Revision: 1080 $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/Libraries/Cortex/e.Core/corePWM.c $

Copyright (c) 2006,2007,2010 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#include "sam.h"
#include "corePWM.h"

#define PWM_TIMER_CLOCK		8000000UL
#ifndef PWM_TIMER_CLOCK
#define PWM_TIMER_CLOCK		F_CPU
#endif

const corePWMPinDescription	corePWMPinList[] =
	{
		{kPWMUnit0, kPWMChannel2},
	};

typedef struct
	{
	float	dutyCycle;
	bool	state;
	} pwmPinStructure;

static	pwmPinStructure	pwmPins[kPWMPinCount];

typedef struct
	{
	Tcc*	TCC;
	uint32	period;
	} pwmUnitStructure;

static	pwmUnitStructure	pwmUnits[kPWMUnitCount] =
	{
		{TCC0, 0},
	};

void corePWMInitialize(void)
	{
	uint8	i;
	
	for (i=0; i<kPWMPinCount; i++)
		{
		pwmPins[i].state = false;
		pwmPins[i].dutyCycle = 0.0;
		// Set duty cycle of 0%
		}
		
	// - Set PA18 (LED) as TCC0 Waveform out ( : F = 0x05)
	PORT->Group[0].WRCONFIG.reg |= 0xD5010004;

	// PORT->Group[0].WRCONFIG.reg = (PORT_WRCONFIG_HWSEL | PORT_WRCONFIG_WRPINCFG | PORT_WRCONFIG_WRPMUX | 1 << (30 - 16) | PORT_WRCONFIG_PMUXEN | (0x4 << PORT_WRCONFIG_PMUX_Pos) );
//	PORT->Group[0].WRCONFIG.reg =(PORT_WRCONFIG_PMUXEN|PORT_WRCONFIG_PMUX(MUX_PA18F_TCC0_WO2)|PORT_WRCONFIG_WRPMUX
	//							|PORT_WRCONFIG_HWSEL|PORT_WRCONFIG_PINMASK(PORT_PA18F_TCC0_WO2))&PORT_WRCONFIG_MASK;
							

	// - Enable TCC0 Bus clock (Timer counter control clock)
	PM->APBCMASK.reg |= PM_APBCMASK_TCC0;		//	Enable TCC0
	//Enable GCLK for TCC0 (timer counter input clock)
	GCLK->CLKCTRL.reg =(GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_GEN_GCLK3 |GCLK_CLKCTRL_ID_TCC0_TCC1);

	/* -- Initialize TCC0 */
	// - DISABLE TCC0
	//	TCC0->CTRLA.reg &=~(TCC_CTRLA_ENABLE);
	// - Set TCC0 in waveform mode Normal PWM
	// TCC0->WAVE.reg |= TCC_WAVE_WAVEGEN_NPWM;
	// - Set PER to maximum counter value (resolution : 0xFF)
	//TCC0->PER.reg = 0xFF;
	// - Set WO[0] compare register to 0xFF (PWM duty cycle = 100%)
	//TCC0->CC[0].reg = 0xFF;
	
	for (i=0; i<kPWMUnitCount; i++)
		{
		pwmUnits[i].TCC->CTRLA.reg &=~(TCC_CTRLA_ENABLE);
		pwmUnits[i].TCC->WAVE.reg |= TCC_WAVE_WAVEGEN_NPWM;
		// Set default frequency to 1kHz
		corePWMSetUnitFrequency(i, 1000);
		}
	}


void corePWMSetUnitFrequency(pwmUnit unit, pwmFrequency frequency)
	{
	if (unit < kPWMUnitCount)
		{
		pwmUnits[unit].period = PWM_TIMER_CLOCK/frequency;
		pwmUnits[unit].TCC->PER.reg = pwmUnits[unit].period;
		}
	}

float corePWMGetDutyCycle(pwmPin pin)
	{
	float	result = 0.0;

	if (pin < kPWMPinCount)
		{
		result = pwmPins[pin].dutyCycle;
		}
	
	return result;
	}		

void corePWMSetDutyCycle(pwmPin pin, float dutyCycle)
	{
	if (pin < kPWMPinCount)
		{
		uint8	unit = corePWMPinList[pin].unit;
		uint8	channel = corePWMPinList[pin].channel;
		
		if (dutyCycle < 0.0)		
     		pwmPins[pin].dutyCycle = 0.0;
		else if (dutyCycle > 100.0)		
     		pwmPins[pin].dutyCycle = 1.0;
		else
     		pwmPins[pin].dutyCycle = dutyCycle/100.0;

		pwmUnits[unit].TCC->CC[channel].reg = (uint32)(pwmPins[pin].dutyCycle * pwmUnits[unit].period);
		}
	}

void corePWMSetStateOn(pwmPin pin)
	{
	if (pin < kPWMPinCount)
		{
		uint8	unit = corePWMPinList[pin].unit;
		uint8	channel = corePWMPinList[pin].channel;
		
		pwmPins[pin].state = true;
		// - ENABLE TCC0
		
		pwmUnits[unit].TCC->CTRLA.reg |= TCC_CTRLA_ENABLE;
		}
	}

void corePWMSetStateOff(pwmPin pin)
	{
#if __DEBUG__ > 4
	char	number[] = "x\r";
	
	//coreAsyncSerialWriteString(kUART0, "corePWMSetPWMOff #");
	number[0] = pin + '0';
	//coreAsyncSerialWriteString(kUART0, number);
#endif	
	if (pin < kPWMPinCount)
		{		
		uint8	unit = corePWMPinList[pin].unit;
		uint8	channel = corePWMPinList[pin].channel;
		
		pwmPins[pin].state = false;
		// - DISABLE TCC0
		pwmUnits[unit].TCC->CTRLA.reg &=~(TCC_CTRLA_ENABLE);
		}
	}

bool corePWMGetState(pwmPin pin)
	{
	bool	result = false;
	
	if (pin < kPWMPinCount)
		{
		if (pwmPins[pin].state)
			result = true;
		}
	
	return result;
	}

