/*--------------------------------------------------------------------------

coreAsyncSerial.c

This file is part of e.Core

Implementation
low level interface to SAMD21 SERCOM/USART

$Author: steffen $
$Date: 2017-06-07 11:15:35 +0200 (Mi, 07 Jun 2017) $
$Revision: 1481 $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/Libraries/Cortex/e.Core/coreAsyncSerial.c $

All rights reserved.

--------------------------------------------------------------------------*/
#include "sam.h"
#include "coreController.h"
#include "coreSystemTimer.h"
#include "coreAsyncSerial.h"
#include "coreTypes.h"

#define CORE_CONFIGURE_SERCOM2
//#define CORE_CONFIGURE_SERCOM3
//#define CORE_CONFIGURE_SERCOM5

#define SERCOM_UART_CLOCK		PCLK
#ifndef SERCOM_UART_CLOCK
#define SERCOM_UART_CLOCK		F_CPU
#endif

#define FIFO

#ifdef FIFO
typedef struct
	{
	uint16	size;
	volatile uint16	head;
	volatile uint16	tail;
	volatile uint8*	buffer;
	} fifoBuffer;

uint16 inuse(const fifoBuffer* f)
	{
	if (f)
		return f->head - f->tail;
	else
		return 0;
	}

void put(fifoBuffer* f, uint8 c)
	{
	if (inuse(f) != f->size)
		{
		f->buffer[f->head++] = c;
		if (f->head >= f->size)
			f->head = 0;
		}
	}

void get(fifoBuffer* f, uint8* c)
	{
	if (inuse(f) != 0)
		{
		*c = f->buffer[f->tail++ % f->size];
		}
	}

void peek(fifoBuffer* f, uint8* c)
	{
	if (inuse(f) != 0)
		{
		*c = f->buffer[f->tail];
		}
	}
#endif

enum uart_pad_settings {
	UART_RX_PAD0_TX_PAD2 = SERCOM_USART_CTRLA_RXPO(0) | SERCOM_USART_CTRLA_TXPO(1),
	UART_RX_PAD1_TX_PAD2 = SERCOM_USART_CTRLA_RXPO(1) | SERCOM_USART_CTRLA_TXPO(1),
	UART_RX_PAD2_TX_PAD0 = SERCOM_USART_CTRLA_RXPO(2),
	UART_RX_PAD3_TX_PAD0 = SERCOM_USART_CTRLA_RXPO(3),
	UART_RX_PAD1_TX_PAD0 = SERCOM_USART_CTRLA_RXPO(1),
	UART_RX_PAD3_TX_PAD2 = SERCOM_USART_CTRLA_RXPO(3) | SERCOM_USART_CTRLA_TXPO(1),

	UART_RX_PAD1_TX_PAD0_RTS_PAD_2_CTS_PAD_3 = SERCOM_USART_CTRLA_RXPO(1) | SERCOM_USART_CTRLA_TXPO(2),
};

typedef struct
	{
#ifdef FIFO
	fifoBuffer			fifo;
#else
	volatile int16_t	uartDataReceived;
	volatile int16_t	uartDataReceivePointer;
	volatile int16_t	uartDataReadPointer;
	int16_t				uartReceiveBufferSize;
	uint8*				uartReceiveBufferPointer;
#endif	
	volatile int16_t	uartDataRemaining;
	const uint8*	uartTransmitBuffer;
	
	Sercom*			SERCOM;
	int32_t			pads;
	IRQn_Type		irq;
	uint8			saved_INTFLAG;
	uint8			uartTransmissionPending;
	} uartData;

#ifdef CORE_CONFIGURE_SERCOM0
uint8	uart0ReceiveBuffer[0x20];
#endif

#ifdef CORE_CONFIGURE_SERCOM1
uint8	uart1ReceiveBuffer[0x20];
#endif

#ifdef CORE_CONFIGURE_SERCOM2
uint8	uart2ReceiveBuffer[0x20];
#endif

#ifdef CORE_CONFIGURE_SERCOM3
uint8	uart3ReceiveBuffer[0x800];
#endif

#ifdef CORE_CONFIGURE_SERCOM4
uint8	uart4ReceiveBuffer[0x100];
#endif

#ifdef CORE_CONFIGURE_SERCOM5
uint8	uart5ReceiveBuffer[0x100];
#endif

static uartData	uarts[] =
	{
#ifdef CORE_CONFIGURE_SERCOM0
	#ifdef FIFO
		{{sizeof(uart0ReceiveBuffer), 0, 0, uart0ReceiveBuffer}, 0, NULL, SERCOM0, UART_RX_PAD3_TX_PAD2, SERCOM0_IRQn},
	#else
		{0, 0, 0, sizeof(uart0ReceiveBuffer), uart0ReceiveBuffer, 0, NULL, SERCOM0, UART_RX_PAD3_TX_PAD2, SERCOM0_IRQn},
	#endif
#else
	#ifdef FIFO
		{{0, 0, 0, NULL}, 0, NULL, SERCOM0},
	#else
		{0, 0, 0, 0, NULL, 0, NULL, SERCOM0},
	#endif
#endif
#ifdef CORE_CONFIGURE_SERCOM1
	#ifdef FIFO
		{{sizeof(uart0ReceiveBuffer), 0, 0, uart1ReceiveBuffer}, 0, NULL, SERCOM1, UART_RX_PAD3_TX_PAD2, SERCOM1_IRQn},
	#else
		{0, 0, 0, sizeof(uart0ReceiveBuffer), uart1ReceiveBuffer, 0, NULL, SERCOM1, UART_RX_PAD3_TX_PAD2, SERCOM1_IRQn},
	#endif
#else
	#ifdef FIFO
		{{0, 0, 0, NULL}, 0, NULL, SERCOM1},
	#else
		{0, 0, 0, 0, NULL, 0, NULL, SERCOM1},
	#endif
#endif
#ifdef CORE_CONFIGURE_SERCOM2
	#ifdef FIFO
		{{sizeof(uart2ReceiveBuffer), 0, 0, uart2ReceiveBuffer}, 0, NULL, SERCOM2, UART_RX_PAD1_TX_PAD0, SERCOM2_IRQn},
	#else
		{0, 0, 0, sizeof(uart2ReceiveBuffer), uart2ReceiveBuffer, 0, NULL, SERCOM2, UART_RX_PAD1_TX_PAD0, SERCOM2_IRQn},
	#endif
#else
	#ifdef FIFO
		{{0, 0, 0, NULL}, 0, NULL, SERCOM2},
	#else
		{0, 0, 0, 0, NULL, 0, NULL, SERCOM2},
	#endif
#endif
#ifdef CORE_CONFIGURE_SERCOM3
	#ifdef FIFO
		{{sizeof(uart3ReceiveBuffer), 0, 0, uart3ReceiveBuffer}, 0, NULL, SERCOM3, UART_RX_PAD3_TX_PAD2, SERCOM3_IRQn},
	#else
		{0, 0, 0, sizeof(uart3ReceiveBuffer), uart3ReceiveBuffer, 0, NULL, SERCOM3, UART_RX_PAD3_TX_PAD2, SERCOM3_IRQn},
	#endif
#else
	#ifdef FIFO
		{{0, 0, 0, NULL}, 0, NULL, SERCOM3},
	#else
		{0, 0, 0, 0, NULL, 0, NULL, SERCOM3},
	#endif
#endif
#ifdef CORE_CONFIGURE_SERCOM4
	#ifdef FIFO
		{{sizeof(uart4ReceiveBuffer), 0, 0, uart4ReceiveBuffer}, 0, NULL, SERCOM4, UART_RX_PAD1_TX_PAD0, SERCOM4_IRQn},
	#else
		{0, 0, 0, sizeof(uart4ReceiveBuffer), uart4ReceiveBuffer, 0, NULL, SERCOM4, UART_RX_PAD1_TX_PAD0, SERCOM4_IRQn},
	#endif
#else
	#ifdef FIFO
		{{0, 0, 0, NULL}, 0, NULL, SERCOM4},
	#else
		{0, 0, 0, 0, NULL, 0, NULL, SERCOM4},
	#endif
#endif
#ifdef CORE_CONFIGURE_SERCOM5
	#ifdef FIFO
		{{sizeof(uart5ReceiveBuffer), 0, 0, uart5ReceiveBuffer}, 0, NULL, SERCOM5, UART_RX_PAD1_TX_PAD0, SERCOM5_IRQn},
	#else
		{0, 0, 0, sizeof(uart5ReceiveBuffer), uart5ReceiveBuffer, 0, NULL, SERCOM5, UART_RX_PAD1_TX_PAD0, SERCOM5_IRQn},
	#endif
#else
	#ifdef FIFO
		{{0, 0, 0, NULL}, 0, NULL, SERCOM5},
	#else
		{0, 0, 0, 0, NULL, 0, NULL, SERCOM5},
	#endif
#endif
	};
	
#ifndef BOOTABLE


static void SERCOM_Handler(uartData* uart)
	{
	//	Read all flags
	uart->saved_INTFLAG = uart->SERCOM->USART.INTFLAG.reg;

	if (uart->SERCOM->USART.INTFLAG.bit.RXC)
		{
		uint16_t	ch;
		
		ch = uart->SERCOM->USART.DATA.reg;
	#ifdef FIFO		
		uint16	offset = (uart->fifo.head++ %  uart->fifo.size);
		uart->fifo.buffer[offset] = ch;
	#else	
		//	Receive Data Available
		uart->uartReceiveBufferPointer[uart->uartDataReceivePointer++] = ch;
		if (uart->uartDataReceivePointer == uart->uartReceiveBufferSize)
			uart->uartDataReceivePointer = 0;
		if (uart->uartDataReceived < uart->uartReceiveBufferSize)
			uart->uartDataReceived++;
	#endif
		}
	
	if (uart->SERCOM->USART.INTFLAG.bit.TXC)
		{
		if (uart->uartDataRemaining > 0)
			{
			uart->SERCOM->USART.DATA.reg = *uart->uartTransmitBuffer++;
			uart->uartDataRemaining--;
			}
		else
			uart->uartTransmissionPending = 0;
		}
	
	//	Clear all flags
	uart->SERCOM->USART.INTFLAG.reg = uart->saved_INTFLAG;
	}

#endif

#ifdef CORE_CONFIGURE_SERCOM0
void SERCOM0_Handler(void)
	{
	SERCOM_Handler(&uarts[0]);
	}
#endif

#ifdef CORE_CONFIGURE_SERCOM1
void SERCOM1_Handler(void)
	{
	SERCOM_Handler(&uarts[1]);
	}
#endif

#ifdef CORE_CONFIGURE_SERCOM2
	#ifndef BOOTABLE


		void SERCOM2_Handler(void)
			{
			SERCOM_Handler(&uarts[2]);
			}
	#endif
#endif

#ifdef CORE_CONFIGURE_SERCOM3
void SERCOM3_Handler(void)
	{
	SERCOM_Handler(&uarts[3]);
	}
#endif

#ifdef CORE_CONFIGURE_SERCOM4
void SERCOM4_Handler(void)
	{
	SERCOM_Handler(&uarts[4]);
	}
#endif

#ifdef CORE_CONFIGURE_SERCOM5
void SERCOM5_Handler(void)
	{
	SERCOM_Handler(&uarts[5]);
	}
#endif

/** Initialize single UART
*/
int8_t coreAsyncSerialInitializeBuffers(uint8 uart);

int8_t coreAsyncSerialInitializeBuffers(uint8 uart)
	{
	int8_t	result = 0;
	
	if (uart < kNumberOfUARTS)
		{
	#ifdef FIFO
		uarts[uart].fifo.head = 0;
		uarts[uart].fifo.tail = 0;
	#else
		uarts[uart].uartDataReceived = 0;
		uarts[uart].uartDataReceivePointer = 0;
		uarts[uart].uartDataReadPointer = 0;
  	#endif
		uarts[uart].uartDataRemaining = 0;
		uarts[uart].uartTransmitBuffer = NULL;
		uarts[uart].uartTransmissionPending = 0;
		}
	else
		result = -1;
	
	return result;
	}

/** Initialize async serial subsystem
*/
/** Initialize async serial subsystem
*/
int8_t coreAsyncSerialInitialize(void)
	{
	int8_t	result = 0;
	uint8_t	i;

	for (i=0; i<kNumberOfUARTS; i++)
		{
		NVIC_DisableIRQ((IRQn_Type)uarts[i].irq);
		NVIC_ClearPendingIRQ((IRQn_Type)uarts[i].irq);
		}

#ifdef CORE_CONFIGURE_SERCOM0
	/* Enable & configure alternate function */
	PORT->Group[0].WRCONFIG.reg = 0x52010C00;	// SERCOM0 PA10 & PA11
	PM->APBCMASK.reg |= (1u << 2);
	//	GCLK->CLKCTRL.reg = 0x4014;	// SERCOM0 0x14
	GCLK->CLKCTRL.reg = 0x4314;	// SERCOM0 0x14
	//coreInterruptsInstallHandler(kUART2Interrupt, kHighestPriority, UART2Handler);
#endif
			
#ifdef CORE_CONFIGURE_SERCOM1
	//PORT->Group[0].WRCONFIG.reg = 0x52010C00;	// SERCOM0 PA10 & PA11
	PM->APBCMASK.reg |= (1u << 3);
	//GCLK->CLKCTRL.reg = 0x4015;	// SERCOM1 0x15
	GCLK->CLKCTRL.reg = 0x4315;	// SERCOM1 0x15
#endif
			
#ifdef CORE_CONFIGURE_SERCOM2
	/* Enable & configure alternate function */
	PORT->Group[0].WRCONFIG.reg |= 0x52013000;	// SERCOM2 PA12 PAD[0] TX & PA13 PAD[1] RX
	PM->APBCMASK.reg |= (1u << 4);
	//GCLK->CLKCTRL.reg = 0x4016;	// SERCOM2 0x16
	GCLK->CLKCTRL.reg = 0x4316;	// SERCOM2 0x16
	//coreInterruptsInstallHandler(kUART2Interrupt, kHighestPriority, UART2Handler);
#endif
			
#ifdef CORE_CONFIGURE_SERCOM3
	PORT->Group[0].WRCONFIG.reg = 0xD2010300;	// SERCOM3 PA24 PAD[0] TX & PA25 PAD[1] RX
	PM->APBCMASK.reg |= (1u << 5);
	GCLK->CLKCTRL.reg = 0x4317;	// SERCOM3 0x17
#endif
			
#ifdef CORE_CONFIGURE_SERCOM4
	PORT->Group[1].WRCONFIG.reg = 0x52013000;	// SERCOM4 C PB12 PAD[0] TX & PB13 PAD[1] RX
	PM->APBCMASK.reg |= (1u << 6);
	//GCLK->CLKCTRL.reg = 0x4018;	// SERCOM4 0x18
	GCLK->CLKCTRL.reg = 0x4318;	// SERCOM4 0x18
#endif
			
#ifdef CORE_CONFIGURE_SERCOM5
	PORT->Group[1].WRCONFIG.reg = 0xD2010003;	//	SERCOM5 C PB16 PAD[0] TX & PB17 PAD[1] RX
	PM->APBCMASK.reg |= (1u << 7);				//	Enable SERCOM 5
	GCLK->CLKCTRL.reg = 0x4319;					//	Enable clock for SERCOM5
#endif

	for (i = 0;	i<kNumberOfUARTS; i++)
		{
		coreAsyncSerialInitializeBuffers(i);
		}
	
	return result;
	}


/** Configure uart
*/
int8_t coreAsyncSerialConfigure(uint8 uart, uint32_t baudrate, uint8 bits, uint8 stop, uint8 parity)
	{
	int8_t	result = 0;

	if (uart < kNumberOfUARTS)
		{
		/* Disable the SERCOM UART module */
		uarts[uart].SERCOM->USART.CTRLA.bit.ENABLE = 0;
		/* Wait for synchronization */
		while(uarts[uart].SERCOM->USART.SYNCBUSY.bit.ENABLE)
			;

		/* Perform a software reset */
		uarts[uart].SERCOM->USART.CTRLA.bit.SWRST = 1;
		/* Wait for synchronization */
		while(uarts[uart].SERCOM->USART.SYNCBUSY.bit.SWRST || uarts[uart].SERCOM->USART.SYNCBUSY.bit.ENABLE)
			;

		/* Update the UART pad settings, mode and data order settings */
		uarts[uart].SERCOM->USART.CTRLA.reg = uarts[uart].pads | SERCOM_USART_CTRLA_MODE(1) | SERCOM_USART_CTRLA_DORD | SERCOM_USART_CTRLA_RUNSTDBY;
		/* Enable transmit and receive and set data size to 8 bits */
		uarts[uart].SERCOM->USART.CTRLB.reg = SERCOM_USART_CTRLB_RXEN | SERCOM_USART_CTRLB_TXEN | SERCOM_USART_CTRLB_CHSIZE(0);
		/* Wait for synchronization */
		while(uarts[uart].SERCOM->USART.SYNCBUSY.bit.CTRLB)
			;
		/* Load the baud value */
		uarts[uart].SERCOM->USART.BAUD.reg = (65536.0*(1.0-((float)(16.0*(float)baudrate)/(float)SERCOM_UART_CLOCK)));
		}
	else
		result = -1;

	return result;
	}

/** Open uart
*/
int8_t coreAsyncSerialOpen(uint8 uart)
	{
	int8_t	result = 0;

	if (uart < kNumberOfUARTS)
		{
		coreAsyncSerialInitializeBuffers(uart);
		/* Enable SERCOM UART */
		uarts[uart].SERCOM->USART.CTRLA.bit.ENABLE = 1;
		/* Wait for synchronization */
		while(uarts[uart].SERCOM->USART.SYNCBUSY.bit.ENABLE)
			;

		NVIC_ClearPendingIRQ((IRQn_Type)uarts[uart].irq);
		NVIC_EnableIRQ((IRQn_Type)uarts[uart].irq);

		uarts[uart].SERCOM->USART.INTENSET.bit.RXC = 1;
		uarts[uart].SERCOM->USART.INTENSET.bit.TXC = 1;
		}
	else
		result = -1;
		
	return result;
	}

/** Close uart
*/
int8_t coreAsyncSerialClose(uint8 uart)
	{
	int8_t	result = 0;

	if (uart < kNumberOfUARTS)
		{
		uarts[uart].SERCOM->USART.INTENCLR.bit.RXC = 1;
		uarts[uart].SERCOM->USART.INTENCLR.bit.TXC = 1;

		NVIC_DisableIRQ((IRQn_Type)uarts[uart].irq);
		NVIC_ClearPendingIRQ((IRQn_Type)uarts[uart].irq);

		/* Disable the SERCOM UART module */
		uarts[uart].SERCOM->USART.CTRLA.bit.ENABLE = 0;
		/* Wait for synchronization */
		while(uarts[uart].SERCOM->USART.SYNCBUSY.bit.ENABLE)
			;
	#ifdef FIFO
		uarts[uart].fifo.head = 0;
		uarts[uart].fifo.tail = 0;
	#else
		uarts[uart].uartDataReceived = 0;
		uarts[uart].uartDataReceivePointer = 0;
		uarts[uart].uartDataReadPointer = 0;
  	#endif
		}
	else
		result = -1;
	
	return result;
	}

void coreAsyncSerialReset(uint8 uart)
	{
	}

uint16 coreAsyncSerialDataAvailable(uint8 uart)
	{
	uint16	result = 0x00;

	if (uart < kNumberOfUARTS)
		{
	#ifdef FIFO
		result = (uarts[uart].fifo.head - uarts[uart].fifo.tail);
	#else
		result = uarts[uart].uartDataReceived;
	#endif
		}
	
	return result;
	}

uint8 coreAsyncSerialPeek(uint8 uart)
	{
	uint8	result = 0x00;

	if (uart < kNumberOfUARTS)
		{
	#ifdef FIFO
		if (uarts[uart].fifo.head != uarts[uart].fifo.tail)
			{
			uint16	offset = (uarts[uart].fifo.tail % uarts[uart].fifo.size);
			result = uarts[uart].fifo.buffer[offset];
			}
	#else
		result = uarts[uart].uartReceiveBufferPointer[uarts[uart].uartDataReadPointer];
	#endif
		}
	
	return result;
	}

uint16 coreAsyncSerialRead(uint8 uart, void* p, uint16 n, time_t timeout)
	{
	uint16	nRead = 0;
	uint8*	bytePtr = (uint8*)p;
	time_t	timeoutTime = timeout;
	bool	timeoutOccured = false;
	
	if (timeoutTime != forever)
		timeoutTime += coreSystemTimerTicks();

	if (uart < kNumberOfUARTS)
		{
	#ifdef FIFO
		while ((nRead < n) && !timeoutOccured)
			{
			uint16	bytesAvailable;

			bytesAvailable = coreAsyncSerialDataAvailable(uart);
			if (bytesAvailable > 0)
				{
				uint16	offset = (uarts[uart].fifo.tail++ % uarts[uart].fifo.size);
				*bytePtr++ = uarts[uart].fifo.buffer[offset];
				nRead++;
				}
			else
				{
				__WFI();
				timeoutOccured = (coreSystemTimerTicks() > timeoutTime);
				}
			}
	#else
		while ((nRead < n) && !timeoutOccured)
			{
			uint16	nAvailable;
			
			coreControllerServiceWatchdog();
			//	If read buffer is empty: Wait until character is in UART receive register
			while(!uarts[uart].uartDataReceived && !timeoutOccured)
				{
				__WFI();
				timeoutOccured = (coreSystemTimerTicks() > timeoutTime);
				}
			
			nAvailable = uarts[uart].uartDataReceived;
			// read character
			while (nAvailable-- && (nRead < n))
				{
				//uarts[uart].SERCOM->USART.INTENCLR.bit.RXC = 1;	//	Disable UART receive  interrupt
				//NVIC_DisableIRQ((IRQn_Type)uarts[uart].irq);
				uarts[uart].uartDataReceived--;
				//NVIC_EnableIRQ((IRQn_Type)uarts[uart].irq);
				//uarts[uart].SERCOM->USART.INTENSET.bit.RXC = 1;	//	Reenable UART receive  interrupt

				*bytePtr++ = uarts[uart].uartReceiveBufferPointer[uarts[uart].uartDataReadPointer++];
				if (uarts[uart].uartDataReadPointer == uarts[uart].uartReceiveBufferSize)
					uarts[uart].uartDataReadPointer = 0;
				nRead++;
				}
			}
	#endif
		}
	
	return nRead;
	}

/**
	Read one byte from stream.
*/
uint8 coreAsyncSerialReadByte(uint8 uart, time_t timeout)
	{
	uint8	result = 0;
	uint8	buffer[1];
	
	coreAsyncSerialRead(uart, buffer, 1, timeout);
	result =  buffer[0];
	
	return result;
	}

uint16 coreAsyncSerialWriteAsync(uint8 uart, const void* p, uint16 n)
	{
	if ((n> 0) && (uart < kNumberOfUARTS))
		{
	//	while (uarts[uart].uartTransmissionPending)
	//		__WFI();
			//	coreControllerIdle();

		uarts[uart].uartDataRemaining = (n - 1);
		uarts[uart].uartTransmitBuffer = (const uint8*)p;
		uarts[uart].uartTransmissionPending = 1;
		uarts[uart].SERCOM->USART.DATA.reg = *uarts[uart].uartTransmitBuffer++;
		}

	return n;
	}

uint16 coreAsyncSerialWrite(uint8 uart, const void* p, uint16 n)
	{
	if (uart < kNumberOfUARTS)
		{
		coreAsyncSerialWriteAsync(uart, p, n);

		while (uarts[uart].uartDataRemaining)
			__WFI();
			//	coreControllerIdle();

		//while (uarts[uart].uartTransmissionPending)
		//	__WFI();
			//	coreControllerIdle();
		}

	return n;
	}

void coreAsyncSerialWriteByte(uint8 uart, uint8 v)
	{
	uint8	buffer[1];
	buffer[0] = v;
	coreAsyncSerialWrite(uart, buffer, 1);
	}

uint16 coreAsyncSerialWriteString(uint8 uart, const char* p)
	{
	int16_t	length = 0;
	const char*	pChar = p;
	
	while (*p++)
		length++;
	
	return coreAsyncSerialWrite(uart, pChar, length);
	}


static const char hexLookup[] = "0123456789ABCDEF";

void coreAsyncSerialWriteDataAsHexString(uint8 uart, const void* v, int n, bool writeSpace)
	{
	if (v)
		{
		int16_t		i;
		
		for (i = 0; i<n; i++)
			{
			uint8_t	byte;
			uint8_t	hiNibble;
			uint8_t	loNibble;
			char	output[] = "01 ";
			
			byte = ((uint8_t*)v)[i];
			hiNibble = ((byte >> 4) & 0x0F);
			loNibble = (byte & 0x0F);
			
			output[0] = hexLookup[hiNibble];
			output[1] = hexLookup[loNibble];
			if (writeSpace)
				coreAsyncSerialWrite(uart, output, 3);
			else
				coreAsyncSerialWrite(uart, output, 2);
			}
		}
	}

