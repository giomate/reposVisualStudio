/*--------------------------------------------------------------------------

coreADConverter.c

This file is part of e.Development

Implementation
low level interface to the LPC2468 internal A/D converter

$Author: steffen $
$Date: 2017-06-07 11:15:35 +0200 (Mi, 07 Jun 2017) $
$Revision: 1481 $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/Libraries/Cortex/e.Core/coreADConverter.c $

Copyright (c) 2006,2007,2008, 2009, 2010, 2014 Steffen Simon.
All rights reserved.

--------------------------------------------------------------------------*/
#include "sam.h"
#include "coreController.h"
#include "coreADConverter.h"

//#define GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)

#define ADC_DONE		0x80000000
#define ADC_OVERRUN		0x40000000
#define ADC_ADINT		0x00010000

#if ICB_Revision >= 0x0100
	#if (PARTNUMBER==144)
	#define ADC_NUM				16			//	for ICB with multiplexer
	#define ADC_CHANNEL_MASK	0x7B
	#else
	#define ADC_NUM				16			//	for ICB with multiplexer
	#define ADC_CHANNEL_MASK	0x00
	#endif
#else
	#define ADC_NUM				8			//	for LPC2468
	#define ADC_CHANNEL_MASK	0xFF
#endif
#define ADC_CLK			4000000		//	set to 4Mhz

static volatile int8 	analogOversamplingRate;
static volatile bool	analogConversionRunning;
static volatile int16 	analogNumberOfConversions;
static volatile int32	analogConversionTemp;
static volatile int16	analogConversionResult;

/*
void ADC0Handler(void)
	{
	uint32 regVal;

	regVal = AD0STAT;			//	Read ADC will clear the interrupt
	if (regVal & 0x0000FF00)	//	check OVERRUN error first
		{
		regVal = (regVal & 0x0000FF00) >> 0x08;
		//	if overrun, just read ADDR to clear
		//	regVal variable has been reused.
		switch (regVal)
			{
			case 0x01:
				regVal = AD0DR0;
				break;
			
			case 0x02:
				regVal = AD0DR1;
				break;
			
			case 0x04:
				regVal = AD0DR2;
				break;
			
			case 0x08:
				regVal = AD0DR3;
				break;
			
			case 0x10:
				regVal = AD0DR4;
				break;
			
			case 0x20:
				regVal = AD0DR5;
				break;
			
			case 0x40:
				regVal = AD0DR6;
				break;
			
			case 0x80:
				regVal = AD0DR7;
				break;
			
			default:
				break;
			}
		}
	else if (regVal & ADC_ADINT)
		{
		switch (regVal & 0xFF )	//	check DONE bit
			{
			case 0x01:
				analogConversionTemp += (AD0DR0 >> 6) & 0x3FF;
				break;

			case 0x02:
				analogConversionTemp += (AD0DR1 >> 6) & 0x3FF;
				break;

			case 0x04:
				analogConversionTemp += (AD0DR2 >> 6) & 0x3FF;
				break;

			case 0x08:
				analogConversionTemp += (AD0DR3 >> 6) & 0x3FF;
				break;

			case 0x10:
				analogConversionTemp += (AD0DR4 >> 6) & 0x3FF;
				break;

			case 0x20:
				analogConversionTemp += (AD0DR5 >> 6) & 0x3FF;
				break;

			case 0x40:
				analogConversionTemp += (AD0DR6 >> 6) & 0x3FF;
				break;

			case 0x80:
				analogConversionTemp += (AD0DR7 >> 6) & 0x3FF;
				break;
			
			default:
				break;
			}
	
		analogNumberOfConversions++;
		if (analogNumberOfConversions >= (1 << (analogOversamplingRate << 1)))
			{
			analogConversionResult = (analogConversionTemp >> analogOversamplingRate);
        	analogConversionTemp = 0;
			analogNumberOfConversions = 0;
			analogConversionRunning = false;
			}
	
		// Not in free running mode, manual conversion)
		if (analogConversionRunning)
			{
			//  start next conversion
			//	AD0CR &= 0xFFFFFF00;
			//	switch channel,start A/D convert
			//	AD0CR |= (1 << 24) | (1 << analogConversionChannel);	
			AD0CR |= (1 << 24);	
			}
		else
			{
			AD0CR &= 0xF8FFFFFF;	//	stop ADC now
			}
		}
	}
*/

typedef struct
	{
	uint8_t	GAIN;
	uint8_t	DIFFMODE;
	uint8_t	MUXNEG;
	uint8_t	MUXPOS;
	} ADCChannel;

static const ADCChannel	channels[] =
{
#if (SMC_Revision > 2)
	{0x0, 0x1, 0x19, 0x7},	//	TEMP_SENS_LC	Analogue 	PA07/AIN7
#else
	{0x0, 0x1, 0x19, 0x1},	//	TEMP_SENS_LC	Analogue 	PA03/AIN1
#endif
	{0x0, 0x1, 0x19, 0x2},	//	PS2_LC			Analogue 	PB08/AIN2
	{0x0, 0x1, 0x19, 0x3},	//	DIST_MEAS_LC	Analogue 	PB09/AIN3
	{0x0, 0x1, 0x19, 0x4},	//	PS1_LC			Analogue 	PB08/AIN4
	{0x0, 0x1, 0x19, 0x5},	//	ICM_U_Poti		Analogue 	PA05/AIN5
	{0x0, 0x1, 0x19, 0x6},	//	TEMP_Ref		Analogue 	PA06/AIN6
};

void coreADConverterInitialize(void)
	{
	analogConversionRunning = false;
	
	analogConversionResult = 0;
	analogConversionTemp = 0;
	analogNumberOfConversions = kNoOversampling;

	/* Turn on the digital interface clock */
	PM->APBCMASK.reg |= PM_APBCMASK_ADC;

	/* Turn on the analog interface clock and use GCLK Generator 3
	   * source is GCLK_SOURCE_OSC8M
	*/
	GCLK_CLKCTRL_Type clkctrl =
		{
		.bit.ID = ADC_GCLK_ID,
		.bit.GEN = 0x03,
		.bit.CLKEN = true,
		.bit.WRTLOCK = false,
		};
	GCLK->CLKCTRL.reg =GCLK_CLKCTRL_ID_ADC| GCLK_CLKCTRL_GEN(GENERIC_CLOCK_GENERATOR_OSC8M) | GCLK_CLKCTRL_CLKEN ;
	//ADC->CTRLA.reg=ADC_CTRLA_SWRST;

//	TEMP_SENS_LC	Analogue 	PA02/AIN0/DAC/Y0
//	PS1_LC			Analogue 	PA03/AIN1/Y1/REFA/REF_DAC/USB_ID
//	PS2_LC			Analogue 	PB08/AIN2/Y14
//	DIST_MEAS_LC	Analogue 	PB09/AIN3/Y15
//	VREF			Analogue 	PA04/AIN4/Y2/REFB

/*
		Analogue 	PA02/AIN0/DAC/Y0
	TEMP_SENS_LC	Analogue 	PA03/AIN1/Y1/REFA/REF_DAC/USB_ID
	PS2_LC			Analogue 	PB08/AIN2/Y14
	DIST_MEAS_LC	Analogue 	PB09/AIN3/Y15

	PS1_LC			Analogue 	PA04/AIN4/Y2/REFB
	ICM_U_POTI		Analogue	PA05/AIN5/Y3
	TEMP_REV		Analogue	PA06/AIN6/Y3
*/
	//	Pins definieren
	
	
	PORT->Group[0].WRCONFIG.reg |= 0x510100A0;	//	{PA3 AIN[1],} PA4 AIN[4], PA5 AIN[5], PA6 AIN[6]
	//PORT->Group[1].WRCONFIG.reg |= 0x51010300;	//	PB8 AIN[2], PB9 AIN[3]
	/* Configure channels that are used for ADC */
	//PORT->Group[0].PMUX[1].reg = PORT_PMUX_PMUXO_B | PORT_PMUX_PMUXE_B;
	//PORT->Group[0].PINCFG[PIN_PA02].reg = PORT_PINCFG_PMUXEN;
	//PORT->Group[0].PINCFG[PIN_PA03].reg = PORT_PINCFG_PMUXEN;
	//PORT->Group[0].PMUX[2].reg = PORT_PMUX_PMUXE_B;
	//PORT->Group[0].PINCFG[PIN_PA04].reg = PORT_PINCFG_PMUXEN;
/*
	ADC_INPUTCTRL_Type inputctrl =
	{
		.bit.MUXPOS = 0,
		.bit.MUXNEG = 0x18,
		.bit.INPUTSCAN = 0,
		.bit.INPUTOFFSET = 0,
		.bit.GAIN = ADC_INPUTCTRL_GAIN_1X_Val
		//.bit.GAIN = ADC_INPUTCTRL_GAIN_DIV2_Val
	};

	ADC->INPUTCTRL.reg = inputctrl.reg;

	*/
	/* Configure reference */
	ADC_REFCTRL_Type refctrl =
		{
		.bit.REFCOMP = true,
		// .bit.REFSEL = ADC_REFCTRL_REFSEL_INT1V_Val
		.bit.REFSEL = ADC_REFCTRL_REFSEL_INTVCC1_Val,
		};
	ADC->REFCTRL.reg = ADC_REFCTRL_REFCOMP|ADC_REFCTRL_REFSEL_INTVCC1;


	ADC->CTRLB.reg |=ADC_CTRLB_PRESCALER_DIV128;		
 	//ADC->CTRLB.bit.PRESCALER = 0x5;		//	8MHz DIV 128 = 62500 Hz
/*	
    ADC->REFCTRL.bit.REFCOMP = 1;
    ADC->REFCTRL.bit.REFSEL = ADC_REFCTRL_REFSEL_INTVCC1_Val; // 1/2 VDDANA = 0.5* 3V3 = 1.65V
*/
/*
	ADC->AVGCTRL.bit.SAMPLENUM = 0x8;	// 256 Samples
	ADC->AVGCTRL.bit.ADJRES = 0;
	ADC->AVGCTRL.bit.SAMPLENUM = 0x0;	// 1 Sample
	ADC->CTRLB.bit.RESSEL = 0x1;		// 16 Bit
*/
	//ADC->AVGCTRL.bit.SAMPLENUM = 0x8;	// 256 Samples
	ADC->AVGCTRL.reg = ADC_AVGCTRL_SAMPLENUM_16
						| ADC_AVGCTRL_ADJRES(4);	// 16 Samples
	

	ADC->SAMPCTRL.reg = ADC_SAMPCTRL_SAMPLEN(63);
	/* Load in the fixed device ADC calibration constants */
	ADC->CALIB.reg =
	  ADC_CALIB_BIAS_CAL((*(uint32_t *) ADC_FUSES_BIASCAL_ADDR >> ADC_FUSES_BIASCAL_Pos)) |
	  ADC_CALIB_LINEARITY_CAL((*(uint64_t *) ADC_FUSES_LINEARITY_0_ADDR >> ADC_FUSES_LINEARITY_0_Pos));
	//coreADCTemperatureInterrupt(5);
	}


void coreADCPortConfigure(uint8 port, uint8 pin){
	
	uint32	portWRconfig;
	
	//PORT->Group[port].DIRCLR.reg=PORT_DIRCLR_DIRCLR(pin);
	PORT->Group[port].PINCFG[pin].reg = PORT_PMUX_PMUXE(MUX_PA07B_ADC_AIN7) |PORT_PINCFG_INEN ;
	PORT->Group[port].PMUX[MUX_PA07B_ADC_AIN7].reg =PORT_PMUX_PMUXE(MUX_PA07B_ADC_AIN7) | PORT_PMUX_PMUXO(MUX_PA07B_ADC_AIN7) ;
	portWRconfig =(PORT->Group[port].WRCONFIG.reg)|(PORT_WRCONFIG_PINMASK(PORT_PA07B_ADC_AIN7)|PORT_WRCONFIG_PMUXEN
									|PORT_WRCONFIG_PMUX(MUX_PA07B_ADC_AIN7)|PORT_WRCONFIG_WRPINCFG|PORT_WRCONFIG_HWSEL)
								&PORT_WRCONFIG_MASK;
	PORT->Group[port].WRCONFIG.reg=portWRconfig;
	
	
}
void coreADConverterOpen(void)
	{
	//	ADC ein
	ADC->INPUTCTRL.bit.MUXPOS = channels[0].MUXPOS; // Selection for the positive ADC input
	ADC->CTRLA.bit.ENABLE = 1;
	while (ADC->STATUS.bit.SYNCBUSY)
		;
	}

void coreADConverterClose(void)
	{
	//	ADC aus
	ADC->CTRLA.bit.ENABLE = 0;
	while (ADC->STATUS.bit.SYNCBUSY)
		;
	}

void coreADConverterSelectChannel(uint8 channel)
	{

	//	ADC aus
	ADC->SWTRIG.reg = ADC_SWTRIG_FLUSH;
	while (ADC->STATUS.bit.SYNCBUSY)
		;

	//	ADC aus
	ADC->CTRLA.reg &= ~ADC_CTRLA_ENABLE;
	while (ADC->STATUS.bit.SYNCBUSY)
		;

	
	
	if (channel==7){
		ADC->REFCTRL.reg = ADC_REFCTRL_REFCOMP|ADC_REFCTRL_REFSEL_AREFA;
		
	}else{
		ADC->REFCTRL.reg = ADC_REFCTRL_REFCOMP|ADC_REFCTRL_REFSEL_INTVCC1;
		
	}
	
	ADC->INPUTCTRL.reg = ADC_INPUTCTRL_MUXPOS((channel))| ADC_INPUTCTRL_MUXNEG_GND| ADC_INPUTCTRL_GAIN_1X;
	
	
	//ADC->INPUTCTRL.reg = inputctrl.reg;
 
	//	ADC ein
	ADC->CTRLA.reg = ADC_CTRLA_ENABLE;

	while (ADC->STATUS.bit.SYNCBUSY);
		
	}

int16 coreADConverterReadSingle(void)
	{
	int16	result=3000;
	ADC->INTENCLR.reg= ADC_INTENCLR_RESETVALUE;
	uint8	mask=ADC->INTFLAG.reg;
	

	ADC->SWTRIG.reg = ADC_SWTRIG_START;
	//ADC->SWTRIG.bit.START = 1;
	while ( ADC->INTFLAG.bit.RESRDY == 0 );   // Waiting for conversion to complete

	result = ADC->RESULT.reg;
	ADC->INTFLAG.reg=mask;
	return result;
	}

void coreADConverterRelease(void)
	{
/*
	//	ADC
	//	- disable
	//	- interrupt disable
	ADCSRA = 0;
#if defined (__AVR_AT90CAN128__)
	ADCSRB = 0;
#endif
	//	DIDR0 = 0;		// Enable digital input buffer
*/
	}
/*
int16 coreADConverterReadSingle(uint8 channel)
	{
	uint8	adcChannel;
	uint8	channelMask;
	int16	result;
	
	//	channel number is 0 through 7
	if (channel >= ADC_NUM)
		adcChannel = 0;		//	reset channel number to 0
#if ICB_Revision >= 0x0100
	else if (channel > 7)
		{
		corePortsSetPortMasked(kPort1, 0x7 << 27, (channel - 8) << 27);
		adcChannel = 0;
		}
#endif
	else
		adcChannel = channel;

	AD0CR &= 0xF8FFFF00;	//	stop ADC now
	
	channelMask = ((1 << adcChannel) & ADC_CHANNEL_MASK);
	
	if (channelMask)
		{
   		analogConversionTemp = 0;
		analogNumberOfConversions = 0;
		analogConversionRunning = true;

		AD0CR |= (1 << 24) | channelMask;
		// wait for result
		while (analogConversionRunning)
			coreControllerIdle();

		result = analogConversionResult;
		}
	else
		result = 0;
	
	return result;
	}
*/
void coreADConverterReadArray(uint16 bits, int16 results[8], uint8 oversampling)
	{
	uint8	ch;
	
	for (ch = 0; ch < ADC_NUM; ch++)
		{
		if (bits & (1 << ch))
			{
			coreADConverterSelectChannel(ch);
			results[ch] = coreADConverterReadSingle();
			}
		}
	}

void coreADConverterSetOversampling(uint8 oversampling)
	{
	if (oversampling > kOversampling256)
		analogOversamplingRate = kOversampling256;
	else
		analogOversamplingRate = oversampling;
	}

uint8 coreADConverterGetResolution(void)
	{
	return 10 + analogOversamplingRate;
	}

int16 coreADConverterGetMaximumValue(void)
	{
	return ((1 << (10 + analogOversamplingRate)) - 1);
	}

