/*
 * encoderClass.cpp
 *
 * Created: 10/27/2019 12:35:49 PM
 *  Author: giova
 */ 

#include "encoderClass.h"
#include "applicationClass.h"



encoderClass::encoderClass(const userParameters* parameters) {

	
	calibrationFactor=parameters->RPMCalibrationfactor;
	distanceCalibrationValue=parameters->distanceCalibrationValue;
	minSpeedCutOff=parameters->minSpeedCutOff;
}


void encoderClass::monitorDistance(void){
	startSpeedMeter();
	
	if (isMoving()){
		if (Door.doorReturn()>0){
			distanceCounter++;
		}else if ((Door.doorReturn()<0)&&(distanceCounter>0)){
			distanceCounter--;
		}
	}

}

float encoderClass::getDistance(void) {
	float	distanceEstimated;
	
	if (Door.isStowed()){
		distanceEstimated=0;
	} else{
		distanceEstimated = (float)distanceCounter * distanceCalibrationValue;
	}
	return distanceEstimated;
	
}

float encoderClass::getRPM(void) {
	
	if (lastSpeed==0){
		status.rpm=0;
	}else{
		status.rpm= (1 * 20 * 1000)/(12*lastSpeed);
	}
	return status.rpm;
}





void encoderClass::initEncoderTimer(void){
	cpu_irq_disable();
	
	// Configure Count Mode (32-bit)
	TC4->COUNT32.CTRLA.reg =TC_CTRLA_MODE_COUNT32|TC_CTRLA_WAVEGEN_NFRQ|TC_CTRLA_PRESCALER_DIV1024;
	while(TC4->COUNT32.STATUS.bit.SYNCBUSY == 1);
	// Initialize compare value for 100mS @ 500kHz
	TC4->COUNT32.CTRLBSET.reg =TC_CTRLBSET_DIR|TC_CTRLBSET_ONESHOT|TC_CTRLBSET_CMD_STOP;
	while(TC4->COUNT32.STATUS.bit.SYNCBUSY == 1);
	
	
	TC4->COUNT32.CC[0].reg = 0;
	while(TC4->COUNT32.STATUS.bit.SYNCBUSY == 1);
	// Enable TC3 compare mode interrupt generation									// Enable match interrupts on compare channel 0
	
	// Enable TC3
	
	
	// Wait until TC3 is enabled
	while(TC4->COUNT32.STATUS.bit.SYNCBUSY == 1);
	
	NVIC_EnableIRQ(TC4_IRQn);						// Enable the interrupt
	
	/* Enable all IRQs */
	cpu_irq_enable();
}

void encoderClass::startSpeedMeter(void){
	
	 TC4->COUNT32.CTRLA.reg |= TC_CTRLA_ENABLE;
	 lastSpeed=speedCounter;
	 speedCounter=0;
	 while(TC4->COUNT32.STATUS.bit.SYNCBUSY == 1);
}

void encoderClass::stopSpeedMeter( void){
	TC4->COUNT32.CTRLBSET.reg =TC_CTRLBSET_CMD_STOP;
	speedCounter= TC4->COUNT32.COUNT.reg;
	//TC4->COUNT32.CTRLA.bit.SWRST = 1 ;
	TC4->COUNT32.CTRLA.reg = TC_CTRLA_RESETVALUE;
	
	TC4->COUNT32.COUNT.reg= TC_COUNT32_COUNT_RESETVALUE;
		
}

bool encoderClass::timerEncoderTimeout(void){
	bool overflow_tcx=(TC4->COUNT32.INTFLAG.bit.OVF);
	return overflow_tcx;
}

void encoderClass::encoderEICConfigure(){
	uint32	configregister;
	
	cpu_irq_disable();
	PM->APBAMASK.reg |= PM_APBAMASK_EIC;
	
	// Configure asynchronous clock source
	
	
	configregister = GCLK_CLKCTRL_ID( GCLK_CLKCTRL_ID_EIC_Val) | GCLK_CLKCTRL_GEN(GCLK_CLKCTRL_GEN_GCLK0_Val) | GCLK_CLKCTRL_CLKEN;							// select TC3 peripheral channel
	while(GCLK->STATUS.bit.SYNCBUSY==1);
	GCLK->CLKCTRL.reg = 0x4305;
	
	
	configregister=PORT_WRCONFIG_MASK
	&(PORT_WRCONFIG_PMUXEN|PORT_WRCONFIG_PULLEN|PORT_WRCONFIG_INEN|PORT_WRCONFIG_PMUX(MUX_PB17A_EIC_EXTINT1)
	|PORT_WRCONFIG_WRPMUX|PORT_WRCONFIG_WRPINCFG|PORT_WRCONFIG_HWSEL)
	|PORT_WRCONFIG_PINMASK(PORT_PA17A_EIC_EXTINT1);
	
	PORT->Group[0].PINCFG[PIN_PA17A_EIC_EXTINT1].reg= PORT_PMUX_PMUXE(MUX_PA17A_EIC_EXTINT1) |PORT_PINCFG_INEN ;								
	PORT->Group[0].PMUX[MUX_PA17A_EIC_EXTINT1].reg =PORT_PMUX_PMUXE(MUX_PA17A_EIC_EXTINT1) | PORT_PMUX_PMUXO(MUX_PA17A_EIC_EXTINT1) ;
	//PORT->Group[0].WRCONFIG.reg |= configregister;
	PORT->Group[0].WRCONFIG.reg |= 0xD0010002;
	
	EIC->CONFIG[0].reg =EIC_CONFIG_SENSE1_BOTH | EIC_CONFIG_FILTEN1;
	EIC->WAKEUP.reg = EIC_WAKEUP_WAKEUPEN1 ;
	cpu_irq_enable();
}

void encoderClass::encoderEnable(){
	EIC->CTRL.reg |=EIC_CTRL_ENABLE ;
	while (EIC->STATUS.bit.SYNCBUSY);
	EIC->INTENSET.reg = EIC_INTENSET_EXTINT1;
	NVIC_ClearPendingIRQ((IRQn_Type)EIC_IRQn);
	NVIC_EnableIRQ((IRQn_Type)EIC_IRQn);
}

void encoderClass::encoderDisable(void){
	EIC->INTENCLR.reg = EIC_INTENCLR_EXTINT1;
	NVIC_DisableIRQ((IRQn_Type)EIC_IRQn);
	NVIC_ClearPendingIRQ((IRQn_Type)EIC_IRQn);
	EIC->CTRL.reg &= ~EIC_CTRL_ENABLE;
	while (EIC->STATUS.bit.SYNCBUSY);
}

void encoderClass::setDistance(float distance)
{
	#if __DEBUG__ > 0
		//controller.asc0 << coreSystemTimerTicks() << "setDistance on entry: distance == " << getDistance()
	//<< ", new distance == " << distance << newline;
	#endif
	//	Check for division by zero!
	if (distanceCalibrationValue > 0.0)
		distanceCounter = (uint32)(distance/(distanceCalibrationValue));
	
	#if __DEBUG__ > 0
	//	controller.asc0 << coreSystemTimerTicks() << "setDistance on exit: distance == " << getDistance() << newline;
	#endif
}


bool encoderClass::isMoving(void){
	return (bool)(getRPM()>=minSpeedCutOff);
}

void EIC_Handler(void){
	
	
	uint32_t	mask = EIC->INTFLAG.reg;
	if ((PORT->Group[0].IN.reg & (1UL << 17)) == 0){
		Door.Encoder.monitorDistance();
		//Door.Encoder.startSpeedMeter();
	}
	if ((PORT->Group[0].IN.reg & (1UL << 17)) == 1){
		Door.Encoder.stopSpeedMeter();
	}
	/*
	if ((PORT->Group[1].IN.reg & (1UL << 14)) == 0){
		//DoorhardwareCutOff();
		MonitorN.stopMotor();
		MonitorN.encoderDisable();
		event e(kHardwareEventClass, kDeviceHWFailureEventType,0);
		sendEventSelf(e);
		//Door->prepareStateChangeEvent(e, kDeviceStateError, uint16 data)
	}
	*/
	EIC->INTFLAG.reg = mask;
}

