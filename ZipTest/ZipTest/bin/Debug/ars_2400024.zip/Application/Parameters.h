/*
 * Parameters.h
 *
 * Created: 10/23/2019 2:13:31 PM
 *  Author: GMateusDP
 */ 


#ifndef PARAMETERS_H_
#define PARAMETERS_H_


#include "coreTypes.h"


struct userParameters
{
	uint16		slowSpeedCurrentLimit;			//	Current Limitation: Number of Steps for electronic resistor
	uint16		fastSpeedCurrentLimit;		    //	fast speed current limitation
	float		motorCurrentLimit;				//	Motorvelocity Slow
	float		motorCurrentResistorFactor;		//	Motorvelocity Slow
	uint16		changeDirectionSpeed;			//	Motorvelocity during Delay 5
	uint16		changeDirectionToStowDelay;		//	Delay wenn Button w�hrend Deploy gedr�ckt wird 0
	uint16		changeDirectionToDeployDelay;	//	Delay wenn Button w�hrend Stow gedr�ckt wird  300
	float		slowSpeed;						//	Motorvelocity Slow
	float		fastSpeed;						//	Motorvelocity High
	float		slowSpeedOffsetDeploy;			//	Distance from deploy position for entering slow speed
	float		slowSpeedOffsetStow;			//	Distance from deploy position for entering slow speed
	float		distanceCalibrationValue;		//	Calibration, Motorsignals vs. Distance
	float		kDeployPosition24inch;			//	Distance from deploy position for entering slow speed
	float		kDeployPosition22inch;			//	Distance from deploy position for entering slow speed
	float		minSpeedCutOff;					//	Minimal speed to consider Door blocked
	float		RPMCalibrationfactor;					//	Minimal speed to consider Door blocked
	
	time_t		stowTimeoutTime;				//	timeout for stowing
	time_t		deployTimeoutTime;				//  timeout for deplying
	time_t		blockTimeDelay;					//	pause after software cutoff
	time_t		cutoffTimer;					//	timer to activate cutoff mode
	time_t		TTLtimer;	      				//	timer to activate cutoff mode
	time_t		CABtimer;	      				//	timer to activate cutoff mode
	time_t		doorMoveDelay;	      			//	timer to activate cutoff mode
	
		
	float		rawTemperatureMin;				//	Temperature min operation
	float		rawTemperatureMax;				//	Temperature max operation

	bool		doorSide;						//	Door side
	bool		doorSize;						//	Door Size		
};

typedef struct userParameters	userParameters;

struct userPreferences
{
	uint32	privacyLightperiod;					//	Period of blinking Light ms
	uint32	privacyLightDutyCycle;				//	DutyCycle on the Light %
};

typedef struct userPreferences userPreferences;

enum{
	RightDoor=0,
	LeftDoor
	};
	
enum{
	Size22inch=0,
	Size24inch
};

extern const userParameters		defaultParameters;
extern const userPreferences	defaultPreferences;
#endif /* PARAMETERS_H_ */