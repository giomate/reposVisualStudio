/*--------------------------------------------------------------------------

GAINDefinitions.h

Interface

Common GAIN enum and type definitions

Author: Steffen Simon

$Date: 2017-10-19 12:43:50 +0200 (Do, 19 Okt 2017) $
$Revision: 1606 $

--------------------------------------------------------------------------*/
#ifndef GAIN_DEFINITIONS_H
#define GAIN_DEFINITIONS_H

#ifdef __cplusplus
extern "C" {
	#endif

#ifdef __DEBUG__
	#ifdef AVR
	#include <avr/pgmspace.h>
	#endif
#endif

#include "coreTypes.h"

#ifdef __DEBUG__
extern const char* deviceStateDescription[];
extern const char* deviceEventDescription[];
#endif

/** Constants for GAIN internal states
*/
enum
	{
	kDeviceStatePowerUp,
	kDeviceStateReset,
	kDeviceStateInitialize,
	kDeviceStateResume,
	kDeviceStateLocked,
	kDeviceStateDeploying,
	kDeviceStateStowing,
	kDeviceStateForcedStow,
	kDeviceStateOverload,
	kDeviceStateError,
	kDeviceInStateEvent,
	kDeviceStateMaintenance,
	kDeviceStateCount
	};
/*@}*/

/*
	Constants for kDeviceEventClass event types
*/



/*
	Constants for Generic GAIN event class types
*/	
enum
	{
	kDeviceSwitchStateEvent = 0x200,
	kDeviceTimerEvent,
	kDeviceResetEvent,
	};
	


struct configurationDataStruct
	{
	uint32		crc32;
	uint32		magic;
	uint32		size;
	uint32		version;

	uint16		slowSpeedCurrentLimit;			//	Current Limitation: Number of Steps for electronic resistor
	uint16		changeDirectionSpeed;			//	Motorvelocity during Delay 5
	uint16		changeDirectionToStowDelay;		//	Delay wenn Button w�hrend Deploy gedr�ckt wird 0
	uint16		changeDirectionToDeployDelay;	//	Delay wenn Button w�hrend Stow gedr�ckt wird  300
	float		slowSpeed;						//	Motorvelocity Slow
	float		slowSpeedOffset;				//	Distance from deploy position for entering slow speed
	float		distanceCalibrationValue;		//	Calibration, Motorsignals vs. Distance
	
	time_t		stowTimeoutTime;
	time_t		deployTimeoutTime;
	};

typedef struct configurationDataStruct	configurationDataStruct;





#ifdef __cplusplus
}
#endif


extern const uint32_t	kApplicationStateStructVersion;
extern const uint32_t	kConfigurationDataStructVersion;


extern const configurationDataStruct	defaultConfiguration;



#endif

