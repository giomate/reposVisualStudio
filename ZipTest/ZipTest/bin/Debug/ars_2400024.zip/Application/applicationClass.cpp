/*--------------------------------------------------------------------------

applicationClass.cc

Implementation
Door Actuator P/N 2400023

Autor: Steffen Simon

$Date: 2017-12-06 12:49:23 +0100 (Mi, 06 Dez 2017) $
$Revision: 1642 $
$Author: steffen $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/ExtensionApp/ARSSTD-2400023-2.0/applicationClass.cc $

--------------------------------------------------------------------------*/

#include "applicationClass.h"
#include "DeviceDefinitions.h"


applicationClass Door;

		
applicationClass::applicationClass(void){
	Parameters =				 defaultParameters;
	WaitEventCallbackHandler =					NULL;
	state.build = build;
	state.currentState =		kDeviceStatePowerUp;
	state.callingState =		kDeviceStatePowerUp;
	state.internalCateringState =				 0;
	state.inStateTime =							 0;
	state.doorFTLocated=0;
	state.doorQSLocated=0;
	state.doorQDLocated=0;
	
	
	kClockWise =							 (defaultParameters.doorSide==LeftDoor);
	kCounterClockWise =						(defaultParameters.doorSide==RightDoor);
	kConfigurationRightHand =				(defaultParameters.doorSide==LeftDoor);
	kConfigurationLeftHand =				(defaultParameters.doorSide==RightDoor);
	//configuration =				defaultConfiguration;
	
	doorPositionSave =						false;
	deployedPositionSave =					 false;
	stowedPositionSave =					false;
	ButtonPressedSave =						false;
	state.doorPositionknown		=				false;
	
	
}
privacyLightClass	applicationClass::Light(&defaultPreferences);
timerClass		applicationClass::CABTimer(7);
timerClass		applicationClass::TTLTimer(6);
event			applicationClass::e(kDeviceEventClass,kDeviceStatePowerUp,0);

thermoClass		applicationClass::Thermo(7);
encoderClass	applicationClass::Encoder(&defaultParameters);
motorDriverClass	applicationClass::Motor(&defaultParameters);

void applicationClass::initDoor(void){
	Encoder.initEncoderTimer();
	Encoder.encoderEICConfigure();
	Thermo.initThermo();
}

void applicationClass::run(void){
	
	uint8	resetCause((uint8)PM->RCAUSE.reg);
	
	
    if (doorSizeConfiguration())
    	{
	#if __DEBUG__ > 2
		controller.asc0 << "door size is 24 inch " << newline;
	#endif
		state.deployPosition = Parameters.kDeployPosition24inch;
		}
	else
    	{
	#if __DEBUG__ > 2
		controller.asc0 << "door size is 22 inch " << newline;
	#endif
		state.deployPosition = Parameters.kDeployPosition22inch;
		}

   if (doorSideConfiguration())
    	{
	#if __DEBUG__ > 2
		controller.asc0 << "door configuration is LH " << newline;
	#endif
		state.deployDirection = kClockWise;
		state.stowDirection = kCounterClockWise;
		}
	else
    	{
	#if __DEBUG__ > 2
		controller.asc0 << "door configuration is RH " << newline;
	#endif
		state.deployDirection = kCounterClockWise;
		state.stowDirection = kClockWise;
		}

	#if __DEBUG__ > 2
		controller.asc0 << "run: reset cause == " << kModeHex <<  resetCause << ", slowSpeedCurrentLimit == " << Parameters.slowSpeedCurrentLimit << newline;
	#endif
	prepareStateChangeEvent(e, kDeviceStateReset);
	sendEventSelf(e);

	while (true){
		if (waitForEvent(Door.e, kDeviceEventClass, kDeviceSwitchStateEvent)){
			handleDeviceEvent(Door.e);
		}
	}
}

void applicationClass::handleDeviceEvent(event& e){
	if (state.currentState != kDeviceStateResume){
		state.callingState = state.currentState;
	}
		
	state.currentState = e.data.wordData[0];


	#if __DEBUG__ > 2
		#ifdef AVR
			controller.asc0.lock();
			controller.asc0 << "handleDeviceEvent received: switching from ";
			controller.asc0.writeP(deviceStateDescription[state.callingState]);
			controller.asc0 << " to ";
			controller.asc0.writeP(deviceStateDescription[state.currentState]);
			
			controller.asc0.unlock();
		#else
			controller.asc0.lock();
			controller.asc0 << "handleDeviceEvent received: switching from ";
			controller.asc0.write(deviceStateDescription[state.callingState]);
			controller.asc0 << " to ";
			controller.asc0.write(deviceStateDescription[state.currentState]);
		
			controller.asc0.unlock();
		#endif
	#endif

	switch (state.currentState){
		case kDeviceStateReset:
			handleStateReset();
			break;

		case kDeviceStateInitialize:
			handleStateInitialize();
			break;

		case kDeviceStateResume:
			handleStateResume();  
			break;

		case kDeviceStateLocked:
			handleStateLocked();
			break;

		case kDeviceStateDeploying:
			handleStateDeploy();
			break;

		case kDeviceStateStowing:
			handleStateStow();
			break;
			
		case kDeviceStateForcedStow:
			handleStateForcedStow();
			break;

		case kDeviceStateError:
			handleStateError();
			break;
		
		default:
			handleStateResume();
			break;
	}
}

void applicationClass::handleStateReset(){
	state.currentState=kDeviceStateReset;
	event	e;
	e=Door.e;
		
#if __DEBUG__ > 0
	controller.asc0.lock();
	controller.asc0 << "handleStateReset" << newline;
	controller.asc0.unlock();	
#endif

	state.distanceEstimatedRaw = 0;
	state.directionChanged = false;

	prepareStateChangeEvent(e, kDeviceStateInitialize);
	sendEventSelf(e);

    coreControllerEnableBOD();
    coreControllerEnableWatchdog();
	
	Door.e=e;
	
}

void applicationClass::handleStateInitialize(){
	state.currentState=kDeviceStateInitialize;
	event	e;
	
	#if __DEBUG__ > 0
		controller.asc0.lock();
		controller.asc0 << "handleStateInitialize" << newline;
		controller.asc0.unlock();	
	#endif
	
	WaitEventCallbackHandler = checkEvent;
	Door.e=checkPeripheral();
	//coreSystemTimerWaitWithCallback(1000, 50, checkEvent);
	e=Door.e;
	switch(e.eventType){
		case kDoorBlockedType:
			prepareStateChangeEvent(e, kDeviceStateError);
			sendEventSelf(e);
			break;
		case kDoorLockedType:
			prepareStateChangeEvent(e, kDeviceStateLocked);
			sendEventSelf(e);
			break;
		case kDoorFTInitiated:
			prepareStateChangeEvent(e, kDeviceStateForcedStow);
			sendEventSelf(e);
			break;
		default:
			prepareStateChangeEvent(e, kDeviceStateLocked);
			sendEventSelf(e);
			break;
		
	}
	Door.e=e;
	state.lastState=kDeviceStateInitialize;
}

void applicationClass::handleStateResume(){
	
	event	e;
	
	#if __DEBUG__ > 0
		controller.asc0.lock();
		controller.asc0 << "handleStateResume" << newline;
		controller.asc0.unlock();	
	#endif
	
	e=checkPeripheral();
	if (e.eventClass==kHardwareEventClass){
		prepareStateChangeEvent(e, kDeviceStateError);
		sendEventSelf(e);
		return;
	} 
	if (e.eventClass==kAdminEventClass){
		prepareStateChangeEvent(e, kDeviceStateLocked);
		sendEventSelf(e);
		return;
	}
	e.data.wordData[0]=state.lastState;
	handleDeviceEvent(e);
		
	
}


void applicationClass::handleStateLocked(){
	state.currentState=kDeviceStateLocked;
	state.counterDirection =1;
	event	e=Door.e;
	bool	done(false);
	
	#ifdef __DEBUG__
		controller.asc0.lock();
		controller.asc0 << " handleStateLocked" << newline;
		controller.asc0.unlock();
	#endif
	while (!done){
		if (handleInStateEvent(e, 1000, done)){
			switch (e.eventClass){
				case kUserEventClass:
					if (doorPositionKnown()){
						switch (e.eventType){
							case kDeviceCABButtonPressed:
								if (isDeployed()){
									e.eventType=kUserStowCommandType;
									prepareStateChangeEvent(e, kDeviceStateLocked, e.eventType);
									Door.CABTimer.startTimer(Parameters.CABtimer);
									while (CABButtonPressed()){
										if (Door.CABTimer.timerTimeout()){
											e.eventClass=kAdminEventClass;
											e.eventType=kAdminStowCommandType;
											prepareStateChangeEvent(e, kDeviceStateForcedStow, e.eventType);
											Door.CABTimer.stopTimer();
											Light.turnOffPrivLight();
											done = true;
											break;
										}
									}
									CABTimer.stopTimer();
									done = true;
								}
								if (isStowed()){
									e.eventType=kUserStowCommandType;
									prepareStateChangeEvent(e, kDeviceStateDeploying, e.eventType);
									Light.turnOffPrivLight();
									done = true;
								}
								break;
							case kDeviceLAVButtonPressed:
								if (isDeployed()){
									e.eventType=kUserStowCommandType;
									Light.turnOnPrivLight();
									prepareStateChangeEvent(e, kDeviceStateStowing, e.eventType);
									CABTimer.startTimer(Parameters.CABtimer);
								}
								if (isStowed()){
									Light.turnOffPrivLight();
									e.eventType=kUserDeployCommandType;
									prepareStateChangeEvent(e, kDeviceStateDeploying, e.eventType);
									done = true;
								}
								break;
							default:
								prepareStateChangeEvent(e, kDeviceStateResume);
								done = true;
								break;
						} 
					}else{
						Light.turnOffPrivLight();
						e.eventType=kUserStowCommandType;
						prepareStateChangeEvent(e, kDeviceStateStowing, e.eventType);
						done = true;
					}
				case kAdminEventClass:
					Light.turnOffPrivLight();
					e.eventType=kAdminStowCommandType;
					prepareStateChangeEvent(e, kDeviceStateForcedStow, e.eventType);
					done = true;
					break;
				default:
					prepareStateChangeEvent(e, kDeviceStateResume);
					done = true;
					break;
			}
		}
	}
	doorPositionSave = false;
	sendEventSelf(e);
	Door.e=e;
	state.lastState=state.currentState;
}



void applicationClass::handleStateForcedStow(void){
	state.currentState=kDeviceStateForcedStow;
	state.counterDirection =1;
	event	e;
	bool	done(false);
	
	#ifdef __DEBUG__
	controller.asc0.lock();
	controller.asc0 << " handleStateForcedStow" << newline;
	controller.asc0.unlock();
	#endif
	e=this->e;
	while (!done){
		switch (e.eventClass){
			case kAdminEventClass:
				if (doorPositionKnown()){
					switch (e.eventType){
						case kDeviceCABButtonPressed:
							if (isDeployed()){
								e.eventType=kDoorLockedType;
								prepareStateChangeEvent(e, kDeviceStateError, e.eventType);
								Light.blinklight();
								CABTimer.startTimer(Parameters.CABtimer);
								done = true;
							}
							if (isStowed()){
								Light.turnOffPrivLight();
								e.eventType=kAdminStowCommandType;
								prepareStateChangeEvent(e, kDeviceStateLocked, e.eventType);
								done = true;
							}
							break;
						case kDeviceTTLEvent:
							prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
							if (isDeployed()){
								e.eventType=kDeviceTTLEvent;
								TTLTimer.startTimer(Parameters.TTLtimer);
								Light.turnOffPrivLight();
								while (TTLButtonPressed()){
									if (TTLTimer.timerTimeout()){
										prepareStateChangeEvent(e, kDeviceStateStowing, e.eventType);
										Light.turnOffPrivLight();
										TTLTimer.stopTimer();
										done = true;
										break;
									}
								}
								TTLTimer.stopTimer();
								done = true;
							}
							if (isStowed()){
								Light.turnOffPrivLight();
								prepareStateChangeEvent(e, kDeviceStateLocked, e.eventType);
								done = true;
							}
							break;
						default:
							break;
					}
				}else if (!(Encoder.isMoving())){
					e.eventType=kDoorBlockedType;
					Light.blinklight();
					prepareStateChangeEvent(e, kDeviceStateOverload, e.eventType);
					done = true;
				}
				break;
			case kOverloadEventClass:
				Light.blinklight();
				prepareStateChangeEvent(e, kDeviceStateStowing, e.eventType);
				done = true;
				break;
			case kDeviceEventClass:
				Light.blinklight();
				prepareStateChangeEvent(e, kDeviceStateStowing, e.eventType);
				done = true;
				break;
			default:
				prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
				break;
				
		}
		
	}
	doorPositionSave = false;
	sendEventSelf(e);
	Door.e=e;
	state.lastState=state.currentState;
}



void applicationClass::handleStateDeploy(){
	state.currentState=kDeviceStateDeploying;
	event	e;
	e=this->e;
	bool	done(false);
	bool	fastMode;
	time_t	enterStateTime(coreSystemTimerTicks());
	
	#ifdef __DEBUG__
		controller.asc0 << "handleStateDeploy" << newline;
		controller.asc0 << "distance == " << Encoder.getDistance() << " mm"<< newline;
	#endif
	
	if (isStowed()||isDeployed()){
		Encoder.setDistance(0);
	}else if (!doorPositionKnown()){
		Encoder.setDistance(state.deployPosition/2);
	}
		
	#ifdef __DEBUG__
		controller.asc0 << "distance == " << Encoder.getDistance() << " mm"<< newline;
	#endif
	
	state.doorDeploying = true;
	state.doorStowed = false;
	state.kinematicLimit = 200;
	
	/*

	if (state.directionChanged){
		state.directionChanged = false;
		startMotor(state.deployDirection, getFastSpeedDutyCycle());
		coreSystemTimerWait(200);
		setDECModuleMode(0x01);
		fastMode = true;
	}else{
		setDECModuleMode(0x01);
		startMotor(state.deployDirection, getFastSpeedDutyCycle());
		fastMode = true;
	}
	*/
	while ((!done)&&(!state.doorDeployed)&&(!state.HWCutOff)&&(!state.doorBlocked)){
		if (hardwareCutOff()){
			#ifdef __DEBUG__
				controller.asc0 << "!!!Hardware CutOff!!!" << newline;
			#endif
			state.HWCutOff=1;
			e.eventClass=kHardwareEventClass;
			e.eventType=kDeviceHWCutOffEvent;
			sendEventSelf(e);
			prepareStateChangeEvent(e, kDeviceStateOverload);
			done=1;
		}
		else if ((coreSystemTimerTicks() - enterStateTime) >  Parameters.deployTimeoutTime*2){
			#ifdef __DEBUG__
				controller.asc0 << "deploy: timeout" << newline;
			#endif
			state.doorBlocked=1;
			e.eventClass=kHardwareEventClass;
			e.eventType=kDeployTimeoutType;
			sendEventSelf(e);
			prepareStateChangeEvent(e, kDeviceStateError);
			done=1;
		}
		else if (handleInStateEvent(e, 100, done) && doorPositionKnown()){
			
			switch (e.eventClass){
				case kUserEventClass:
					if (!state.doorFTLocated){
						switch (e.eventType){
							case kDeviceCABButtonPressed:
								if (isStowed()){
									coreSystemTimerWait(Parameters.changeDirectionToStowDelay);
									state.doorBlocked=1;
									state.doorQSLocated=1;
									prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
								}
								else{
									Encoder.encoderEnable();
									Motor.setCurrentLimit(getFastSpeedCurrentLimit());
									Motor.startMotor(state.deployDirection, Parameters.fastSpeed);
									Light.turnOffPrivLight();
									prepareStateChangeEvent(e, kDeviceStateStowing, e.eventType);
									state.counterDirection *=-1;
									state.doorDeployed=1;
								}
								done=1;
								break;
							case kDeviceLAVButtonPressed:
								if (isStowed()){
									state.doorBlocked=1;
									state.doorQSLocated=1;
									coreSystemTimerWait(Parameters.doorMoveDelay);
									prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
								}
								else{
									Encoder.encoderEnable();
									Motor.setCurrentLimit(getFastSpeedCurrentLimit());
									Motor.startMotor(state.deployDirection, Parameters.fastSpeed);
									Light.turnOnPrivLight();
									Light.setPrivacyLock();
									prepareStateChangeEvent(e, kDeviceStateStowing, e.eventType);
									state.counterDirection *=-1;
									state.doorDeployed=1;
								}
								done=1;
								break;
							default:
								break;
						}
					}else if (state.doorQDLocated || (e.eventType==kDoorQDLocated)){
						Motor.setCurrentLimit(getSlowSpeedCurrentLimit());
						Motor.startMotor(state.deployDirection, Parameters.slowSpeed);
						fastMode=0; state.kinematicLimit=10;
					}else if (state.doorFTLocated || (e.eventType==kDoorFTLocated)){
						Motor.setCurrentLimit(getFastSpeedCurrentLimit());
						Motor.startMotor(state.deployDirection, Parameters.fastSpeed);
						Motor.setMotorDutyCycle(getFastSpeedDutyCycle());
						
					}else{
						state.doorPositionknown=0;
						Motor.setCurrentLimit(getSlowSpeedCurrentLimit());
						Motor.stopMotor();
						prepareStateChangeEvent(e, kDeviceStateInitialize, e.eventType);
						done=1;
					}
				case kAdminEventClass:
					if(e.eventType==kDeviceTTLEvent){
						prepareStateChangeEvent(e, kDeviceStateForcedStow, e.eventType);
						done=1;
					}
				default:
					prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
					done=1;
					break;
			}
			
		}
		#ifdef __DEBUG__
			controller.asc0 << " speed == " << Encoder.getRPM() << " rpm, distance == " << Encoder.getDistance() << " mm"<< newline;
		#endif
		if ((!done)&&(!state.doorDeployed)&&(!state.HWCutOff)&&(!state.doorBlocked)){
			if (fastMode){
				if  (((coreSystemTimerTicks() - enterStateTime) > 700) && (Encoder.getRPM() < state.kinematicLimit)){
					#ifdef __DEBUG__
						controller.asc0 << "deploy: fast mode blocked" << newline;
					#endif
					if (isStowed()){
						prepareStateChangeEvent(e, kDeviceStateForcedStow, e.eventType);
					}else{
						prepareStateChangeEvent(e, kDeviceStateOverload, e.eventType);
					}
					done = 1;
				}
			}else if (Encoder.getRPM() < state.kinematicLimit){
					#ifdef __DEBUG__
						controller.asc0 << "deploy: slow mode blocked" << newline;
					#endif
					prepareStateChangeEvent(e, kDeviceStateForcedStow, e.eventType);
					done = 1;
			}
		}
		e=checkPeripheral();
		
	}

	Motor.stopMotor();
	Encoder.encoderDisable();

	#ifdef __DEBUG__
		controller.asc0.lock();
		controller.asc0 << "leaving handleStateDeploy" << newline;
		controller.asc0 << "distance == " << Encoder.getDistance() << " mm"<< newline;
		controller.asc0.unlock();	
	#endif
	sendEventSelf(e);
	this->e=e;
	state.lastState=state.currentState;
} 	

void applicationClass::handleStateStow(){
	state.currentState=kDeviceStateStowing;
	event	e=Door.e;
	bool	done(false);
	time_t	enterStateTime(coreSystemTimerTicks());
	
	#ifdef __DEBUG__
		controller.asc0.lock();
		controller.asc0 << "handleStateStow" << newline;
		controller.asc0 << "distance == " << Encoder.getDistance() << " mm"<< newline;
		controller.asc0.unlock();	
	#endif
	
	if (isStowed()||isDeployed()){
		Encoder.setDistance(0);
	}else if (!doorPositionKnown()){
		Encoder.setDistance(state.deployPosition/2);
	}
	#ifdef __DEBUG__
	controller.asc0 << "distance == " << Encoder.getDistance() << " mm"<< newline;
	#endif

	state.doorDeploying = false;
	state.doorDeployed = false;
/*
	if (isDeployed()){
		coreSystemTimerWait(Parameters.changeDirectionToStowDelay);
		state.doorBlocked=1;
		state.directionChanged = false;
		Motor.startMotor(state.stowDirection, getFastSpeedDutyCycle());
		//KHH 04.11.19: optimizeed value for the wait
		//coreSystemTimerWait(200);
		coreSystemTimerWait(200);
		Motor.setDECModuleMode(0x01);
	}
	else{
		Motor.setCurrentLimit(getSlowSpeedCurrentLimit());
		Motor.startMotor(state.stowDirection, getFastSpeedDutyCycle());
		Motor.setDECModuleMode(0x01);
	}
*/	
	while ((!done)&&(!state.doorStowed)&&(!state.HWCutOff)&&(!state.doorBlocked)){	
		if (hardwareCutOff()){
			#ifdef __DEBUG__
			controller.asc0 << "!!!Hardware CutOff!!!" << newline;
			#endif
			state.HWCutOff=1;
			e.eventClass=kHardwareEventClass;
			e.eventType=kDeviceHWCutOffEvent;
			sendEventSelf(e);
			prepareStateChangeEvent(e, kDeviceStateOverload);
			done=1;
		}
		if ((coreSystemTimerTicks() - enterStateTime) > Parameters.stowTimeoutTime*2){
			#ifdef __DEBUG__
				controller.asc0 << "stow: timeout" << newline;
			#endif
			state.doorBlocked=1;
			e.eventClass=kHardwareEventClass;
			e.eventType=kStowTimeoutType;
			sendEventSelf(e);
			prepareStateChangeEvent(e, kDeviceStateError);
			done=1;
		}
		else if (handleInStateEvent(e, 100, done)){
			switch (e.eventClass){
				case kDeviceEventClass:
					switch (e.eventType){
						case kDeviceCABButtonPressed:
							if (!state.privLight){
								if (isDeployed()){
									coreSystemTimerWait(Parameters.changeDirectionToStowDelay);
									state.doorLocked=1;
									state.doorQDLocated=1;
									prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
									done=1;
													
								}else if (isStowed()){
									state.doorLocked=1;
									state.doorQSLocated=1;
									prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
									done=1;
								}else{
									Motor.setCurrentLimit(getSlowSpeedCurrentLimit());
									Motor.startMotor(state.stowDirection, getSlowSpeedDutyCycle());
									Light.turnOffPrivLight();
									state.directionChanged = true;
									prepareStateChangeEvent(e, kDeviceStateDeploying, e.eventType);
									state.counterDirection *=-1;
									done = true;
								}
							}else{
								state.doorQSLocated=1;
								prepareStateChangeEvent(e, kDeviceStateLocked, e.eventType);
								done = true;
							}
							
							break;
						case kDeviceLAVButtonPressed:
							if (isDeployed()){
								coreSystemTimerWait(Parameters.changeDirectionToStowDelay);
								state.doorBlocked=1;
								state.doorQSLocated=1;
								prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
								done=1;
							}else{
								Motor.stopMotor();
								Motor.setDECModuleMode(0x00);
								Motor.startMotor(state.stowDirection, Parameters.changeDirectionSpeed);
								coreSystemTimerWait(200);
								Light.turnOffPrivLight();
								prepareStateChangeEvent(e, kDeviceStateDeploying, e.eventType);
								state.directionChanged = true;
								state.counterDirection *=-1;
								
							}
							done = true;
							break;
						case kDeviceDoorStowPositionReached:
							prepareStateChangeEvent(e, kDeviceStateLocked, e.eventType);
							done = true;
							break;
							
						case kDoorFTInitiated:
							Motor.setCurrentLimit(getFastSpeedCurrentLimit());
							Motor.stopMotor();
							Motor.setDECModuleMode(0x00);
							Motor.startMotor(state.stowDirection, getSlowSpeedDutyCycle());
							//coreSystemTimerWait(200);
							Light.turnOffPrivLight();
							prepareStateChangeEvent(e, kDeviceStateLocked, e.eventType);
							break;

						default:
							prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
							done=1;
							break;
							}
						break;
				
				case kAdminEventClass:
					switch(e.eventType){
						case kDeviceCABButtonPressed:
							prepareStateChangeEvent(e, kDeviceStateLocked, e.eventType);
							done=1;
							break;
						case kDeviceTTLEvent:
							prepareStateChangeEvent(e, kDeviceStateForcedStow, e.eventType);
							done=1;
							break;
						default:
							prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
							done=1;
							break;
					}
				case kHardwareEventClass:
					prepareStateChangeEvent(e, kDeviceStateOverload, e.eventType);
					done=1;
					break;
				default:
					prepareStateChangeEvent(e, kDeviceStateResume, e.eventType);
					done=1;
					break;
					
				
			}
			if (state.doorQSLocated || (e.eventType==kDoorQSLocated)){
				Motor.setCurrentLimit(getSlowSpeedCurrentLimit());
				Motor.startMotor(state.deployDirection, Parameters.slowSpeed);
				state.fastMode=0; state.kinematicLimit=10;
			}
			if (state.doorFTLocated || (e.eventType==kDoorFTLocated)){
				Motor.setCurrentLimit(getFastSpeedCurrentLimit());
				Motor.startMotor(state.deployDirection, Parameters.fastSpeed);
				Motor.setMotorDutyCycle(getFastSpeedDutyCycle());
				state.fastMode=1;
			}
			
		}
		#ifdef __DEBUG__
			//controller.asc0 << "speed == " <<Encoder.getRPM() << " rpm, distance == " << Encoder.getDistance() << " mm"<< newline;
		#endif
		e=checkPeripheral();
	}

	Motor.stopMotor();
	#ifdef __DEBUG__
		controller.asc0.lock();
		controller.asc0 << "leaving handleStateStow" << newline;
		controller.asc0 << "distance == " << Encoder.getDistance() << " mm"<< newline;
		controller.asc0.unlock();	
	#endif
	sendEventSelf(e);
	Door.e=e;
	state.lastState=state.currentState;
} 	

void applicationClass::handleStateOverload(void){
	state.currentState=kDeviceStateOverload;
	event	e;
	e=Door.e;
	
	#if __DEBUG__ > 0
		controller.asc0.lock();
		controller.asc0 << "handleStateOverload" << newline;
		controller.asc0.unlock();
	#endif
	
	coreSystemTimerWaitWithCallback(Parameters.cutoffTimer, (time_t)Parameters.cutoffTimer/100, checkEvent);
	switch(e.eventType){
		case kDeviceMotorNotReady:
			prepareStateChangeEvent(e, kDeviceStateError);
			break;
		case kDeviceOverHeat:
			prepareStateChangeEvent(e, kDeviceStateReset);
			break;
		case kDoorQSLocated:
			Light.turnOffPrivLight();
			Light.clearPrivacyLock();
			prepareStateChangeEvent(e, kDeviceStateInitialize);
			break;
		case kDoorQDLocated:
			Light.turnOnPrivLight();
			Light.clearPrivacyLock();
			prepareStateChangeEvent(e, kDeviceStateStowing);
			break;
		case kDoorFTLocated:
			Light.blinklight();
			prepareStateChangeEvent(e, kDeviceStateStowing);
			break;
		default:
			prepareStateChangeEvent(e, kDeviceStateResume);
			break;
	}
	sendEventSelf(e);
	state.lastState=state.currentState;
}
	

void applicationClass::handleStateError(){
	state.currentState=kDeviceStateError;
	event	e;
	bool	done(false);
	
#if __DEBUG__ > 1
	controller.asc0.lock();
	controller.asc0 << "handleStateError" << newline;
	controller.asc0.unlock();	
#endif
	while (!done)
		{
		if (handleInStateEvent(e, 100, done))
			{
			switch (e.eventClass)
				{
					
				default:
					break;
				}
			}
		}	//	while (!done)

	sendEventSelf(e);
	state.lastState=state.currentState;
	}

bool applicationClass::handleInStateEvent(event& e, time_t t, bool& done){
	//state.currentState=kDeviceInStateEvent;
	bool	result;
	
	done = false;

#if __DEBUG__  > 4
	controller.asc0.lock();
	controller.asc0 << " handleInStateEvent" << newline;
	controller.asc0.unlock();	
#endif
	result = waitForEvent(e, kAnyEventClass, kAnyEventType, t);
	
	if (result){
	#if __DEBUG__  > 3
		controller.asc0.lock();
		controller.asc0 << coreSystemTimerTicks() << ": handleInStateEvent got event: ";
	#endif
		switch (e.eventClass){
			case kCommunicationEventClass:
				#if DEBUG_MAINTENANCE
					controller.asc0 << "class == kCommunicationEventClass";
				#endif
				switch (e.eventType){
					case kUARTDataAvailableEvent:
						#if DEBUG_MAINTENANCE
							controller.asc0 << ", type == UART Data Available";
						#endif
						
						if (coreAsyncSerialPeek(kUART3) == '@'){
							prepareStateChangeEvent(e, kDeviceStateMaintenance);
							done = true;
						}else{
							char	buffer[32];
							uint16	n(coreAsyncSerialDataAvailable(kUART3));
							
							if (n > sizeof(buffer))
								n = sizeof(buffer);
								
							coreAsyncSerialRead(kUART3, buffer, n, 0);
						}
						break;

					default:
						#if DEBUG_MAINTENANCE
							controller.asc0 << ", type == " << kModeHex << e.eventType;
						#endif
						break;
				}
 				break;

			case kDeviceEventClass:
			#if __DEBUG__  > 3
				controller.asc0 << "class == kDeviceEventClass, type == '" << deviceEventDescription[e.eventType - kDeviceCABButtonPressed] << "'";
			#endif
				switch (e.eventType){
					case kDeviceDoorDeployPositionReached:
						Encoder.setDistance(0);
						state.doorStowed = false;
						break;

					case kDeviceDoorDeployPositionLeft:
						state.doorDeployed = false;
						break;

					case kDeviceDoorStowPositionReached:
						Encoder.setDistance(0);
						state.doorDeployed = false;
						break;

					case kDeviceDoorStowPositionLeft:
						state.doorStowed = false;
						break;
						

					default:
						break;
				}
				break;

			default:
			#if __DEBUG__  > 3
				controller.asc0 << "class == " << kModeHex << e.eventClass;
				controller.asc0 << ", type == " << kModeHex << e.eventType;
			#endif
				break;
			}
	#if __DEBUG__  > 3
		controller.asc0 << newline;
	#endif
		}
	#if __DEBUG__  > 4
	else
		{
		controller.asc0.lock();
		controller.asc0 << "handleInStateEvent got no event" << newline;
		controller.asc0.unlock();
	}
	#endif

	return result;
//	state.lastState=state.currentState;
}

void applicationClass::prepareStateChangeEvent(event& e, uint16 newState, uint16 data){
	if (newState==kDeviceStateResume){
		state.lastState=state.currentState;
	} 
	e.eventClass = kDeviceEventClass;
	e.eventType = kDeviceSwitchStateEvent;
	e.data.wordData[0] = newState;
	e.data.wordData[1] = data;
	//Door.e=e;
	}

bool applicationClass::isDeployed(void){
	bool	result;
	
	result = deploySwitchClosed();
	result |= state.doorDeployed;
	state.doorPositionknown=true;
	#ifdef OFFLINE
		result |=  (Encoder.getDistance() > state.deployPosition);
	#endif
	return result;
}
		
bool applicationClass::isStowed(void){
	bool	result;
	
	result = stowSwitchClosed();
	result |= state.doorStowed;
	state.doorPositionknown=true;
	#ifdef OFFLINE
		result |=  (getDistance() < 2);
	#endif
	return result;
}
		
bool applicationClass::doorSizeConfiguration(void) const {
#ifdef OFFLINE
	bool	result = false;
	#else
		bool	result = Parameters.doorSide;
	#endif
	return result;
}
		
bool applicationClass::doorSideConfiguration(void) const {
	#ifdef OFFLINE
		bool	result = false;
	#else
		bool	result = Parameters.doorSide;
	#endif
	return result;
}
		
bool applicationClass::deploySwitchClosed(void) {
	bool	result = ((PORT->Group[1].IN.reg & (1 << 2)) == 0);
	if (result){
		state.doorQSLocated=0; state.doorFTLocated=0; state.doorQDLocated=1;
	}
	return result;
}

bool applicationClass::stowSwitchClosed(void){
	bool	result = ((PORT->Group[1].IN.reg & (1 << 1)) == 0);
	if (result){
		state.doorQSLocated=1; state.doorFTLocated=0; state.doorQDLocated=0;
	}
	return result;
}
	
bool applicationClass::isDoorLocked(void){
	
	state.doorLocked=(stowSwitchClosed()||deploySwitchClosed());
	return state.doorLocked;
	
}
	
bool applicationClass::doorPositionKnown(void){
			
		return (state.doorFTLocated|state.doorQDLocated|state.doorQSLocated);
	}

bool applicationClass::isDeploying(void){
	
	if((Encoder.isMoving())&&(state.lastState==kDeviceStateLocked)&&(state.currentState==kDeviceStateDeploying)){
		state.doorDeploying=1;
	}else{
		state.doorDeploying=0;
	}
	return (state.doorDeploying);
}

bool applicationClass::isStowing(void){
	
	if((Encoder.isMoving())&&(state.lastState==kDeviceStateLocked)&&(state.currentState==kDeviceStateStowing)){
		state.doorStowing=1;
	}else{
		state.doorStowing=0;
	}
	return (state.doorStowing);
}

int applicationClass::doorReturn(void){
	return state.counterDirection;
}

uint8 applicationClass::buttonPressed(void) 
	{
	uint8	result = (CABButtonPressed() + LAVButtonPressed()*2 + hardwareCutOff()*4 + TTLButtonPressed()*8 );
	return result;
	}
	
bool applicationClass::TTLButtonPressed(void) 
{
	bool	result = ((PORT->Group[1].IN.reg & (1 << 4))== 0);
	return result;
}

bool applicationClass::LAVButtonPressed(void) 
{
	bool	result = ((PORT->Group[1].IN.reg & (1 << 5))  == 0);
	return result;
}

bool applicationClass::CABButtonPressed(void){
	bool	result = ((PORT->Group[1].IN.reg & (1 << 6))== 0);
	return result;
}

bool applicationClass::hardwareCutOff(void){
	bool	result = ((PORT->Group[1].IN.reg & (1 << 14))== 0);
	return result;
}
		
float applicationClass::getSlowSpeedDutyCycle(void) const
	{
	return Parameters.slowSpeed;
	}
		
float applicationClass::getFastSpeedDutyCycle(void) const
	{
	

	return  Parameters.fastSpeed;
	}

uint16 applicationClass::getSlowSpeedCurrentLimit(void) const
	{
	return Parameters.slowSpeedCurrentLimit;
	}

uint16 applicationClass::getFastSpeedCurrentLimit(void) const
	{
	
	return Parameters.fastSpeedCurrentLimit;
}



event applicationClass::checkPeripheral(void){
	event	e;
	
	uint8	value=0;
	float	distance;
	
	
	e=Door.e;
	//e.data.wordData[0]=state.currentState;
	
	

	if (!(Motor.ICMReady())){
		state.motorNotReady=1;
		e.eventClass=kHardwareEventClass;
		e.eventType=kDeviceMotorNotReady;
		prepareStateChangeEvent(e, kDeviceStateError);
		sendEventSelf(e);
		return e;
	}
	
	if (hardwareCutOff()){
		state.HWCutOff=1;
		e.eventClass=kHardwareEventClass;
		e.eventType=kDeviceHWCutOffEvent;
		prepareStateChangeEvent(e, kDeviceStateResume);
		sendEventSelf(e);
		return e;
	}
	
	if (Encoder.getRPM()<Parameters.minSpeedCutOff){
		state.doorMoving=false;
		if (state.lastState==kDeviceStateError){
			state.doorInactive=1;
			e.eventClass=kHardwareEventClass;
			e.eventType=kDoorBlockedType;
			prepareStateChangeEvent(e, kDeviceStateReset);
			sendEventSelf(e);
			return e;
		}
		if (state.lastState==kDeviceStateResume){
			state.doorBlocked=1;
			e.eventClass=kHardwareEventClass;
			e.eventType=kDoorBlockedType;
			prepareStateChangeEvent(e, kDeviceStateLocked);
			sendEventSelf(e);
			return e;
		}
		/*
		if ((isDeployed()|isStowed())==0){
			if (state.lastState==kDeviceStateDeploying){
				state.doorBlocked=1;
				e.eventClass=kHardwareEventClass;
				e.eventType=kDoorBlockedType;
				prepareStateChangeEvent(e, kDeviceStateOverload);
				sendEventSelf(e);
				return e;
			}
			if (state.lastState==kDeviceStateStowing){
				state.doorBlocked=1;
				e.eventClass=kHardwareEventClass;
				e.eventType=kDoorBlockedType;
				prepareStateChangeEvent(e, kDeviceStateResume);
				sendEventSelf(e);
				return e;
			}
			
		}
		*/
	}
	
	
	
	
	if (Encoder.isMoving()){
		
		state.doorLocked=0;
		state.doorMoving=true;
		distance = Encoder.getDistance();
		
		if ((distance<0) | (distance>1.1*(Parameters.doorSize==Size24inch?Parameters.kDeployPosition24inch:Parameters.kDeployPosition22inch))){
			state.doorPositionknown=0;
			if (state.lastState==kDeviceStateDeploying){
				state.HWCutOff=1;
				e.eventClass=kHardwareEventClass;
				e.eventType=kDoorBlockedType;
				prepareStateChangeEvent(e, kDeviceStateForcedStow);
				sendEventSelf(e);
				return e;
			}
			if (state.lastState==kDeviceStateStowing){
				state.doorLocked=1;
				e.eventClass=kHardwareEventClass;
				e.eventType=kDoorForcedMove;
				prepareStateChangeEvent(e, kDeviceStateInitialize);
				sendEventSelf(e);
				return e;
			}
		}else{
			if ((Parameters.slowSpeedOffsetStow >= distance) &&  (distance <= Parameters.slowSpeedOffsetDeploy)){
				e.eventType = kDoorFTLocated;
				state.doorQSLocated=0; state.doorFTLocated=1; state.doorQDLocated=0;
				sendEventSelf(e);
			}
			if (distance >= (state.deployPosition - Parameters.slowSpeedOffsetDeploy)){
				e.eventType = kDoorQDLocated;
				state.doorQSLocated=0; state.doorFTLocated=0; state.doorQDLocated=1;
				sendEventSelf(e);
			}
			if (distance <= (Parameters.slowSpeedOffsetStow)){
				e.eventType = kDoorQSLocated;
				state.doorQSLocated=1; state.doorFTLocated=0;
				sendEventSelf(e);
			}
			
		}
	}else if (!isDoorLocked()){
			state.distanceEstimatedRaw=Encoder.getDistance();
			state.doorPositionknown=doorPositionKnown();
			if (state.currentState==kDeviceStateInitialize){
				e.eventType= kDeviceEventClass;
				e.eventType = kDoorFTInitiated;
				sendEventSelf(e);
			}
	
		
	}else{
		int16 raw=Thermo.getTemperatureRaw();
		if ((raw <= 503) |  (raw > 4185)){
			state.istooHot=1;
			e.eventClass=kHardwareEventClass;
			e.eventType=kDeviceOverHeat;
			prepareStateChangeEvent(e, kDeviceStateError);
			sendEventSelf(e);
			return e;
		}
		e.eventType= kHardwareEventClass;
		e.eventType = kHardwareErrorType;
		sendEventSelf(e);
	}
	
	if(state.doorLocked==1){
		value = deploySwitchClosed();
		if (deployedPositionSave != value){
			deployedPositionSave = value;
			if ((value==1) && (state.currentState==kDeviceStateDeploying)){
				state.doorDeployed=1; state.doorPositionknown=0;
				e.eventType = kDeviceDoorDeployPositionReached;
				prepareStateChangeEvent(e, kDeviceStateLocked);
				sendEventSelf(e);
				return e;
			}
			if (((value==0) && (Encoder.isMoving()))){
				state.doorDeployed=0;
				e.eventClass=kOverloadEventClass;
				e.eventType = kDoorForcedMove;
				prepareStateChangeEvent(e, kDeviceStateOverload);
				sendEventSelf(e);
				return e;
			}
		}
		value = stowSwitchClosed();
		if (stowedPositionSave != value){
			stowedPositionSave = value;
			if ((value==1) && (state.currentState==kDeviceStateStowing)){
				state.doorStowed=1;	state.doorPositionknown=1; 
				e.eventType = kDeviceDoorStowPositionReached;
				prepareStateChangeEvent(e,kDeviceStateLocked);
				sendEventSelf(e);
				return e;
			}
			if (((value==0) && (Encoder.isMoving()))){
				state.doorStowed=0; state.doorPositionknown=0;
				e.eventClass=kOverloadEventClass;
				e.eventType = kDoorForcedMove;
				prepareStateChangeEvent(e, kDeviceStateOverload);
				sendEventSelf(e);
				return e;
			}
		}
	}
	
	value = buttonPressed();
	if (ButtonPressedSave != value){
		
		ButtonPressedSave = value;
		switch (value){
			case 1:
				e.eventClass = kUserEventClass;
				e.eventType = kDeviceCABButtonPressed;
				sendEventSelf(e);
				break;
			case 2:
				e.eventClass = kUserEventClass;
				e.eventType = kDeviceLAVButtonPressed;
				sendEventSelf(e);
				break;
			case 4:
				e.eventType = kDeviceHWCutOffEvent;
				e.eventClass = kHardwareEventClass;
				sendEventSelf(e);
				break;
			case 8:
				e.eventType = kDeviceTTLEvent;
				e.eventClass = kAdminEventClass;
				sendEventSelf(e);
				break;
			default:
				break;
		}	
	}
	Door.e=e;
	
	
	return e;
}


void checkEvent(void){
	
	if ((coreSystemTimerTicks() - Door.e.lastCheckEventCalled) >= 50){
		coreControllerServiceWatchdog();
		Door.e.lastCheckEventCalled = coreSystemTimerTicks();
		Door.e=Door.checkPeripheral();
	}
	
}






