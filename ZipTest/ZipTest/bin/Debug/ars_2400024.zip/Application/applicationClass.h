/*--------------------------------------------------------------------------

applicationClass.h

Interface
Door Actuator P/N 2400023

Author: Steffen Simon

$Date: 2017-11-09 11:49:36 +0100 (Do, 09 Nov 2017) $
$Revision: 1611 $
$Author: steffen $

--------------------------------------------------------------------------*/
#ifndef DEVICE_CLASS_H
#define DEVICE_CLASS_H


#include "DeviceDefinitions.h"
#include "Parameters.h"
#include "coreTypes.h"
#include "eDeviceEvent.h"
#include "eDevice.h"
#include "samd21.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "version.h"
#include "motorDriver.h"
#include "thermometerClass.h"
#include "encoderClass.h"
#include "privateLightClass.h"
#include "buttonTimer.h"

#pragma pack (4)

typedef struct
	{
	uint32	magic;
	time_t	now;
	int		build;
	
	bool	privLight;
	
	uint8	lastState;
	uint8	currentState;
	uint8	callingState;
	

	uint32	selfProtectSourceMask;
	uint32	error;
	int		counterDirection;

	bool	deployDirection:1;
	bool	stowDirection:1;
	bool	doorMoving:1;
	bool	doorDeploying:1;
	bool	doorStowing:1;
	bool	doorDeployed:1;
	bool	doorStowed:1;
	bool	doorPositionknown;
	bool	doorQSLocated;
	bool	doorQDLocated;
	bool	doorFTLocated;
	bool	motorNotReady;
	bool	istooHot;
	bool	doorBlocked;
	bool	doorLocked;
	bool	doorInactive;
	bool	HWCutOff;
	bool	fastMode;
	float	deployPosition;
	mutable time_t	lastRPMCheck;
	mutable uint32	currentRPM;
	mutable uint32	kinematicLimit;
	uint32	targetRPM;
	
	int32	distanceEstimatedRaw;
	uint8	internalCateringState;
	uint8	maintenanceState;
	uint8	maintenanceFlags;

	time_t	inStateTime;
	time_t	leaveInternalOperationStateTime;
	
	bool	directionChanged:1;
	bool	maintenanceToolConnected:1;
	} DeviceWorkingState;



/** \brief Device flow control
*/
class applicationClass
	{
	public:
		applicationClass();
		
		void	run(void);

		void	handleDeviceEvent(event& theEvent);

		void	handleStateReset(void);
		void	handleStateInitialize(void);
		void	handleStateResume(void);
		void	handleStateLocked(void);
		void	handleStateDeploy(void);
		void	handleStateStow(void);
		void	handleStateForcedStow(void);
		void	handleStateError(void);
		void	handleStateOverload(void);
		void	handleStateMaintenance(void);
	
		
		
		bool	handleInStateEvent(event& e, time_t t, bool& done);
		//friend void EIC_Handler(void);
		bool	hardwareCutOff(void) ;

		void	prepareStateChangeEvent(event& e, uint16 newState, uint16 data = 0);
		
		event checkPeripheral(void);
		
		
		
		bool	isDeployed(void);
		bool	isStowed(void);
		bool	isDeploying(void);
		bool	isStowing(void);
		int		doorReturn(void);
		void	initDoor(void);
		
		
	
		
		
		
		
		
		static	 event				e;
		static	 motorDriverClass	 Motor;
		static   encoderClass			Encoder;
		static	 thermoClass		 Thermo;
		static	 timerClass			TTLTimer;
		static	 timerClass			CABTimer;
		static	 privacyLightClass		Light;
		
		friend void checkEvent(void);
		friend class encoderClass;
		friend class privacyLightClass;
		friend class event;
		friend void EIC_Handler1(void);
		DeviceWorkingState	state;
	

	protected:
		
		
		
		bool	doorPositionKnown(void);
		bool	isDoorLocked(void);

	
		bool	doorSizeConfiguration(void) const;
		bool	doorSideConfiguration(void) const ;
		bool	deploySwitchClosed(void) ;
		bool	stowSwitchClosed(void);
		uint8	buttonPressed(void) ;
		bool	LAVButtonPressed(void) ;
		bool	CABButtonPressed(void) ;
		bool	TTLButtonPressed(void) ;
		
		
		bool	enableMotorMonitorValue(void) const;

		float	getSlowSpeedDutyCycle(void) const;
		float	getFastSpeedDutyCycle(void) const;

		uint16	getSlowSpeedCurrentLimit(void) const;
		uint16	getFastSpeedCurrentLimit(void) const;

			
        
		
		time_t	powerInterruptDuration;
		bool	resumeLastStateValid;
		
		
		
	private:
	
		
	
		  bool	kClockWise;
		  bool	kCounterClockWise;

		  bool	kConfigurationRightHand;
		  bool	kConfigurationLeftHand;

		 configurationDataStruct	configuration;

		 userParameters	Parameters;

		 bool	doorPositionSave;
		 bool	deployedPositionSave;
		 bool	stowedPositionSave;
		 bool	ButtonPressedSave;
		
		
	};

void checkEvent(void);
extern applicationClass Door;



#endif


