/*
 * privacyLightClass.cpp
 *
 * Created: 10/28/2019 9:49:43 PM
 *  Author: giova
 */ 

#include "privateLightClass.h"
#include "applicationClass.h"


privacyLightClass::privacyLightClass(const userPreferences* Preferences){
	locked=0;
	period=Preferences->privacyLightperiod;
	dutyCycle=Preferences->privacyLightDutyCycle;
	timerLightInit();
}

privacyLightClass::~privacyLightClass(void){
	timerLightDisable();
}

void privacyLightClass::turnOnPrivLight(void){
	timerLightDisable();
	PORT->Group[1].OUTSET.reg = (1UL << 7);
	Door.state.privLight=1;
}
void privacyLightClass::turnOffPrivLight(void){
	timerLightDisable();
	PORT->Group[1].OUTCLR.reg = (1UL << 7);
	Door.state.privLight=1;
}

void privacyLightClass::blinklight(void){
	timerLightEnable();
	PORT->Group[1].OUTTGL.reg = (1UL << 7);
	if ((PORT->Group[1].IN.reg & (1UL << 7))==1){
	}
}

void privacyLightClass::timerLightInit(void){
		
	
		
	PM->APBAMASK.reg |=  PM_APBAMASK_EIC;				
	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID_EIC |GCLK_GENCTRL_SRC(GCLK_GENCTRL_SRC_OSC32K_Val)| GCLK_CLKCTRL_CLKEN;

		
	TCC2->CTRLA.bit.ENABLE &=~(TCC_CTRLA_ENABLE);
	TCC2->CTRLA.reg	|=TCC_CTRLA_RUNSTDBY|TCC_CTRLA_CPTEN0|TCC_CTRLA_CPTEN1;
	while(TCC2->SYNCBUSY.bit.ENABLE==1);
	
	TCC2->CTRLBSET.reg= TCC_CTRLBSET_DIR | TCC_CTRLBSET_CMD_RETRIGGER;
	while(TCC2->SYNCBUSY.bit.CTRLB==1);
	
	TCC2->INTENSET.reg = TCC_INTENSET_OVF | TCC_INTENSET_TRG | TCC_INTENSET_MC0 | TCC_INTENSET_MC1  ;
	while(TCC2->SYNCBUSY.bit.STATUS==1);
			
	TCC2->CC[0].reg = period;
	while(TCC2->SYNCBUSY.bit.CC0 == 1);
	
	TCC2->CC[1].reg = dutyCycle;
	while(TCC2->SYNCBUSY.bit.CC1 == 1);
			
}


void privacyLightClass::timerLightEnable(void){
	cpu_irq_disable();
		
	TCC2->CTRLA.reg |= TCC_CTRLA_ENABLE ;	// Enable TCC2
	while(TCC2->SYNCBUSY.bit.ENABLE== 1);
													
	NVIC_EnableIRQ(TCC2_IRQn);						// Enable the interrupt
	
	/* Enable all IRQs */
	cpu_irq_enable();
	
	
}
void privacyLightClass::timerLightDisable(void){
	cpu_irq_disable();
	NVIC_DisableIRQ(TCC2_IRQn);		// Disable the interrupt
		
	TCC2->CTRLA.reg &=~(TCC_CTRLA_ENABLE) ;	// Disable TC3
	while(TCC2->SYNCBUSY.bit.ENABLE== 1);
	
	cpu_irq_enable();
}

bool privacyLightClass::timeoutPrivacylight(void){
	
	return (TCC2->INTFLAG.bit.OVF==1);
}

void privacyLightClass::setPrivacyLock(void){
	if (!(Door.Encoder.isMoving())){
		PORT->Group[0].OUTSET.reg = (1UL << 19);
	}else{
		PORT->Group[0].OUTCLR.reg = (1UL << 19);
	}
		
}
void privacyLightClass::clearPrivacyLock(void){
	
		PORT->Group[0].OUTCLR.reg = (1UL << 19);
	
	}
	

void TCC2_Handler(void){
	
	if ((TCC2->INTFLAG.bit.MC0)==1){			//check if the interrupion come from timer or communication port
		PORT->Group[1].OUTCLR.reg = (1UL << 7);
	}else if((TCC2->INTFLAG.bit.MC1)==1){
		PORT->Group[1].OUTSET.reg = (1UL << 7);
	}
	
}

