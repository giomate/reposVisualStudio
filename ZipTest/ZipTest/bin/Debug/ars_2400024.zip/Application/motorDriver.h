/*
 * motor_driver.h
 *
 * Created: 10/27/2019 9:39:04 AM
 *  Author: giova
 */ 


#ifndef MOTOR_DRIVER_H_
#define MOTOR_DRIVER_H_

#include "Parameters.h"
#include "coreTypes.h"
#include "corePWM.h"
#include <math.h>

typedef struct{
	
		mutable time_t	lastRPMCheck;
		mutable uint32	currentRPM;
		mutable uint32	kinematicLimit;
		uint32			targetRPM;
		uint16		slowSpeedCurrentLimit;			//	Current Limitation: Number of Steps for electronic resistor
		uint16		fastSpeedCurrentLimit;		    //	fast speed current limitation
		float		motorCurrentLimit;				//	Motorvelocity Slow
		float		motorCurrentResistorFactor;		//	Motorvelocity Slow
		uint16		changeDirectionSpeed;			//	Motorvelocity during Delay 5
		uint16		changeDirectionToStowDelay;		//	Delay wenn Button w�hrend Deploy gedr�ckt wird 0
		uint16		changeDirectionToDeployDelay;	//	Delay wenn Button w�hrend Stow gedr�ckt wird  300
		float		slowSpeed;						//	Motorvelocity Slow
		float		fastSpeed;						//	Motorvelocity High
	
} MotorDriverParameters;



class motorDriverClass
{
	public:
	motorDriverClass(const userParameters*);
	
	~motorDriverClass();
	
	friend class encoderClass;
    bool	ICMReady(void);
	float	setCurrentController(float);
	void	startMotor(bool direction, float dutyCycle);
	void	stopMotor(void);
	void	setMotorDutyCycle(float dutyCycle);
	void	setDECModuleMode(uint8 mode);
	void	setCurrentLimit(uint16 limit);
	void	encoderEnable();
	void	encoderDisable();
	void	initMotorParameters(void);
	
	
	protected:
	void incrementResistor(void);
	void decrementResistor(void);
	void setCS(bool);
	void setUD(bool);
	void veryShortDelay(void);
	
	private:
	  MotorDriverParameters motorParameters;
	};






#endif /* MOTOR_DRIVER_H_ */