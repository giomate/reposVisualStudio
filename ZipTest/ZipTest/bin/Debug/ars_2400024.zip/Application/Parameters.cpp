/*
 * Parameters.cpp
 *
 * Created: 10/23/2019 2:41:11 PM
 *  Author: GMateusDP
 */ 

#include "Parameters.h"
#include <math.h>

const userParameters	defaultParameters =
{
	.slowSpeedCurrentLimit	=		2269,			//	Current Limitation mAmp
	.fastSpeedCurrentLimit =		1500,			//	Current Limitation mAmp
	.motorCurrentLimit =			2270,			//	Current Limitation Amp
	.motorCurrentResistorFactor =	2.2167,		//	Current Limitation Amp
	.changeDirectionSpeed	=		10,			//	Motorvelocity during Delay 5
	.changeDirectionToStowDelay=	0,			//	Delay wenn Button w�hrend Deploy gedr�ckt wird 0
	.changeDirectionToDeployDelay=200,			//	Delay wenn Button w�hrend Stow gedr�ckt wird  300
	.slowSpeed	=					5,			//	Motorvelocity Slow
	.fastSpeed	=					47.1,			//	Motorvelocity High
	.slowSpeedOffsetDeploy	=		135,		//	Distance from deploy position for entering slow speed
	.slowSpeedOffsetStow	=		135,		//	Distance from deploy position for entering slow speed
	.distanceCalibrationValue	=	0.492,		//	Calibration, Motorsignals vs. Distance
	.kDeployPosition24inch	=		1020.0,		//	Distance from deploy position for entering slow speed
	.kDeployPosition22inch	=		980.0,		//	Calibration, Motorsignals vs. Distance
	.minSpeedCutOff			=		5,			//	Minimal speed to consider Door blocked mm/s
	.RPMCalibrationfactor=			1,			//	RPM calibration
	
	.stowTimeoutTime	=			8000,		//	timeout for stowing
	.deployTimeoutTime		=		8000,		//  timeout for deplying
	.blockTimeDelay		=			8000,		//	pause after software cutoff
	.cutoffTimer		=			8000,		//	timer to activate cutoff mode
	.TTLtimer			=			5000,		//	pause after software cutoff
	.CABtimer			=			5000,		//	timer to activate cutoff mode
	.doorMoveDelay      =			100,		//	timer to activate cutoff mode
	
	

	
	.rawTemperatureMin	=			8,			//	Temperature min operation
	.rawTemperatureMax	=			70,			//	Temperature max operation

	.doorSide	=					RightDoor,	//	Door side
	.doorSize	=					Size22inch	//	Door size
};

const userPreferences		defaultPreferences=
{
	.privacyLightperiod		=		250,		//	Period of blinking Light ms
	.privacyLightDutyCycle	=		50,		//	DutyCycle on the Light %
};
