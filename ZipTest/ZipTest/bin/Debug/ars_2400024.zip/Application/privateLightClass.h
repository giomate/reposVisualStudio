/*
 * privateLightClass.h
 *
 * Created: 10/28/2019 9:46:35 PM
 *  Author: giova
 */ 


#ifndef PRIVATELIGHTCLASS_H_
#define PRIVATELIGHTCLASS_H_

#include "coreTypes.h"
#include "Parameters.h"
#include "eCore.h"
#include "sam.h"


class privacyLightClass
{
		
public:
	privacyLightClass( const userPreferences*);
	~privacyLightClass();
	void turnOnPrivLight(void);
	void turnOffPrivLight(void);
	void timerLightInit(void);
	bool timeoutPrivacylight(void);
	
	friend void TCC2_Handler(void);
	friend class applicationClass;
	
protected:
	
	void timerLightEnable(void);
	void timerLightDisable(void);
	void blinklight(void);
	void clearPrivacyLock(void);
	void setPrivacyLock(void);
	
	
private:
	int32	period;
	int32	dutyCycle;
	
	bool locked;
};

void TCC2_Handler(void);


#endif /* PRIVATELIGHTCLASS_H_ */