/*--------------------------------------------------------------------------

GAINDefinitions.cc

Implementation

Common GAIN enum and type definitions

Author: Steffen Simon

$Date: 2017-12-06 12:49:23 +0100 (Mi, 06 Dez 2017) $
$Revision: 1642 $
$Author: steffen $
$HeadURL: https://svn.s2embedded.at/customers/hs2-engineering/trunk/HiLo/Firmware/ExtensionApp/ARSSTD-2400023-2.0/DeviceDefinitions.cc $

--------------------------------------------------------------------------*/
#include "DeviceDefinitions.h"

#ifdef __DEBUG__
	
const uint32_t	kApplicationStateStructVersion = 2;        //diese muss manuell hochgesetzt werden.
const uint32_t	kConfigurationDataStructVersion = 9;


const configurationDataStruct	defaultConfiguration =
	{
	0,
	0xCAFEBABE,
	sizeof(configurationDataStruct),
	kConfigurationDataStructVersion,

	29,			//	uint16		slow speed currentLimitation;	//	Current Limitation
	1,			//	uint16		changeDirectionSpeed;			//	Motorvelocity during Delay
	0,			//	uint16		changeDirectionToStowDelay;		//	Delay wenn Button w�hrend Deploy gedr�ckt wird
	200,		//	uint16		changeDirectionToDeployDelay;	//	Delay wenn Button w�hrend Stow gedr�ckt wird
	5.0,		//	float		slowSpeed;						//	Motorvelocity Slow
	135.0,		//	float		slowSpeedOffset;				//	Distance from deploy position for entering slow speed
	0.4595,		//	float		distanceCalibrationValue;		//	Calibration, Motorsignals vs. Distance
	8000,		//	time_t		stowTimeoutTime;
	8000,		//	time_t		deployTimeoutTime;
	};

const char* deviceStateDescription[] =
	{
	"Power Up",
	"Reset",
	"Initialize",
	"Resume",
	"Locked",
	"Deploy",
	"Stow",
	"Error",
	"Maintenance",
	};

const char* deviceEventDescription[] =
	{
	"Move Button Pressed",

	"Door is Deployed",
	"Door left Deploy Position",
	"Door is Stowed",
	"Door left Stow Position",
	"Door reached slow down Position",

	"Device MotorStalled",
	};
#endif

