/*
 * encoderClass.h
 *
 * Created: 10/27/2019 12:37:35 PM
 *  Author: giova
 */ 



#ifndef ENCODERCLASS_H_
#define ENCODERCLASS_H_

#include <stdio.h>
#include <string.h>

#include "samd21.h"
//#include "coreEIC.h"
#include "coreTypes.h"
#include "Parameters.h"
#include "eCore.h"
//#include "eDevice.h"
//#include "applicationClass.h"



typedef struct
{
	time_t	now;
	float	distance;
	uint32	rpm;
	uint32	speedDoor;
	
} encoderStatus;


class encoderClass
{		
public:
	encoderClass(){};
	encoderClass(const userParameters* parameters);
	//~encoderClass();
	
	float	getDistance(void);
	bool	isMoving(void);
	void	startSpeedMeter(void);
	void	stopSpeedMeter(void);
	float	getRPM(void);
	void	setDistance(float );
	
	
	
	void	encoderEnable(void);
	void	encoderDisable(void);
	bool	timerEncoderTimeout(void);
	bool	isStowed(void);
		
	void	monitorDistance(void);
	
	friend class privacyLightClass;
	friend class motorDriverClass;
	friend void EIC_Handler(void);

	volatile int32	distanceCounter,speedCounter, lastSpeed;
	static uint32			captureTime;
	static uint16			EICnumber;
	encoderStatus		status;
	
protected:
	friend class applicationClass;
	void encoderEICConfigure(void);
	void initEncoderTimer(void);

private:
	
	float			calibrationFactor;
	float			distanceCalibrationValue;
	float			minSpeedCutOff;
	
	
};

void EIC_Handler(void);

#endif /* ENCODERCLASS_H_ */