/*
 * motorDriverClass.cpp
 *
 * Created: 10/27/2019 10:28:57 AM
 *  Author: giova
 */ 


#include "motorDriver.h"
#include "eDevice.h"
#include "applicationClass.h"
#include "coreADConverter.h"




motorDriverClass::motorDriverClass(const userParameters* parameters){
	
	motorParameters.slowSpeedCurrentLimit	=		parameters->slowSpeedCurrentLimit;			//	Current Limitation Amp
	motorParameters.fastSpeedCurrentLimit =		parameters->fastSpeedCurrentLimit;			//	Current Limitation Amp
	motorParameters.motorCurrentLimit =			parameters->motorCurrentLimit;			//	Current Limitation Amp
	motorParameters.motorCurrentResistorFactor =	parameters->motorCurrentResistorFactor;		//	Current Limitation Amp
	motorParameters.changeDirectionSpeed	=		parameters->changeDirectionSpeed;			//	Motorvelocity during Delay 5
	motorParameters.changeDirectionToStowDelay=	parameters->changeDirectionToDeployDelay;			//	Delay wenn Button w�hrend Deploy gedr�ckt wird 0
	motorParameters.changeDirectionToDeployDelay=	parameters->changeDirectionToStowDelay;			//	Delay wenn Button w�hrend Stow gedr�ckt wird  300
	motorParameters.slowSpeed	=					parameters->slowSpeed;			//	Motorvelocity Slow
	motorParameters.fastSpeed	=					parameters->fastSpeed;			//	Motorvelocity High
	
}

motorDriverClass::~motorDriverClass(void){
	stopMotor();
}
	
void motorDriverClass::initMotorParameters(void){
	
		
}


void motorDriverClass::startMotor(bool direction, float dutyCycle)
{
	#if __DEBUG__  > 3
	controller.asc0 << coreSystemTimerTicks() << ": startMotor " << (direction?"CCW":"CW") << ", duty cycle = " << (int)dutyCycle << newline;
	#endif
	//	Setup MAXON
	if (direction)
		PORT->Group[0].OUTSET.reg = (1UL << 16);	//	Set Direction
	else
		PORT->Group[0].OUTCLR.reg = (1UL << 16);	//	Clear Direction
	corePWMSetDutyCycle(kPWM0, dutyCycle);
	//PORT->Group[0].DIRSET.reg = (1UL << 18);
	//PORT->Group[0].OUTSET.reg = (1UL << 18);
	corePWMSetStateOn(kPWM0);

	//	Enable motor
	PORT->Group[1].OUTSET.reg = (1UL << 23);
	motorParameters.lastRPMCheck = coreSystemTimerTicks();
	
	Door.Encoder.encoderEnable();
}

void motorDriverClass::stopMotor(void){
	#if __DEBUG__  > 3
		controller.asc0 << coreSystemTimerTicks() << ": stopMotor " << newline;
	#endif
	//	Disable motor
	PORT->Group[1].OUTCLR.reg = (1UL << 23);
	corePWMSetStateOff(kPWM0);
	Door.Encoder.encoderDisable();
}

void motorDriverClass::setMotorDutyCycle(float dutyCycle)
{
	#if __DEBUG__  > 3
	controller.asc0 << coreSystemTimerTicks() << ": setMotorDutyCycle: duty cycle = " << (int)dutyCycle << newline;
	#endif
	corePWMSetDutyCycle(kPWM0, dutyCycle);
}

	
void motorDriverClass::setDECModuleMode(uint8 mode){
	
		bool	enabled(PORT->Group[1].OUT.reg & (1UL << 23));
		bool	DIGIN1((mode & (1 << 1)) != 0);
		bool	DIGIN2((mode & (1 << 0)) != 0);

		#if __DEBUG__  > 3
			bool	DIGIN1old(PORT->Group[1].OUT.reg & (1UL << 31));
			bool	DIGIN2old(PORT->Group[1].OUT.reg & (1UL << 22));
			controller.asc0 << coreSystemTimerTicks() << ": setDECModuleMode: new mode is "
			<< mode
			<< ", motor enabled: " << (enabled?"yes":"no")
			<< ", DIGIN1: " << (DIGIN1?"hi":"lo")<< " (was: "  << (DIGIN1old?"hi":"lo")
			<< "), DIGIN2: " << (DIGIN2?"hi":"lo")<< " (was: "   << (DIGIN2old?"hi":"lo")
			<< ")" << newline;
		#endif
		
		if (enabled)
		{
			//	Disable motor
			PORT->Group[1].OUTCLR.reg = (1UL << 23);
		}

		//	DIGIN1:
		if (DIGIN1)
		PORT->Group[1].OUTSET.reg = (1UL << 31);
		else
		PORT->Group[1].OUTCLR.reg = (1UL << 31);

		//	DIGIN2:
		if (DIGIN2)
		PORT->Group[1].OUTSET.reg = (1UL << 22);
		else
		PORT->Group[1].OUTCLR.reg = (1UL << 22);

		coreSystemTimerWait(30);
		if (enabled)
		{
			//	Enable motor
			PORT->Group[1].OUTSET.reg = (1UL << 23);
		}

		#if __DEBUG__  > 3
		DIGIN1 = (PORT->Group[1].OUT.reg & (1UL << 31));
		DIGIN2 = (PORT->Group[1].OUT.reg & (1UL << 22));
		controller.asc0 << coreSystemTimerTicks() << ": setDECModuleMode: on exit: "
		<< "motor enabled: " << (enabled?"yes":"no")
		<< ", DIGIN1: " << (DIGIN1?"hi":"lo")<< " (was: "  << (DIGIN1old?"hi":"lo")
		<< "), DIGIN2: " << (DIGIN2?"hi":"lo")<< " (was: "   << (DIGIN2old?"hi":"lo")
		<< ")" << newline;
		#endif
	}


void motorDriverClass::setCurrentLimit(uint16 limit)
{
	uint8	i;
	int32	adc(2048);
	float	currentLimit=(float)limit;
	

	#if __DEBUG__  > 3
	coreADConverterSelectChannel(5);
	adc = coreADConverterReadSingle();
	controller.asc0 << coreSystemTimerTicks() << ": setCurrentLimit: current limit is " << limit << ", approx. R is "  << (int)((limit * 2100)/64)  << " ohm" <<  newline;
	controller.asc0 << "\t initial: " << adc << newline;
	#endif
	
	/*
	
	//	Step 1: Dec to zero
	#if __DEBUG__  > 3
	controller.asc0 << coreSystemTimerTicks() << ": step #1: dec to zero" << newline;
	#endif
	//	C/S hi
	setCS(true);
	setUD(false);
	setCS(false);

	for (i=0; (i<128) && (adc > 40); i++){
		setUD(true);
		setUD(false);
		#if __DEBUG__  > 5
		adc = coreADConverterReadSingle();
		controller.asc0 << "\t #" << i << ": " << adc << newline;
		#endif
	}
	setCS(true);
	
	#if __DEBUG__  > 3
	adc = coreADConverterReadSingle();
	controller.asc0 << coreSystemTimerTicks() << ": final: " << adc << newline;
	#endif
	*/
	setCurrentController(currentLimit);
	/*
	if (limit > 0)
	{
		#if __DEBUG__  > 3
		controller.asc0 << coreSystemTimerTicks() << ": setCurrentLimit: step #2: inc to value " << limit << newline;
		#endif
		//	C/S hi
		setCS(true);
		setUD(true);
		setCS(false);

		for (i=0; i<limit; i++)
		{
			setUD(false);
			setUD(true);
			
			#if __DEBUG__  > 3
			adc = coreADConverterReadSingle();
			controller.asc0 << "\t #" << i << ": " << adc << ", approx. R is "  << (int)(((i + 1) * 2100)/64) << " ohm" << newline;
			#endif
		}
		setCS(true);
		setUD(false);
		
		#if __DEBUG__  > 3
		adc = coreADConverterReadSingle();
		controller.asc0 << coreSystemTimerTicks() << ": final: " << adc << ", approx. R is "  << (int)((i * 2100)/64) << " ohm" << newline;
		#endif
	}
	*/
	
}

float motorDriverClass::setCurrentController(float setpoint){
	uint8	i=0;
	float pi_error,proportional, integral, process, max_current;
	uint32 nintegral;
	max_current=motorParameters.motorCurrentLimit;
	proportional=10; integral=0; nintegral=0;
	
	process=motorParameters.motorCurrentResistorFactor*((float)coreADConverterReadSingle());
	pi_error=setpoint-process;
	
	while (abs(pi_error)>(max_current/64)){
		integral+=proportional*pi_error/(motorParameters.motorCurrentLimit);
		nintegral=(uint32)(abs(integral));
		while (nintegral>0){
			process=((float)coreADConverterReadSingle())*motorParameters.motorCurrentResistorFactor;
			if (integral>0){
				incrementResistor();
				i++;
				#if __DEBUG__  > 3
					controller.asc0 << coreSystemTimerTicks() << ": final: " << process << ", approx. R is "  << (int)((i * 2100)/64) << " ohm" << newline;
				#endif
			}else if (integral<0){
				decrementResistor();
				i>0?i--:i=0;
				#if __DEBUG__  > 3
					controller.asc0 << coreSystemTimerTicks() << ": final: " << process << ", approx. R is "  << (int)((i * 2100)/64) << " ohm" << newline;
				#endif
			}
			nintegral--;
		}
		process=((float)coreADConverterReadSingle())*motorParameters.motorCurrentResistorFactor;
		pi_error=setpoint-process;
		#if __DEBUG__  > 3
			controller.asc0 << coreSystemTimerTicks() << ": final: " << process << ", approx. R is "  << (int)((i * 2100)/64) << " ohm" << newline;
		#endif
	}
	return pi_error;
}

bool motorDriverClass::ICMReady(void){
	bool ready;
	ready = ((PORT->Group[1].IN.reg & (1UL << 30))==1);
	return 1;
	//return ready;
}

void motorDriverClass::setCS(bool value){
	(value?PORT->Group[1].OUTSET.reg = (1UL << 12):PORT->Group[1].OUTCLR.reg = (1UL << 12));
	veryShortDelay();
}
void motorDriverClass::setUD(bool value){
	(value?PORT->Group[1].OUTSET.reg = (1UL << 13):PORT->Group[1].OUTCLR.reg = (1UL << 13));
	veryShortDelay();
}
void motorDriverClass::veryShortDelay(void){
	__NOP();
}

void motorDriverClass::incrementResistor(){
	setCS(true);
	setUD(true);
	setCS(false);
	setUD(false);
	setUD(true);
	setCS(true);
	
}
void motorDriverClass::decrementResistor(){
	setCS(true);
	setUD(false);
	setCS(false);
	setUD(true);
	setUD(false);
	setCS(true);
	
} 